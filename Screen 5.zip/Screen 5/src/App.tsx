import { useEffect } from "react";
import {
  ArrowLeft,
  Bot,
  Brain,
  ChevronDown,
  ChevronRight,
  Cloud,
  Copy,
  Key,
  MonitorCog,
  MoreHorizontal,
  Package,
  Palette,
  Play,
  Plug,
  RefreshCw,
  Save,
  TriangleAlert,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";

export default function App() {
  return (
    <div>
      <div className="font-mono bg-neutral-950 text-neutral-50 w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <div className="sticky z-10 bg-neutral-950 border-white/10 border-t-0 border-r-0 border-b-1 border-l-0 border-solid top-0">
          <div className="flex px-4 items-center gap-4 h-14">
            <button className="size-8 rounded-lg flex justify-center items-center">
              <ArrowLeft className="size-5" />
            </button>
            <span className="font-semibold text-base leading-6 tracking-wide">
              Settings
            </span>
          </div>
        </div>
        <div className="flex px-6 pt-6 pb-12 flex-col gap-8">
          <Card className="bg-neutral-900 border-white/10 border-0 border-solid p-6 gap-4">
            <CardHeader className="p-0 gap-1">
              <div className="text-[oklch(0.708_0.15_295)] flex items-center gap-2">
                <Cloud className="size-4" />
                <span className="font-bold text-[#888] text-xs leading-4 tracking-[3.2px]">
                  CLOUD SYNC
                </span>
              </div>
            </CardHeader>
            <CardContent className="flex p-0 flex-col gap-4">
              <div className="flex justify-between items-center">
                <span className="text-sm leading-5">Supabase Auto-Sync</span>
                <Switch defaultChecked={true} />
              </div>
              <div className="flex flex-col gap-2">
                <label className="text-[#888] text-xs leading-4">
                  Supabase Project URL
                </label>
                <Input
                  className="bg-neutral-800 text-sm leading-5 border-white/10 border-0 border-solid"
                  defaultValue="https://xyz.supabase.co"
                />
              </div>
              <div className="flex flex-col gap-2">
                <label className="text-[#888] text-xs leading-4">
                  Service Role Key
                </label>
                <Input
                  type="password"
                  className="bg-neutral-800 text-sm leading-5 border-white/10 border-0 border-solid"
                  defaultValue="servicekey1234567890"
                />
              </div>
              <div className="flex flex-col gap-2">
                <label className="text-[#888] text-xs leading-4">
                  Personal Access Token
                </label>
                <Input
                  type="password"
                  className="bg-neutral-800 text-sm leading-5 border-white/10 border-0 border-solid"
                  defaultValue="sbp_1234567890abcdef"
                />
              </div>
              <div className="flex gap-2">
                <Button
                  variant="secondary"
                  className="text-sm leading-5 flex-1"
                >
                  <Play className="size-4" />
                  Run Setup
                </Button>
                <Button className="bg-neutral-200 text-neutral-900 text-sm leading-5 flex-1">
                  <RefreshCw className="size-4" />
                  {`Sync & Resolve`}
                </Button>
              </div>
              <button className="rounded-lg bg-neutral-800 border-white/10 border-1 border-solid flex px-4 py-2.5 justify-between items-center w-full">
                <span className="text-sm leading-5">
                  Show Supabase SQL DDL Script
                </span>
                <ChevronDown className="size-4 text-[#888]" />
              </button>
              <Button
                variant="outline"
                className="text-sm leading-5 border-white/10 border-0 border-solid self-start"
              >
                <Copy className="size-4" />
                Copy
              </Button>
            </CardContent>
          </Card>
          <div className="flex flex-col gap-3">
            <button className="text-left rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex p-4 flex-col gap-1">
              <div className="flex items-center gap-2">
                <Key className="size-4 text-[oklch(0.708_0.15_295)]" />
                <span className="font-bold text-[#888] text-xs leading-4 tracking-[3.2px]">
                  PROVIDER SETTINGS
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[#e0e0e0] text-sm leading-5">
                  OpenAI · Google · Anthropic · GLM...
                </span>
                <ChevronRight className="size-4 text-[#555]" />
              </div>
            </button>
            <button className="text-left rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex p-4 flex-col gap-1">
              <div className="flex items-center gap-2">
                <Brain className="size-4 text-[oklch(0.708_0.15_295)]" />
                <span className="font-bold text-[#888] text-xs leading-4 tracking-[3.2px]">
                  MODEL SETTINGS
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[#e0e0e0] text-sm leading-5">{`Per-model params & defaults`}</span>
                <ChevronRight className="size-4 text-[#555]" />
              </div>
            </button>
            <button className="text-left rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex p-4 flex-col gap-1">
              <div className="flex items-center gap-2">
                <Plug className="size-4 text-[oklch(0.708_0.15_295)]" />
                <span className="font-bold text-[#888] text-xs leading-4 tracking-[3.2px]">
                  MCP MANAGER
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[#e0e0e0] text-sm leading-5">
                  Tools, connectors, servers
                </span>
                <ChevronRight className="size-4 text-[#555]" />
              </div>
            </button>
            <button className="text-left rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex p-4 flex-col gap-1">
              <div className="flex items-center gap-2">
                <Bot className="size-4 text-[oklch(0.708_0.15_295)]" />
                <span className="font-bold text-[#888] text-xs leading-4 tracking-[3.2px]">
                  AGENTS
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[#e0e0e0] text-sm leading-5">{`Agent configs & pipelines`}</span>
                <ChevronRight className="size-4 text-[#555]" />
              </div>
            </button>
            <button className="text-left rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex p-4 flex-col gap-1">
              <div className="flex items-center gap-2">
                <Palette className="size-4 text-[oklch(0.708_0.15_295)]" />
                <span className="font-bold text-[#888] text-xs leading-4 tracking-[3.2px]">
                  PERSONALISATION
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[#e0e0e0] text-sm leading-5">
                  Theme, name, avatar
                </span>
                <ChevronRight className="size-4 text-[#555]" />
              </div>
            </button>
            <button className="text-left rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex p-4 flex-col gap-1">
              <div className="flex items-center gap-2">
                <Package className="size-4 text-[oklch(0.708_0.15_295)]" />
                <span className="font-bold text-[#888] text-xs leading-4 tracking-[3.2px]">
                  AUTO COMPRESS
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[#e0e0e0] text-sm leading-5">
                  Context compression rules
                </span>
                <ChevronRight className="size-4 text-[#555]" />
              </div>
            </button>
            <button className="text-left rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex p-4 flex-col gap-1">
              <div className="flex items-center gap-2">
                <MonitorCog className="size-4 text-[oklch(0.708_0.15_295)]" />
                <span className="font-bold text-[#888] text-xs leading-4 tracking-[3.2px]">
                  APPEARANCE
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[#e0e0e0] text-sm leading-5">
                  Font, density, colors
                </span>
                <ChevronRight className="size-4 text-[#555]" />
              </div>
            </button>
            <button className="text-left rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex p-4 flex-col gap-1">
              <div className="flex items-center gap-2">
                <Save className="size-4 text-[oklch(0.708_0.15_295)]" />
                <span className="font-bold text-[#888] text-xs leading-4 tracking-[3.2px]">
                  DATA EXPORT / IMPORT
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[#e0e0e0] text-sm leading-5">
                  JSON, Markdown export
                </span>
                <ChevronRight className="size-4 text-[#555]" />
              </div>
            </button>
            <button className="text-left rounded-xl bg-neutral-900 border-[#ff6467]/40 border-1 border-solid flex p-4 flex-col gap-1">
              <div className="flex items-center gap-2">
                <TriangleAlert className="size-4 text-[#ff6467]" />
                <span className="font-bold text-[#ff6467] text-xs leading-4 tracking-[3.2px]">
                  DANGER ZONE
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[#e0e0e0] text-sm leading-5">
                  Wipe all data, reset app
                </span>
                <ChevronRight className="size-4 text-[#ff6467]/60" />
              </div>
            </button>
            <button className="text-left rounded-xl bg-neutral-900/50 border-white/10 border-1 border-dashed flex p-4 flex-col gap-1">
              <div className="flex items-center gap-2">
                <MoreHorizontal className="size-4 text-[#555]" />
                <span className="font-bold text-[#555] text-xs leading-4 tracking-[3.2px]">
                  XYZ ( reserved )
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[#555] text-sm leading-5">
                  Future settings land here
                </span>
                <ChevronRight className="size-4 text-[#555]" />
              </div>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
