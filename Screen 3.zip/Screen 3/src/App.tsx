import { useEffect } from "react";
import {
  ArrowUp,
  MessageSquare,
  Mic,
  MoreVertical,
  PanelLeft,
  Plus,
  RefreshCw,
  Zap,
} from "lucide-react";

export default function App() {
  return (
    <div>
      <div className="font-mono bg-neutral-950 text-neutral-50 w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <div className="bg-[#0d0d0d] text-[#e0e0e0] flex p-2 flex-col w-full h-218.5">
          <div className="shrink-0 pt-2">
            <div className="rounded-sm text-sm leading-5 border-[#444] border-1 border-solid flex px-3 py-2.5 justify-between items-center">
              <div className="flex items-center gap-2">
                <PanelLeft className="size-5 text-[#e0e0e0]" />
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[#e0e0e0]">gpt-4o-mini</span>
                <RefreshCw className="size-4 text-violet-400" />
              </div>
              <div className="flex items-center gap-3">
                <MessageSquare className="size-5 text-[#e0e0e0]" />
                <MoreVertical className="size-5 text-[#e0e0e0]" />
              </div>
            </div>
            <div className="whitespace-nowrap text-[#444] text-xs leading-4 tracking-tighter pt-2 overflow-hidden">
              ════════════════════════════════════════════
            </div>
          </div>
          <div className="leading-tight text-xs leading-4 flex px-1 py-4 flex-col flex-1 gap-6 overflow-hidden">
            <div className="flex flex-col items-start">
              <pre className="whitespace-pre text-[#888]" />
            </div>
            <div className="flex flex-col items-end">
              <pre className="whitespace-pre text-violet-400" />
            </div>
            <div className="flex flex-col items-start">
              <pre className="whitespace-pre text-[#888]" />
            </div>
          </div>
          <div className="shrink-0">
            <div className="whitespace-nowrap text-[#444] text-xs leading-4 tracking-tighter overflow-hidden">
              ════════════════════════════════════════════
            </div>
            <div className="rounded-sm text-[#666] text-sm leading-5 border-[#444] border-1 border-solid flex mt-2 p-3 items-center">
              <span className="truncate">
                Type a message...........................
              </span>
            </div>
            <div className="flex mt-3 pb-2 justify-between items-center">
              <div className="flex items-center gap-2">
                <div className="size-10 rounded-sm border-[#444] border-1 border-solid flex justify-center items-center">
                  <Plus className="size-5 text-[#e0e0e0]" />
                </div>
                <div className="size-10 rounded-sm border-[#444] border-1 border-solid flex justify-center items-center">
                  <Zap className="size-5 text-violet-400" />
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="size-10 rounded-sm border-[#444] border-1 border-solid flex justify-center items-center">
                  <Mic className="size-5 text-[#e0e0e0]" />
                </div>
                <div className="size-10 rounded-sm bg-violet-400/15 border-violet-400 border-1 border-solid flex justify-center items-center">
                  <ArrowUp className="size-5 text-violet-400" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
