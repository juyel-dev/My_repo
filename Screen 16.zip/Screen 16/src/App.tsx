import { useEffect } from "react";
import {
  ArrowLeft,
  Bell,
  Brain,
  ChevronDown,
  MessageCircle,
  UserCircle,
} from "lucide-react";
import { Switch } from "@/components/ui/switch";

export default function App() {
  return (
    <div>
      <div className="bg-[oklch(0.10_0_0)] font-mono text-neutral-50 w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <div className="sticky z-10 bg-neutral-950 border-white/10 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex top-0 px-4 py-3 items-center gap-3">
          <button className="rounded-full text-neutral-400 flex justify-center items-center w-8 h-8">
            <ArrowLeft className="size-4" />
          </button>
          <span className="font-mono font-bold text-center text-neutral-50 text-sm leading-5 tracking-tight flex-1">{`Memory & Personalization`}</span>
          <div className="w-8" />
        </div>
        <div className="flex p-4 flex-col gap-4">
          <div className="rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex px-4 py-3 flex-col gap-3">
            <div className="flex mb-1 items-center gap-2">
              <Brain className="size-3 text-[oklch(0.708_0.15_295)]" />
              <span className="text-[oklch(0.708_0.15_295)] font-mono font-bold uppercase text-[10px] tracking-widest">
                // MEMORY
              </span>
            </div>
            <div className="flex flex-col gap-1">
              <div className="flex justify-between items-center">
                <span className="font-mono text-neutral-50 text-sm leading-5">
                  Persistent Memory
                </span>
                <Switch className="scale-75" defaultChecked={true} />
              </div>
              <span className="font-mono text-neutral-600 text-[10px]">
                // retains context across sessions
              </span>
            </div>
            <div className="bg-white/5 w-full h-px" />
            <div className="flex flex-col gap-1">
              <div className="flex justify-between items-center">
                <span className="font-mono text-neutral-50 text-sm leading-5">
                  Session Memory
                </span>
                <Switch className="scale-75" defaultChecked={true} />
              </div>
              <span className="font-mono text-neutral-600 text-[10px]">
                // active within current session only
              </span>
            </div>
            <div className="bg-white/5 w-full h-px" />
            <div className="flex flex-col gap-1">
              <div className="flex justify-between items-center">
                <div className="flex flex-col gap-0.5">
                  <span className="font-mono text-neutral-50 text-sm leading-5">
                    Memory Limit
                  </span>
                  <span className="font-mono text-neutral-600 text-[10px]">
                    // max stored memory entries
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-neutral-500 text-[10px]">
                    App Default
                  </span>
                  <span className="text-[oklch(0.45_0_0)] font-mono font-bold rounded-full bg-neutral-800 text-[9px] tracking-widest px-2 py-0.5">
                    OFF
                  </span>
                </div>
              </div>
            </div>
            <div className="bg-white/5 w-full h-px" />
            <div className="flex flex-col gap-1">
              <div className="flex justify-between items-center">
                <span className="font-mono text-neutral-50 text-sm leading-5">
                  Auto-Summarize
                </span>
                <Switch className="scale-75" defaultChecked={true} />
              </div>
              <span className="font-mono text-neutral-600 text-[10px]">
                // compresses old context automatically
              </span>
            </div>
            <div className="bg-white/5 w-full h-px" />
            <div className="flex flex-col gap-1">
              <div className="flex justify-between items-center">
                <span className="font-mono text-neutral-50 text-sm leading-5">
                  Memory Search
                </span>
                <Switch className="scale-75" />
              </div>
              <span className="font-mono text-neutral-600 text-[10px]">
                // enables semantic search over memory
              </span>
            </div>
          </div>
          <div className="rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex px-4 py-3 flex-col gap-3">
            <div className="flex mb-1 items-center gap-2">
              <UserCircle className="size-3 text-[oklch(0.708_0.15_295)]" />
              <span className="text-[oklch(0.708_0.15_295)] font-mono font-bold uppercase text-[10px] tracking-widest">
                // PERSONALIZATION
              </span>
            </div>
            <div className="flex flex-col gap-1">
              <span className="font-mono uppercase text-neutral-500 text-[10px] tracking-widest">
                Display Name
              </span>
              <input
                className="outline-none font-mono rounded-lg bg-neutral-950 text-neutral-50 text-xs leading-4 border-white/10 border-1 border-solid px-3 py-2 w-full"
                placeholder="// your name or alias"
              />
            </div>
            <div className="flex flex-col gap-1">
              <span className="font-mono uppercase text-neutral-500 text-[10px] tracking-widest">
                User Bio
              </span>
              <textarea
                className="outline-none resize-none font-mono rounded-lg bg-neutral-950 text-neutral-50 text-xs leading-4 border-white/10 border-1 border-solid px-3 py-2 w-full"
                rows={2}
                placeholder="// brief description of yourself..."
              />
            </div>
            <div className="flex flex-col gap-1">
              <span className="font-mono uppercase text-neutral-500 text-[10px] tracking-widest">
                Preferred Language
              </span>
              <div className="rounded-lg bg-neutral-950 border-white/10 border-1 border-solid flex px-3 py-2 justify-between items-center">
                <span className="font-mono text-neutral-50 text-xs leading-4">
                  English
                </span>
                <ChevronDown className="size-3 text-neutral-400" />
              </div>
            </div>
            <div className="flex flex-col gap-1">
              <span className="font-mono uppercase text-neutral-500 text-[10px] tracking-widest">{`Date & Time Format`}</span>
              <div className="flex gap-2">
                <div className="bg-[oklch(0.708_0.15_295)] text-[oklch(0.10_0_0)] font-mono font-bold rounded-lg text-xs leading-4 flex py-1.5 justify-center items-center flex-1">
                  12h
                </div>
                <div className="font-mono rounded-lg bg-neutral-800 text-neutral-400 text-xs leading-4 flex py-1.5 justify-center items-center flex-1">
                  24h
                </div>
              </div>
            </div>
            <div className="flex flex-col gap-1">
              <span className="font-mono uppercase text-neutral-500 text-[10px] tracking-widest">
                First Day of Week
              </span>
              <div className="flex gap-2">
                <div className="bg-[oklch(0.708_0.15_295)] text-[oklch(0.10_0_0)] font-mono font-bold rounded-lg text-xs leading-4 flex py-1.5 justify-center items-center flex-1">
                  Mon
                </div>
                <div className="font-mono rounded-lg bg-neutral-800 text-neutral-400 text-xs leading-4 flex py-1.5 justify-center items-center flex-1">
                  Sun
                </div>
                <div className="font-mono rounded-lg bg-neutral-800 text-neutral-400 text-xs leading-4 flex py-1.5 justify-center items-center flex-1">
                  Sat
                </div>
              </div>
            </div>
          </div>
          <div className="rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex px-4 py-3 flex-col gap-3">
            <div className="flex mb-1 items-center gap-2">
              <MessageCircle className="size-3 text-[oklch(0.708_0.15_295)]" />
              <span className="text-[oklch(0.708_0.15_295)] font-mono font-bold uppercase text-[10px] tracking-widest">
                // CHAT PREFERENCES
              </span>
            </div>
            <div className="flex flex-col gap-1">
              <span className="font-mono uppercase text-neutral-500 text-[10px] tracking-widest">
                Default System Prompt
              </span>
              <textarea
                className="outline-none resize-none font-mono rounded-lg bg-neutral-950 text-neutral-50 text-xs leading-4 border-white/10 border-1 border-solid px-3 py-2 w-full"
                rows={3}
                placeholder="// global fallback system prompt..."
              />
            </div>
            <div className="bg-white/5 w-full h-px" />
            <div className="flex flex-col gap-1">
              <div className="flex justify-between items-center">
                <span className="font-mono text-neutral-50 text-sm leading-5">
                  Send on Enter
                </span>
                <Switch className="scale-75" defaultChecked={true} />
              </div>
            </div>
            <div className="bg-white/5 w-full h-px" />
            <div className="flex flex-col gap-1">
              <div className="flex justify-between items-center">
                <span className="font-mono text-neutral-50 text-sm leading-5">
                  Show Token Count
                </span>
                <Switch className="scale-75" defaultChecked={true} />
              </div>
            </div>
            <div className="bg-white/5 w-full h-px" />
            <div className="flex flex-col gap-1">
              <div className="flex justify-between items-center">
                <span className="font-mono text-neutral-50 text-sm leading-5">
                  Show Model Badge
                </span>
                <Switch className="scale-75" defaultChecked={true} />
              </div>
            </div>
            <div className="bg-white/5 w-full h-px" />
            <div className="flex flex-col gap-1">
              <div className="flex justify-between items-center">
                <span className="font-mono text-neutral-50 text-sm leading-5">
                  Typing Indicator
                </span>
                <Switch className="scale-75" />
              </div>
            </div>
            <div className="bg-white/5 w-full h-px" />
            <div className="flex flex-col gap-1">
              <div className="flex justify-between items-center">
                <span className="font-mono text-neutral-50 text-sm leading-5">
                  Auto-Scroll to Bottom
                </span>
                <Switch className="scale-75" defaultChecked={true} />
              </div>
            </div>
          </div>
          <div className="rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex px-4 py-3 flex-col gap-3">
            <div className="flex mb-1 items-center gap-2">
              <Bell className="size-3 text-[oklch(0.708_0.15_295)]" />
              <span className="text-[oklch(0.708_0.15_295)] font-mono font-bold uppercase text-[10px] tracking-widest">
                // NOTIFICATIONS
              </span>
            </div>
            <div className="flex flex-col gap-1">
              <div className="flex justify-between items-center">
                <span className="font-mono text-neutral-50 text-sm leading-5">
                  Enable Notifications
                </span>
                <Switch className="scale-75" defaultChecked={true} />
              </div>
            </div>
            <div className="bg-white/5 w-full h-px" />
            <div className="flex flex-col gap-1">
              <div className="flex justify-between items-center">
                <span className="font-mono text-neutral-50 text-sm leading-5">
                  Sound Alerts
                </span>
                <Switch className="scale-75" />
              </div>
            </div>
            <div className="bg-white/5 w-full h-px" />
            <div className="flex flex-col gap-1">
              <div className="flex justify-between items-center">
                <span className="font-mono text-neutral-50 text-sm leading-5">
                  Haptic Feedback
                </span>
                <Switch className="scale-75" defaultChecked={true} />
              </div>
            </div>
            <div className="bg-white/5 w-full h-px" />
            <div className="flex flex-col gap-1">
              <div className="flex justify-between items-center">
                <span className="font-mono text-neutral-50 text-sm leading-5">
                  Badge Count
                </span>
                <Switch className="scale-75" defaultChecked={true} />
              </div>
            </div>
          </div>
          <div className="h-4" />
        </div>
      </div>
    </div>
  );
}
