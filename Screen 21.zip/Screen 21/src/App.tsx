import { useEffect } from "react";
import {
  ArrowUp,
  Bot,
  ChevronDown,
  Copy,
  Mic,
  MoreVertical,
  Paperclip,
  RefreshCw,
  Search,
  Server,
  Share2,
} from "lucide-react";

export default function App() {
  return (
    <div>
      <div className="bg-neutral-950 text-neutral-50 w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <div className="min-h-[874px] font-mono bg-[#0d0d0d] text-neutral-50 flex flex-col w-full">
          <div className="sticky z-20 bg-neutral-950 border-white/10 border-t-0 border-r-0 border-b-1 border-l-0 border-solid top-0 px-4 py-3">
            <div className="flex justify-between items-center gap-3">
              <button className="text-left rounded-lg bg-neutral-900 border-white/10 border-1 border-solid flex px-3 py-2 items-center gap-2">
                <div className="rounded-md bg-violet-400/10 text-violet-400 flex justify-center items-center w-8 h-8">
                  <Bot className="size-4" />
                </div>
                <div className="leading-none flex flex-col">
                  <span className="font-semibold text-neutral-50 text-sm leading-5">
                    ResearchBot
                  </span>
                  <span className="text-neutral-400 text-[10px]">gpt-4o</span>
                </div>
                <ChevronDown className="size-4 text-neutral-400 ml-1" />
              </button>
              <div className="flex items-center gap-2">
                <button className="rounded-full bg-neutral-900 text-neutral-400 border-white/10 border-1 border-solid flex justify-center items-center w-8 h-8">
                  <Search className="size-4" />
                </button>
                <button className="relative rounded-full bg-neutral-900 text-neutral-400 border-white/10 border-1 border-solid flex justify-center items-center w-8 h-8">
                  <Server className="size-4" />
                  <span className="rounded-full bg-emerald-400 absolute right-1 top-1 w-2 h-2" />
                </button>
                <button className="rounded-full bg-neutral-900 text-neutral-400 border-white/10 border-1 border-solid flex justify-center items-center w-8 h-8">
                  <MoreVertical className="size-4" />
                </button>
              </div>
            </div>
          </div>
          <div className="flex-1 overflow-hidden">
            <div className="overflow-y-auto px-4 py-3 h-full">
              <div className="flex pb-4 flex-col gap-4">
                <div className="flex justify-end">
                  <div className="max-w-[84%] rounded-tl-2xl rounded-tr-2xl rounded-bl-2xl rounded-br-sm bg-violet-400/15 text-neutral-50 text-sm leading-5 border-violet-400/20 border-1 border-solid px-3 py-2">
                    <div>
                      // What are the latest AI research papers on reasoning
                      models?
                    </div>
                    <div className="text-right text-neutral-600 text-[9px] mt-1">
                      10:42 AM
                    </div>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <div className="shrink-0 rounded-full bg-neutral-800 text-violet-400 flex mt-1 justify-center items-center w-7 h-7">
                    <Bot className="size-4" />
                  </div>
                  <div className="max-w-[84%]">
                    <div className="rounded-tl-2xl rounded-tr-2xl rounded-bl-sm rounded-br-2xl bg-neutral-900 text-neutral-300 text-sm leading-5 border-white/10 border-1 border-solid px-3 py-2">
                      <div className="font-semibold uppercase text-violet-400 text-[10px] tracking-widest">
                        // Reasoning Models — Recent Papers
                      </div>
                      <div className="space-y-1 text-neutral-300 text-xs leading-4 mt-2">
                        <div>
                          1. Chain-of-Thought Prompting — Google DeepMind, 2025
                        </div>
                        <div>
                          2. DeepSeek-R1: Incentivizing Reasoning — DeepSeek AI,
                          Jan 2025
                        </div>
                        <div>
                          3. OpenAI o3 Technical Report — OpenAI, Feb 2025
                        </div>
                      </div>
                      <div className="text-neutral-500 text-[10px] mt-2">
                        // 3 results via brave-search MCP · 847 tokens
                      </div>
                    </div>
                    <div className="text-neutral-600 flex mt-2 px-1 items-center gap-3">
                      <button className="text-[10px] flex items-center gap-1">
                        <Copy className="size-3.5" />
                        <span>Copy</span>
                      </button>
                      <button className="text-[10px] flex items-center gap-1">
                        <RefreshCw className="size-3.5" />
                        <span>Retry</span>
                      </button>
                      <button className="text-[10px] flex items-center gap-1">
                        <Share2 className="size-3.5" />
                        <span>Share</span>
                      </button>
                    </div>
                  </div>
                </div>
                <div className="flex justify-end">
                  <div className="max-w-[84%] rounded-tl-2xl rounded-tr-2xl rounded-bl-2xl rounded-br-sm bg-violet-400/15 text-neutral-50 text-sm leading-5 border-violet-400/20 border-1 border-solid px-3 py-2">
                    <div>
                      // Can you show me the code for implementing
                      chain-of-thought?
                    </div>
                    <div className="text-right text-neutral-600 text-[9px] mt-1">
                      10:43 AM
                    </div>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <div className="shrink-0 rounded-full bg-neutral-800 text-violet-400 flex mt-1 justify-center items-center w-7 h-7">
                    <Bot className="size-4" />
                  </div>
                  <div className="max-w-[84%]">
                    <div className="rounded-tl-2xl rounded-tr-2xl rounded-bl-sm rounded-br-2xl bg-neutral-900 text-neutral-300 text-sm leading-5 border-white/10 border-1 border-solid px-3 py-2">
                      <div className="flex mb-2 justify-between items-center">
                        <span className="font-semibold uppercase text-violet-400 text-[10px] tracking-widest">
                          // Python
                        </span>
                        <button className="text-neutral-600">
                          <Copy className="size-3.5" />
                        </button>
                      </div>
                      <div className="rounded-xl bg-neutral-950 text-violet-300 text-xs leading-4 border-violet-400/20 border-1 border-solid px-3 py-2">
                        <div>def answer(prompt):</div>
                        <div>reasoning = think_step_by_step(prompt)</div>
                        <div>final = summarize_reasoning(reasoning)</div>
                        <div>return final</div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex justify-end">
                  <div className="max-w-[84%] rounded-tl-2xl rounded-tr-2xl rounded-bl-2xl rounded-br-sm bg-violet-400/15 text-neutral-50 text-sm leading-5 border-violet-400/20 border-1 border-solid px-3 py-2">
                    <div>// Summarize this in a table format</div>
                    <div className="text-right text-neutral-600 text-[9px] mt-1">
                      10:44 AM
                    </div>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <div className="shrink-0 rounded-full bg-neutral-800 text-violet-400 flex mt-1 justify-center items-center w-7 h-7">
                    <Bot className="size-4" />
                  </div>
                  <div className="rounded-tl-2xl rounded-tr-2xl rounded-bl-sm rounded-br-2xl bg-neutral-900 border-white/10 border-1 border-solid px-4 py-3">
                    <div className="flex gap-1">
                      <div className="animate-pulse rounded-full bg-neutral-500 w-2 h-2" />
                      <div className="animate-pulse rounded-full bg-neutral-500 w-2 h-2" />
                      <div className="animate-pulse rounded-full bg-neutral-500 w-2 h-2" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="sticky z-20 bg-neutral-950 border-white/10 border-t-1 border-r-0 border-b-0 border-l-0 border-solid bottom-0 p-3">
            <div className="text-neutral-600 text-[9px] flex mb-2 px-1 justify-between items-center">
              <span>// 847 / 128k tokens</span>
              <span>ResearchBot</span>
            </div>
            <div className="rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid flex px-3 py-2 items-center gap-2">
              <button className="text-neutral-500">
                <Paperclip className="size-4" />
              </button>
              <button className="text-neutral-500">
                <Mic className="size-4" />
              </button>
              <div className="text-neutral-400 text-sm leading-5 flex-1">
                // message ResearchBot...
              </div>
              <button className="text-violet-foreground rounded-xl bg-violet-400 flex justify-center items-center w-8 h-8">
                <ArrowUp className="size-4" />
              </button>
            </div>
            <div className="overflow-x-auto flex mt-2 pb-1 gap-2">
              <button className="whitespace-nowrap rounded-full bg-neutral-900 text-neutral-400 text-[10px] border-white/10 border-1 border-solid px-3 py-1">
                // summarize
              </button>
              <button className="whitespace-nowrap rounded-full bg-neutral-900 text-neutral-400 text-[10px] border-white/10 border-1 border-solid px-3 py-1">
                // explain
              </button>
              <button className="whitespace-nowrap rounded-full bg-neutral-900 text-neutral-400 text-[10px] border-white/10 border-1 border-solid px-3 py-1">
                // translate
              </button>
              <button className="whitespace-nowrap rounded-full bg-neutral-900 text-neutral-400 text-[10px] border-white/10 border-1 border-solid px-3 py-1">
                // code review
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
