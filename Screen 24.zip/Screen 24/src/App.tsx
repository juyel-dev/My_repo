import { useEffect } from "react";
import {
  AlertTriangle,
  ArrowLeft,
  Database,
  Key,
  LogOut,
  RefreshCw,
  RotateCcw,
  Shield,
  Trash2,
  UserX,
  X,
} from "lucide-react";

export default function App() {
  return (
    <div>
      <div className="bg-neutral-950 text-neutral-50 w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <div className="relative font-mono w-full">
          <div className="font-mono bg-[#0d0d0d] w-full">
            <div className="sticky z-10 bg-neutral-950 border-white/10 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex top-0 px-4 py-3 items-center">
              <button className="rounded-full bg-neutral-900 flex justify-center items-center w-8 h-8">
                <ArrowLeft className="size-4 text-neutral-400" />
              </button>
              <span className="font-mono font-bold text-center text-neutral-50 text-sm leading-5 flex-1">
                Danger Zone
              </span>
              <AlertTriangle className="size-4 text-red-400" />
            </div>
            <div className="pointer-events-none select-none opacity-30 flex px-4 pt-4 pb-8 flex-col gap-4">
              <div className="rounded-xl bg-red-500/8 border-red-500/25 border-1 border-solid flex px-4 py-3 flex-row items-start gap-3">
                <AlertTriangle className="size-4 shrink-0 text-red-400 mt-0.5" />
                <div className="flex flex-col gap-1">
                  <span className="font-mono font-bold uppercase text-red-400 text-[10px] tracking-widest">
                    // IRREVERSIBLE ACTIONS
                  </span>
                  <span className="font-mono text-neutral-400 text-[10px]">
                    // these actions cannot be undone. proceed with extreme
                    caution.
                  </span>
                </div>
              </div>
              <div className="rounded-xl bg-neutral-900 border-red-500/15 border-1 border-solid overflow-hidden">
                <div className="border-white/10 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex px-4 py-3 flex-row items-center gap-2">
                  <Trash2 className="size-3 text-red-400" />
                  <span className="font-mono font-bold uppercase text-red-400 text-[10px] tracking-widest">
                    // CLEAR DATA
                  </span>
                </div>
                <div className="divide-y divide-white/5 flex flex-col">
                  <div className="flex px-4 py-3 flex-row items-center gap-3">
                    <Trash2 className="size-4 shrink-0 text-red-400" />
                    <div className="flex flex-col flex-1 gap-0.5">
                      <span className="font-mono text-neutral-50 text-sm leading-5">
                        Clear All Chat History
                      </span>
                      <span className="font-mono text-neutral-600 text-[10px]">
                        // permanently deletes all conversations
                      </span>
                    </div>
                    <button className="font-mono font-bold rounded-lg bg-red-500/8 text-red-400 text-[11px] border-red-500/40 border-1 border-solid px-3 py-1.5">
                      CLEAR
                    </button>
                  </div>
                  <div className="flex px-4 py-3 flex-row items-center gap-3">
                    <Trash2 className="size-4 shrink-0 text-red-400" />
                    <div className="flex flex-col flex-1 gap-0.5">
                      <span className="font-mono text-neutral-50 text-sm leading-5">
                        Clear Model Configs
                      </span>
                      <span className="font-mono text-neutral-600 text-[10px]">
                        // removes all saved model configurations
                      </span>
                    </div>
                    <button className="font-mono font-bold rounded-lg bg-red-500/8 text-red-400 text-[11px] border-red-500/40 border-1 border-solid px-3 py-1.5">
                      CLEAR
                    </button>
                  </div>
                  <div className="flex px-4 py-3 flex-row items-center gap-3">
                    <Trash2 className="size-4 shrink-0 text-red-400" />
                    <div className="flex flex-col flex-1 gap-0.5">
                      <span className="font-mono text-neutral-50 text-sm leading-5">
                        Clear Agent Configs
                      </span>
                      <span className="font-mono text-neutral-600 text-[10px]">
                        // removes all configured agents
                      </span>
                    </div>
                    <button className="font-mono font-bold rounded-lg bg-red-500/8 text-red-400 text-[11px] border-red-500/40 border-1 border-solid px-3 py-1.5">
                      CLEAR
                    </button>
                  </div>
                  <div className="flex px-4 py-3 flex-row items-center gap-3">
                    <Trash2 className="size-4 shrink-0 text-red-400" />
                    <div className="flex flex-col flex-1 gap-0.5">
                      <span className="font-mono text-neutral-50 text-sm leading-5">
                        Clear MCP Configs
                      </span>
                      <span className="font-mono text-neutral-600 text-[10px]">
                        // removes all MCP server configurations
                      </span>
                    </div>
                    <button className="font-mono font-bold rounded-lg bg-red-500/8 text-red-400 text-[11px] border-red-500/40 border-1 border-solid px-3 py-1.5">
                      CLEAR
                    </button>
                  </div>
                </div>
              </div>
              <div className="rounded-xl bg-neutral-900 border-red-500/15 border-1 border-solid overflow-hidden">
                <div className="border-white/10 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex px-4 py-3 flex-row items-center gap-2">
                  <RotateCcw className="size-3 text-red-400" />
                  <span className="font-mono font-bold uppercase text-red-400 text-[10px] tracking-widest">
                    // RESET APP
                  </span>
                </div>
                <div className="divide-y divide-white/5 flex flex-col">
                  <div className="flex px-4 py-3 flex-row items-center gap-3">
                    <RotateCcw className="size-4 shrink-0 text-amber-400" />
                    <div className="flex flex-col flex-1 gap-0.5">
                      <span className="font-mono text-neutral-50 text-sm leading-5">
                        Reset All Settings
                      </span>
                      <span className="font-mono text-neutral-600 text-[10px]">
                        // restores all settings to factory defaults
                      </span>
                    </div>
                    <button className="font-mono font-bold rounded-lg bg-amber-400/8 text-amber-400 text-[11px] border-amber-400/40 border-1 border-solid px-3 py-1.5">
                      RESET
                    </button>
                  </div>
                  <div className="flex px-4 py-3 flex-row items-center gap-3">
                    <RefreshCw className="size-4 shrink-0 text-neutral-400" />
                    <div className="flex flex-col flex-1 gap-0.5">
                      <span className="font-mono text-neutral-50 text-sm leading-5">
                        Reset Onboarding
                      </span>
                      <span className="font-mono text-neutral-600 text-[10px]">
                        // re-runs the first-time setup flow
                      </span>
                    </div>
                    <button className="font-mono font-bold rounded-lg text-neutral-400 text-[11px] border-white/20 border-1 border-solid px-3 py-1.5">
                      RESET
                    </button>
                  </div>
                  <div className="flex px-4 py-3 flex-row items-center gap-3">
                    <Database className="size-4 shrink-0 text-violet-400" />
                    <div className="flex flex-col flex-1 gap-0.5">
                      <span className="font-mono text-neutral-50 text-sm leading-5">
                        Rebuild Local Index
                      </span>
                      <span className="font-mono text-neutral-600 text-[10px]">
                        // re-indexes all local data for search
                      </span>
                    </div>
                    <button className="font-mono font-bold rounded-lg bg-violet-400/8 text-violet-400 text-[11px] border-violet-400/40 border-1 border-solid px-3 py-1.5">
                      RUN
                    </button>
                  </div>
                </div>
              </div>
              <div className="rounded-xl bg-neutral-900 border-red-500/15 border-1 border-solid overflow-hidden">
                <div className="border-white/10 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex px-4 py-3 flex-row items-center gap-2">
                  <Shield className="size-3 text-red-400" />
                  <span className="font-mono font-bold uppercase text-red-400 text-[10px] tracking-widest">
                    // ACCOUNT
                  </span>
                </div>
                <div className="divide-y divide-white/5 flex flex-col">
                  <div className="flex px-4 py-3 flex-row items-center gap-3">
                    <Key className="size-4 shrink-0 text-red-400" />
                    <div className="flex flex-col flex-1 gap-0.5">
                      <span className="font-mono text-neutral-50 text-sm leading-5">
                        Revoke All API Keys
                      </span>
                      <span className="font-mono text-neutral-600 text-[10px]">
                        // invalidates all stored provider API keys
                      </span>
                    </div>
                    <button className="font-mono font-bold rounded-lg bg-red-500/8 text-red-400 text-[11px] border-red-500/40 border-1 border-solid px-3 py-1.5">
                      REVOKE
                    </button>
                  </div>
                  <div className="flex px-4 py-3 flex-row items-center gap-3">
                    <LogOut className="size-4 shrink-0 text-neutral-400" />
                    <div className="flex flex-col flex-1 gap-0.5">
                      <span className="font-mono text-neutral-50 text-sm leading-5">
                        Sign Out
                      </span>
                      <span className="font-mono text-neutral-600 text-[10px]">
                        // logs out of NeuralKey account
                      </span>
                    </div>
                    <button className="font-mono font-bold rounded-lg text-neutral-400 text-[11px] border-white/20 border-1 border-solid px-3 py-1.5">
                      SIGN OUT
                    </button>
                  </div>
                  <div className="flex px-4 py-3 flex-row items-center gap-3">
                    <UserX className="size-4 shrink-0 text-red-400" />
                    <div className="flex flex-col flex-1 gap-0.5">
                      <span className="font-mono text-neutral-50 text-sm leading-5">
                        Delete Account
                      </span>
                      <span className="font-mono text-red-400/70 text-[10px]">
                        // permanently deletes your account and all data
                      </span>
                    </div>
                    <button className="font-mono font-bold rounded-lg bg-red-500/20 text-red-400 text-[11px] border-red-500/50 border-1 border-solid px-3 py-1.5">
                      DELETE
                    </button>
                  </div>
                </div>
              </div>
              <div className="font-mono text-center text-neutral-700 text-[10px] py-2">
                // NeuralKey v2.1.0 · build 20250115 · all data stored locally
              </div>
            </div>
          </div>
          <div className="z-20 bg-black/70 absolute inset-0" />
          <div className="z-30 rounded-t-2xl bg-neutral-900 border-white/10 border-t-1 border-r-0 border-b-0 border-l-0 border-solid flex absolute inset-x-0 bottom-0 flex-col">
            <div className="flex pt-3 pb-1 justify-center">
              <div className="rounded-full bg-neutral-700 w-10 h-1" />
            </div>
            <div className="flex mt-4 px-4 flex-col items-center">
              <div className="rounded-full bg-red-500/10 border-red-500/20 border-1 border-solid flex justify-center items-center w-14 h-14">
                <AlertTriangle className="size-7 text-red-400" />
              </div>
            </div>
            <div className="text-center mt-3 px-6">
              <span className="font-mono font-bold text-neutral-50 text-base leading-6">
                Clear All Chat History
              </span>
            </div>
            <div className="text-center mt-2 px-6">
              <span className="leading-relaxed font-mono text-neutral-400 text-[11px]">
                // This will permanently delete all 847 conversations and cannot
                be undone. This action is irreversible.
              </span>
            </div>
            <div className="rounded-xl bg-red-500/8 border-red-500/20 border-1 border-solid flex mx-4 mt-4 px-4 py-3 flex-col gap-2">
              <div className="flex flex-row items-center gap-2">
                <X className="size-3 shrink-0 text-red-400" />
                <span className="font-mono text-neutral-400 text-[10px]">
                  847 conversations will be deleted
                </span>
              </div>
              <div className="flex flex-row items-center gap-2">
                <X className="size-3 shrink-0 text-red-400" />
                <span className="font-mono text-neutral-400 text-[10px]">
                  All message history permanently removed
                </span>
              </div>
              <div className="flex flex-row items-center gap-2">
                <X className="size-3 shrink-0 text-red-400" />
                <span className="font-mono text-neutral-400 text-[10px]">
                  MCP tool call logs will be cleared
                </span>
              </div>
            </div>
            <div className="flex mx-4 mt-4 flex-col gap-1.5">
              <span className="font-mono text-neutral-500 text-[10px]">
                // type DELETE to confirm
              </span>
              <div className="rounded-xl bg-neutral-950 border-red-500/30 border-1 border-solid px-3 py-2.5 w-full">
                <span className="font-mono text-red-400/40 text-sm leading-5">
                  // DELETE
                </span>
              </div>
            </div>
            <div className="flex mx-4 mt-4 pb-8 flex-col gap-3">
              <button className="opacity-40 rounded-xl bg-red-500/20 border-red-500/50 border-1 border-solid flex justify-center items-center gap-2 w-full h-12">
                <Trash2 className="size-4 text-red-400" />
                <span className="font-mono font-bold text-red-400 text-sm leading-5">
                  Confirm — Clear All History
                </span>
              </button>
              <button className="rounded-xl border-white/15 border-1 border-solid flex justify-center items-center w-full h-11">
                <span className="font-mono text-neutral-400 text-sm leading-5">
                  Cancel
                </span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
