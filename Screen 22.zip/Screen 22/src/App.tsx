import { useEffect } from "react";
import { ArrowRight, Brain, Key, Server, Shield } from "lucide-react";

export default function App() {
  return (
    <div>
      <div className="min-h-[874px] font-mono bg-[#0d0d0d] text-neutral-50 flex flex-col w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <div className="flex px-6 pt-16 pb-8 flex-col items-center">
          <div className="rounded-2xl bg-neutral-900 border-white/10 border-1 border-solid flex mb-4 justify-center items-center w-18 h-18">
            <Brain className="size-10 text-[oklch(0.708_0.15_295)]" />
          </div>
          <h1 className="font-mono font-bold text-neutral-50 text-2xl leading-8 tracking-tight mb-1">
            NeuralKey
          </h1>
          <p className="font-mono uppercase text-neutral-500 text-[11px] tracking-widest">
            // BYOK AI CHAT · POWER USER EDITION
          </p>
        </div>
        <div className="flex px-6 flex-col flex-1 gap-6">
          <div className="bg-[oklch(0.708_0.15_295/0.05)] border-[oklch(0.708_0.15_295/0.15)] rounded-2xl border-black/1 border-1 border-solid flex px-4 py-5 flex-col gap-4">
            <div className="flex flex-row items-start gap-3">
              <div className="bg-[oklch(0.708_0.15_295/0.12)] shrink-0 rounded-lg flex mt-0.5 justify-center items-center w-8 h-8">
                <Key className="size-4 text-[oklch(0.708_0.15_295)]" />
              </div>
              <div className="flex flex-col gap-0.5">
                <span className="font-mono font-bold text-neutral-50 text-sm leading-5">
                  BYOK — Bring Your Own Keys
                </span>
                <span className="font-mono text-neutral-500 text-[10px]">
                  // your API keys, your data, zero middleman
                </span>
              </div>
            </div>
            <div className="bg-white/5 w-full h-px" />
            <div className="flex flex-row items-start gap-3">
              <div className="bg-[oklch(0.708_0.15_295/0.12)] shrink-0 rounded-lg flex mt-0.5 justify-center items-center w-8 h-8">
                <Brain className="size-4 text-[oklch(0.708_0.15_295)]" />
              </div>
              <div className="flex flex-col gap-0.5">
                <span className="font-mono font-bold text-neutral-50 text-sm leading-5">
                  Multi-Agent Orchestration
                </span>
                <span className="font-mono text-neutral-500 text-[10px]">{`// configure agents with custom tools & memory`}</span>
              </div>
            </div>
            <div className="bg-white/5 w-full h-px" />
            <div className="flex flex-row items-start gap-3">
              <div className="bg-[oklch(0.708_0.15_295/0.12)] shrink-0 rounded-lg flex mt-0.5 justify-center items-center w-8 h-8">
                <Server className="size-4 text-[oklch(0.708_0.15_295)]" />
              </div>
              <div className="flex flex-col gap-0.5">
                <span className="font-mono font-bold text-neutral-50 text-sm leading-5">
                  MCP Server Integration
                </span>
                <span className="font-mono text-neutral-500 text-[10px]">
                  // connect any MCP-compatible tool server
                </span>
              </div>
            </div>
            <div className="bg-white/5 w-full h-px" />
            <div className="flex flex-row items-start gap-3">
              <div className="bg-[oklch(0.708_0.15_295/0.12)] shrink-0 rounded-lg flex mt-0.5 justify-center items-center w-8 h-8">
                <Shield className="size-4 text-[oklch(0.708_0.15_295)]" />
              </div>
              <div className="flex flex-col gap-0.5">
                <span className="font-mono font-bold text-neutral-50 text-sm leading-5">
                  100% Local Storage
                </span>
                <span className="font-mono text-neutral-500 text-[10px]">
                  // all data stored on-device, never uploaded
                </span>
              </div>
            </div>
          </div>
          <div className="flex flex-row justify-center items-center gap-2">
            <div className="bg-[oklch(0.708_0.15_295)] rounded-full w-6 h-1.5" />
            <div className="rounded-full bg-neutral-700 w-1.5 h-1.5" />
            <div className="rounded-full bg-neutral-700 w-1.5 h-1.5" />
          </div>
        </div>
        <div className="flex mt-6 px-6 pb-10 flex-col gap-3">
          <button className="bg-[oklch(0.708_0.15_295)] rounded-xl flex justify-center items-center gap-2 w-full h-12">
            <span className="font-mono font-bold text-white text-sm leading-5">
              Get Started
            </span>
            <ArrowRight className="size-4 text-white" />
          </button>
          <p className="font-mono text-center text-neutral-600 text-[10px]">
            // no account required · works offline · open source
          </p>
        </div>
      </div>
    </div>
  );
}
