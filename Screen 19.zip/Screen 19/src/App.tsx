import { useEffect } from "react";
import {
  ArrowLeft,
  Bot,
  ChevronRight,
  ClipboardList,
  Download,
  FolderOpen,
  Globe,
  Link,
  MessageCircle,
  Share,
  Upload,
  Zap,
} from "lucide-react";
import { Switch } from "@/components/ui/switch";

export default function App() {
  return (
    <div>
      <div className="bg-[oklch(0.10_0_0)] font-mono text-neutral-50 w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <div className="sticky z-10 bg-neutral-950 border-white/10 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex top-0 px-4 py-3 items-center gap-3">
          <button className="rounded-full bg-neutral-900 border-white/10 border-1 border-solid flex justify-center items-center w-8 h-8">
            <ArrowLeft className="size-4 text-neutral-400" />
          </button>
          <span className="font-mono font-bold text-center text-neutral-50 text-sm leading-5 tracking-tight flex-1">{`Data Import & Export`}</span>
          <div className="w-8" />
        </div>
        <div className="flex p-4 flex-col gap-4">
          <div className="rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex px-4 py-3 flex-col gap-3">
            <div className="flex items-center gap-2">
              <Upload className="size-3.5 text-[oklch(0.708_0.15_295)]" />
              <span className="text-[oklch(0.708_0.15_295)] font-mono font-bold uppercase text-[10px] tracking-widest">
                // Export Data
              </span>
            </div>
            <div className="bg-[oklch(0.708_0.15_295)]/5 border-[oklch(0.708_0.15_295)]/20 rounded-lg border-black/1 border-1 border-solid px-3 py-2">
              <span className="font-mono text-neutral-400 text-[10px]">
                // export your chats, settings, and configurations as a portable
                backup
              </span>
            </div>
            <div className="flex flex-col gap-1">
              <span className="font-mono uppercase text-neutral-500 text-[10px] tracking-widest">
                Export Format
              </span>
              <div className="flex mt-1 gap-2">
                <button className="bg-[oklch(0.708_0.15_295)] border-[oklch(0.708_0.15_295)] font-mono font-bold rounded-lg text-white text-[11px] border-black/1 border-1 border-solid py-2 flex-1">
                  JSON
                </button>
                <button className="font-mono rounded-lg bg-neutral-800 text-neutral-400 text-[11px] border-white/10 border-1 border-solid py-2 flex-1">
                  Markdown
                </button>
                <button className="font-mono rounded-lg bg-neutral-800 text-neutral-400 text-[11px] border-white/10 border-1 border-solid py-2 flex-1">
                  CSV
                </button>
              </div>
            </div>
            <div className="flex flex-col gap-1">
              <span className="font-mono uppercase text-neutral-500 text-[10px] tracking-widest mb-1">
                Include in Export
              </span>
              <div className="flex flex-col gap-1.5">
                <div className="rounded-lg bg-neutral-950 border-white/10 border-1 border-solid flex px-3 py-2.5 justify-between items-center">
                  <span className="font-mono text-neutral-50 text-sm leading-5">
                    Chat History
                  </span>
                  <Switch className="scale-75" checked={true} />
                </div>
                <div className="rounded-lg bg-neutral-950 border-white/10 border-1 border-solid flex px-3 py-2.5 justify-between items-center">
                  <span className="font-mono text-neutral-50 text-sm leading-5">
                    Model Configs
                  </span>
                  <Switch className="scale-75" checked={true} />
                </div>
                <div className="rounded-lg bg-neutral-950 border-white/10 border-1 border-solid flex px-3 py-2.5 justify-between items-center">
                  <span className="font-mono text-neutral-50 text-sm leading-5">
                    Agent Configs
                  </span>
                  <Switch className="scale-75" checked={true} />
                </div>
                <div className="rounded-lg bg-neutral-950 border-white/10 border-1 border-solid flex px-3 py-2.5 justify-between items-center">
                  <span className="font-mono text-neutral-50 text-sm leading-5">
                    MCP Configs
                  </span>
                  <Switch className="scale-75" checked={true} />
                </div>
                <div className="rounded-lg bg-neutral-950 border-white/10 border-1 border-solid flex px-3 py-2.5 justify-between items-center">
                  <span className="font-mono text-neutral-400 text-sm leading-5">
                    App Settings
                  </span>
                  <Switch className="scale-75" />
                </div>
              </div>
            </div>
            <button className="bg-[oklch(0.708_0.15_295)] rounded-xl flex justify-center items-center gap-2 w-full h-11">
              <Download className="size-4 text-white" />
              <span className="font-mono font-bold text-white text-sm leading-5">
                Export All Data
              </span>
            </button>
          </div>
          <div className="rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex px-4 py-3 flex-col gap-3">
            <div className="flex items-center gap-2">
              <Download className="size-3.5 text-[oklch(0.708_0.15_295)]" />
              <span className="text-[oklch(0.708_0.15_295)] font-mono font-bold uppercase text-[10px] tracking-widest">
                // Import Data
              </span>
            </div>
            <div className="rounded-lg bg-neutral-800/50 border-white/10 border-1 border-solid px-3 py-2">
              <span className="font-mono text-neutral-500 text-[10px]">
                // import a previously exported NeuralKey backup file
              </span>
            </div>
            <div className="rounded-xl bg-neutral-950 border-white/15 border-2 border-dashed flex flex-col justify-center items-center gap-1 h-24">
              <FolderOpen className="size-5 text-neutral-500" />
              <span className="font-mono text-neutral-500 text-[11px]">
                // tap to select backup file
              </span>
              <span className="font-mono text-neutral-600 text-[10px]">
                .json / .zip supported
              </span>
            </div>
            <div className="flex flex-col gap-1">
              <div className="flex gap-2">
                <button className="bg-[oklch(0.708_0.15_295)] border-[oklch(0.708_0.15_295)] font-mono font-bold rounded-lg text-white text-[11px] border-black/1 border-1 border-solid py-2 flex-1">
                  Merge
                </button>
                <button className="font-mono rounded-lg bg-neutral-800 text-neutral-400 text-[11px] border-white/10 border-1 border-solid py-2 flex-1">
                  Replace
                </button>
              </div>
              <span className="font-mono text-neutral-600 text-[10px] mt-0.5">
                // merge keeps existing data, replace overwrites
              </span>
            </div>
            <button className="rounded-xl bg-neutral-950 border-white/20 border-1 border-solid flex justify-center items-center gap-2 w-full h-11">
              <Upload className="size-4 text-neutral-400" />
              <span className="font-mono text-neutral-300 text-sm leading-5">
                Select Import File
              </span>
            </button>
          </div>
          <div className="rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex px-4 py-3 flex-col gap-3">
            <div className="flex items-center gap-2">
              <Link className="size-3.5 text-[oklch(0.708_0.15_295)]" />
              <span className="text-[oklch(0.708_0.15_295)] font-mono font-bold uppercase text-[10px] tracking-widest">
                // Third-Party Import
              </span>
            </div>
            <div className="flex flex-col gap-1.5">
              <div className="rounded-lg bg-neutral-950 border-white/10 border-1 border-solid flex p-3 justify-between items-center">
                <div className="flex items-center gap-2">
                  <MessageCircle className="size-4 text-[oklch(0.708_0.15_295)]" />
                  <span className="font-mono text-neutral-50 text-sm leading-5">
                    Import from ChatGPT
                  </span>
                </div>
                <ChevronRight className="size-4 text-neutral-400" />
              </div>
              <div className="rounded-lg bg-neutral-950 border-white/10 border-1 border-solid flex p-3 justify-between items-center">
                <div className="flex items-center gap-2">
                  <Bot className="size-4 text-[oklch(0.708_0.15_295)]" />
                  <span className="font-mono text-neutral-50 text-sm leading-5">
                    Import from Claude
                  </span>
                </div>
                <ChevronRight className="size-4 text-neutral-400" />
              </div>
              <div className="rounded-lg bg-neutral-950 border-white/10 border-1 border-solid flex p-3 justify-between items-center">
                <div className="flex items-center gap-2">
                  <Zap className="size-4 text-[oklch(0.708_0.15_295)]" />
                  <span className="font-mono text-neutral-50 text-sm leading-5">
                    Import from OpenRouter
                  </span>
                </div>
                <ChevronRight className="size-4 text-neutral-400" />
              </div>
              <div className="rounded-lg bg-neutral-950 border-white/10 border-1 border-solid flex p-3 justify-between items-center">
                <div className="flex items-center gap-2">
                  <Globe className="size-4 text-[oklch(0.708_0.15_295)]" />
                  <span className="font-mono text-neutral-50 text-sm leading-5">
                    Import from Custom URL
                  </span>
                </div>
                <ChevronRight className="size-4 text-neutral-400" />
              </div>
            </div>
          </div>
          <div className="rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex px-4 py-3 flex-col gap-3">
            <div className="flex items-center gap-2">
              <ClipboardList className="size-3.5 text-[oklch(0.708_0.15_295)]" />
              <span className="text-[oklch(0.708_0.15_295)] font-mono font-bold uppercase text-[10px] tracking-widest">
                // Export History
              </span>
            </div>
            <div className="flex flex-col gap-1.5">
              <div className="rounded-lg bg-neutral-950 border-white/10 border-1 border-solid flex px-3 py-2.5 justify-between items-center">
                <div className="flex flex-col gap-0.5">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-neutral-50 text-xs leading-4">
                      Jan 15, 2025
                    </span>
                    <span className="bg-[oklch(0.708_0.15_295)]/10 text-[oklch(0.708_0.15_295)] font-mono uppercase rounded-full text-[10px] tracking-widest px-1.5 py-0.5">
                      JSON
                    </span>
                  </div>
                  <span className="font-mono text-neutral-400 text-[10px]">
                    2.4 MB
                  </span>
                </div>
                <Share className="size-4 text-neutral-400" />
              </div>
              <div className="rounded-lg bg-neutral-950 border-white/10 border-1 border-solid flex px-3 py-2.5 justify-between items-center">
                <div className="flex flex-col gap-0.5">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-neutral-50 text-xs leading-4">
                      Dec 28, 2024
                    </span>
                    <span className="bg-[oklch(0.708_0.15_295)]/10 text-[oklch(0.708_0.15_295)] font-mono uppercase rounded-full text-[10px] tracking-widest px-1.5 py-0.5">
                      Markdown
                    </span>
                  </div>
                  <span className="font-mono text-neutral-400 text-[10px]">
                    1.1 MB
                  </span>
                </div>
                <Share className="size-4 text-neutral-400" />
              </div>
              <div className="rounded-lg bg-neutral-950 border-white/10 border-1 border-solid flex px-3 py-2.5 justify-between items-center">
                <div className="flex flex-col gap-0.5">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-neutral-50 text-xs leading-4">
                      Dec 01, 2024
                    </span>
                    <span className="bg-[oklch(0.708_0.15_295)]/10 text-[oklch(0.708_0.15_295)] font-mono uppercase rounded-full text-[10px] tracking-widest px-1.5 py-0.5">
                      JSON
                    </span>
                  </div>
                  <span className="font-mono text-neutral-400 text-[10px]">
                    1.8 MB
                  </span>
                </div>
                <Share className="size-4 text-neutral-400" />
              </div>
            </div>
          </div>
          <div className="h-4" />
        </div>
      </div>
    </div>
  );
}
