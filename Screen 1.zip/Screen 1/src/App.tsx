import { useEffect } from "react";

export default function App() {
  return (
    <div>
      <div className="bg-neutral-950 text-neutral-50 w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <div className="min-h-[874px] font-mono flex px-8 py-12 flex-col justify-between items-center">
          <div className="flex pt-12 flex-col items-center gap-8 w-full">
            <div className="flex flex-col items-center gap-2 w-full">
              <pre className="leading-tight text-violet-400 text-[11px] tracking-tight" />
              <p className="text-[#a1a1a1] text-[11px] tracking-wide">
                // Your keys. Your models. Your data.
              </p>
            </div>
            <pre className="leading-none text-white/10 text-[10px]">
              ───────────────────────────────
            </pre>
            <div className="text-neutral-50/90 text-[13px] flex flex-col items-center gap-1">
              <p>A personal, private AI chat client.</p>
              <p>Bring your own API keys.</p>
              <p>No middleman. No telemetry.</p>
            </div>
            <pre className="leading-none text-white/10 text-[10px]">
              ───────────────────────────────
            </pre>
          </div>
          <div className="flex pb-8 flex-col items-center gap-6 w-full">
            <button className="group transition-opacity flex justify-center w-full">
              <pre className="leading-tight text-violet-400 text-xs" />
            </button>
            <button className="transition-colors text-[#a1a1a1] text-xs">
              // Already configured? → Open Chat
            </button>
          </div>
        </div>
        <div className="flex pb-8 justify-center">
          <p className="font-mono text-[#a1a1a1]/60 text-[10px] tracking-wide">
            v0.1.0-alpha | Personal Build
          </p>
        </div>
      </div>
    </div>
  );
}
