import { useEffect } from "react";
import { Bot, Menu, Settings, Sparkles, Star, X } from "lucide-react";

export default function App() {
  return (
    <div>
      <div className="bg-neutral-950 text-neutral-50 w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <div className="relative font-mono bg-neutral-950 w-100.5 h-218.5 overflow-hidden">
          <div className="bg-black/60 absolute inset-0" />
          <div className="w-[22%] bg-gradient-to-l from-transparent to-black/40 absolute right-0 top-0 h-full" />
          <div className="w-[78%] bg-[#1a1a1a] border-violet-400/30 border-t-0 border-r-1 border-b-0 border-l-0 border-solid flex absolute left-0 top-0 p-4 flex-col h-full">
            <div className="leading-tight text-[#555] text-[10px]">
              ╔════════════════════════════╗
            </div>
            <div className="flex -my-1 p-2 justify-between items-center">
              <div className="flex items-center gap-2">
                <Menu className="size-4 text-violet-400" />
                <span className="font-semibold text-[#e0e0e0] text-sm leading-5 tracking-wide">
                  NeuralKey
                </span>
              </div>
              <button className="size-7 rounded-sm text-[#e0e0e0] border-[#555] border-1 border-solid flex justify-center items-center">
                <X className="size-4" />
              </button>
            </div>
            <div className="leading-tight text-[#555] text-[10px]">
              ╚════════════════════════════╝
            </div>
            <button className="rounded-lg bg-violet-400/10 text-violet-400 text-sm leading-5 border-violet-400 border-1 border-solid flex mt-4 px-4 py-3 items-center gap-2 w-full">
              <Sparkles className="size-4" />
              <span>New Conversation</span>
            </button>
            <div className="text-[#555] text-[11px] flex mt-6 items-center gap-2">
              <span>──</span>
              <span className="text-[#777] tracking-widest">STARRED</span>
              <span className="truncate flex-1">──────────────</span>
            </div>
            <div className="flex mt-2 flex-col gap-1">
              <div className="rounded-sm text-[#e0e0e0] text-sm leading-5 flex p-2 justify-between items-center">
                <span>abc</span>
                <Star className="size-3.5 fill-[#a78bfa] text-violet-400" />
              </div>
              <div className="rounded-sm text-[#e0e0e0] text-sm leading-5 flex p-2 justify-between items-center">
                <span>klm</span>
                <Star className="size-3.5 fill-[#a78bfa] text-violet-400" />
              </div>
            </div>
            <div className="text-[#555] text-[11px] flex mt-6 items-center gap-2">
              <span>──</span>
              <span className="text-[#777] tracking-widest">RECENTS</span>
              <span className="truncate flex-1">──────────────</span>
            </div>
            <div className="flex mt-2 flex-col gap-0.5 overflow-hidden">
              <div className="text-[#555] text-sm leading-5 flex px-2 py-1.5 items-center gap-2">
                <span className="text-violet-400">·</span>
                <span>...xyz...</span>
              </div>
              <div className="text-[#555] text-sm leading-5 flex px-2 py-1.5 items-center gap-2">
                <span className="text-violet-400">·</span>
                <span>...pqr...</span>
              </div>
              <div className="text-[#555] text-sm leading-5 flex px-2 py-1.5 items-center gap-2">
                <span className="text-violet-400">·</span>
                <span>...mnl...</span>
              </div>
              <div className="text-[#555] text-sm leading-5 flex px-2 py-1.5 items-center gap-2">
                <span className="text-violet-400">·</span>
                <span className="truncate">Quantum computing chat</span>
              </div>
              <div className="text-[#555] text-sm leading-5 flex px-2 py-1.5 items-center gap-2">
                <span className="text-violet-400">·</span>
                <span className="truncate">API setup help</span>
              </div>
              <div className="text-[#555] text-sm leading-5 flex px-2 py-1.5 items-center gap-2">
                <span className="text-violet-400">·</span>
                <span className="truncate">Code review session</span>
              </div>
            </div>
            <div className="mt-auto pt-4">
              <div className="leading-tight truncate text-[#555] text-[10px]">
                ════════════════════════════
              </div>
              <div className="flex mt-3 items-center gap-2">
                <button className="rounded-lg text-[#e0e0e0] text-sm leading-5 border-violet-400/60 border-1 border-solid flex p-3 justify-center items-center flex-1 gap-2">
                  <Settings className="size-4 text-violet-400" />
                  <span>Settings</span>
                </button>
                <button className="rounded-lg text-[#e0e0e0] text-sm leading-5 border-violet-400/60 border-1 border-solid flex p-3 justify-center items-center flex-1 gap-2">
                  <Bot className="size-4 text-violet-400" />
                  <span>Agents</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
