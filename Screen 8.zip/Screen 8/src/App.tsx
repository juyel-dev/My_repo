import { useEffect } from "react";
import {
  ArrowLeft,
  ArrowRight,
  Box,
  Check,
  ChevronDown,
  Cpu,
  Globe,
  Key,
  KeyRound,
  Layers,
  Link,
  MessageCircle,
  Pencil,
  Plus,
  Settings,
  Tag,
  Trash2,
  Zap,
} from "lucide-react";
import { Switch } from "@/components/ui/switch";

export default function App() {
  return (
    <div>
      <div className="font-mono bg-neutral-950 text-neutral-50 w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <div className="min-h-[874px] bg-[oklch(0.08_0_0)] flex flex-col">
          <div className="border-[oklch(1_0_0/10%)] bg-[oklch(0.10_0_0)] sticky z-10 border-black/1 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex top-0 px-4 py-3 items-center gap-4">
            <button className="text-[oklch(0.985_0_0)] text-sm leading-5 flex items-center gap-1">
              <ArrowLeft className="size-4" />
              <span className="text-[oklch(0.708_0_0)] text-xs leading-4">
                Provider Settings
              </span>
            </button>
            <span className="text-[oklch(0.985_0_0)] font-bold text-center text-sm leading-5 tracking-wide flex-1">
              Add Custom Provider
            </span>
            <div className="w-20" />
          </div>
          <div className="overflow-y-auto flex px-4 pt-4 pb-24 flex-col flex-1 gap-4">
            <div className="flex mb-1 items-center gap-2">
              <Plus className="size-3.5 text-[oklch(0.708_0.15_295)]" />
              <span className="text-[oklch(0.708_0.15_295)] font-bold uppercase text-[10px] tracking-[2.88px]">
                // New Custom Provider
              </span>
            </div>
            <div className="bg-[oklch(0.13_0_0)] border-[oklch(1_0_0/10%)] rounded-xl border-black/1 border-1 border-solid overflow-hidden">
              <div className="border-[oklch(1_0_0/8%)] border-black/1 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex px-4 py-3 items-center gap-3">
                <Settings className="size-4 text-[oklch(0.708_0.15_295)]" />
                <span className="text-[oklch(0.708_0_0)] uppercase text-xs leading-4 tracking-widest">
                  Enable this service
                </span>
                <div className="ml-auto">
                  <Switch />
                </div>
              </div>
              <div className="flex px-4 py-3 flex-col gap-1">
                <span className="text-[oklch(0.708_0_0)] uppercase text-[10px] tracking-widest">
                  Custom Provider Name
                </span>
                <div className="bg-[oklch(0.17_0_0)] border-[oklch(1_0_0/12%)] rounded-lg border-black/1 border-1 border-solid flex mt-1 px-3 py-2 items-center gap-2">
                  <Tag className="size-3.5 text-[oklch(0.708_0_0)]" />
                  <input
                    className="bg-transparent text-[oklch(0.985_0_0)] placeholder-[oklch(0.45_0_0)] outline-none font-mono text-xs leading-4 flex-1"
                    placeholder="e.g. My Local LLM"
                  />
                </div>
              </div>
            </div>
            <div className="bg-[oklch(0.13_0_0)] border-[oklch(1_0_0/10%)] rounded-xl border-black/1 border-1 border-solid overflow-hidden">
              <div className="flex px-4 pt-3 pb-1 items-center gap-2">
                <Globe className="size-3.5 text-[oklch(0.708_0.15_295)]" />
                <span className="text-[oklch(0.708_0.15_295)] font-bold uppercase text-[10px] tracking-widest">
                  Base URL / API Host
                </span>
              </div>
              <div className="flex px-4 pt-1 pb-3 flex-col gap-1">
                <div className="bg-[oklch(0.17_0_0)] border-[oklch(1_0_0/12%)] rounded-lg border-black/1 border-1 border-solid flex px-3 py-2 items-center gap-2">
                  <Link className="size-3.5 text-[oklch(0.708_0_0)]" />
                  <input
                    className="bg-transparent text-[oklch(0.985_0_0)] placeholder-[oklch(0.45_0_0)] outline-none font-mono text-xs leading-4 flex-1"
                    placeholder="https://api.example.com/v1"
                  />
                </div>
                <span className="text-[oklch(0.45_0_0)] text-[10px] mt-1">
                  // Leave blank to use provider default
                </span>
              </div>
            </div>
            <div className="bg-[oklch(0.13_0_0)] border-[oklch(1_0_0/10%)] rounded-xl border-black/1 border-1 border-solid overflow-hidden">
              <div className="flex px-4 pt-3 pb-1 items-center gap-2">
                <Layers className="size-3.5 text-[oklch(0.708_0.15_295)]" />
                <span className="text-[oklch(0.708_0.15_295)] font-bold uppercase text-[10px] tracking-widest">
                  API Type
                </span>
              </div>
              <div className="px-4 pt-1 pb-3">
                <div className="bg-[oklch(0.17_0_0)] border-[oklch(1_0_0/12%)] rounded-lg border-black/1 border-1 border-solid flex px-3 py-2 justify-between items-center gap-2">
                  <span className="text-[oklch(0.708_0_0)] font-mono text-xs leading-4">
                    OpenAI Compatible
                  </span>
                  <ChevronDown className="size-3.5 text-[oklch(0.708_0_0)]" />
                </div>
                <div className="flex mt-2 flex-col gap-1">
                  <div className="bg-[oklch(0.17_0_0)] border-[oklch(0.708_0.15_295)/40%] rounded-md border-black/1 border-1 border-solid flex px-3 py-1.5 items-center gap-2">
                    <div className="size-2 bg-[oklch(0.708_0.15_295)] rounded-full" />
                    <span className="text-[oklch(0.985_0_0)] font-mono text-xs leading-4">
                      OpenAI Compatible
                    </span>
                  </div>
                  <div className="bg-[oklch(0.17_0_0)] border-[oklch(1_0_0/8%)] rounded-md border-black/1 border-1 border-solid flex px-3 py-1.5 items-center gap-2">
                    <div className="size-2 bg-[oklch(0.35_0_0)] rounded-full" />
                    <span className="text-[oklch(0.708_0_0)] font-mono text-xs leading-4">
                      Anthropic
                    </span>
                  </div>
                  <div className="bg-[oklch(0.17_0_0)] border-[oklch(1_0_0/8%)] rounded-md border-black/1 border-1 border-solid flex px-3 py-1.5 items-center gap-2">
                    <div className="size-2 bg-[oklch(0.35_0_0)] rounded-full" />
                    <span className="text-[oklch(0.708_0_0)] font-mono text-xs leading-4">
                      Google Gemini
                    </span>
                  </div>
                  <div className="bg-[oklch(0.17_0_0)] border-[oklch(1_0_0/8%)] rounded-md border-black/1 border-1 border-solid flex px-3 py-1.5 items-center gap-2">
                    <div className="size-2 bg-[oklch(0.35_0_0)] rounded-full" />
                    <span className="text-[oklch(0.708_0_0)] font-mono text-xs leading-4">
                      Ollama (Local)
                    </span>
                  </div>
                  <div className="bg-[oklch(0.17_0_0)] border-[oklch(1_0_0/8%)] rounded-md border-black/1 border-1 border-solid flex px-3 py-1.5 items-center gap-2">
                    <div className="size-2 bg-[oklch(0.35_0_0)] rounded-full" />
                    <span className="text-[oklch(0.708_0_0)] font-mono text-xs leading-4">
                      Custom / Raw HTTP
                    </span>
                  </div>
                </div>
                <span className="block text-[oklch(0.45_0_0)] text-[10px] mt-2">{`// determines request format & auth header`}</span>
              </div>
            </div>
            <div className="bg-[oklch(0.13_0_0)] border-[oklch(1_0_0/10%)] rounded-xl border-black/1 border-1 border-solid overflow-hidden">
              <div className="flex px-4 pt-3 pb-1 justify-between items-center">
                <div className="flex items-center gap-2">
                  <KeyRound className="size-3.5 text-[oklch(0.708_0.15_295)]" />
                  <span className="text-[oklch(0.708_0.15_295)] font-bold uppercase text-[10px] tracking-widest">
                    API Key
                  </span>
                </div>
                <button className="text-[oklch(0.708_0.15_295)] border-[oklch(0.708_0.15_295)/40%] font-mono rounded-md text-[10px] border-black/1 border-1 border-solid px-2 py-0.5">
                  + Add
                </button>
              </div>
              <div className="px-4 py-1">
                <div className="bg-[oklch(0.17_0_0)] border-[oklch(1_0_0/12%)] rounded-lg border-black/1 border-1 border-solid flex px-3 py-2 items-center gap-2">
                  <Key className="size-3.5 text-[oklch(0.708_0_0)]" />
                  <input
                    className="bg-transparent text-[oklch(0.985_0_0)] placeholder-[oklch(0.45_0_0)] outline-none font-mono text-xs leading-4 flex-1"
                    placeholder="sk-••••••••••••••••"
                  />
                </div>
                <span className="block text-[oklch(0.45_0_0)] text-[10px] mt-1.5 mb-2">
                  // stored securely on-device only
                </span>
              </div>
            </div>
            <div className="bg-[oklch(0.13_0_0)] border-[oklch(1_0_0/10%)] rounded-xl border-black/1 border-1 border-solid overflow-hidden">
              <div className="flex px-4 pt-3 pb-2 justify-between items-center">
                <div className="flex items-center gap-2">
                  <Cpu className="size-3.5 text-[oklch(0.708_0.15_295)]" />
                  <span className="text-[oklch(0.708_0.15_295)] font-bold uppercase text-[10px] tracking-widest">
                    Custom Models
                  </span>
                </div>
                <button className="text-[oklch(0.708_0.15_295)] border-[oklch(0.708_0.15_295)/40%] font-mono rounded-md text-[10px] border-black/1 border-1 border-solid flex px-2 py-0.5 items-center gap-1">
                  <Plus className="size-3" />
                  Add Model
                </button>
              </div>
              <div className="flex px-4 pb-3 flex-col gap-2">
                <div className="bg-[oklch(0.17_0_0)] border-[oklch(1_0_0/12%)] rounded-lg border-black/1 border-1 border-solid flex px-3 py-2 items-center gap-2">
                  <Box className="size-3.5 text-[oklch(0.708_0_0)]" />
                  <input
                    className="bg-transparent text-[oklch(0.985_0_0)] placeholder-[oklch(0.45_0_0)] outline-none font-mono text-xs leading-4 flex-1"
                    placeholder="model-name-or-id"
                  />
                  <button className="ml-auto">
                    <Plus className="size-3.5 text-[oklch(0.708_0.15_295)]" />
                  </button>
                </div>
                <div className="bg-[oklch(0.17_0_0)] border-[oklch(0.708_0.15_295)/30%] rounded-lg border-black/1 border-1 border-solid flex px-3 py-2 items-center gap-2">
                  <div className="size-1.5 bg-[oklch(0.708_0.15_295)] rounded-full" />
                  <span className="text-[oklch(0.985_0_0)] font-mono text-xs leading-4 flex-1">
                    my-custom-model-v1
                  </span>
                  <button className="bg-[oklch(0.708_0.15_295)/15%] rounded-full p-1">
                    <Pencil className="size-3 text-[oklch(0.708_0.15_295)]" />
                  </button>
                  <button className="bg-[oklch(0.704_0.191_22.216)/15%] rounded-full p-1">
                    <Trash2 className="size-3 text-[oklch(0.704_0.191_22.216)]" />
                  </button>
                </div>
                <span className="text-[oklch(0.45_0_0)] text-[10px]">
                  // add model IDs exposed by this endpoint
                </span>
              </div>
            </div>
            <div className="flex mt-1 gap-2">
              <button className="border-[oklch(1_0_0/12%)] bg-[oklch(0.13_0_0)] text-[oklch(0.708_0_0)] font-mono rounded-xl text-xs leading-4 tracking-wide border-black/1 border-1 border-solid flex px-4 py-3 justify-center items-center flex-1 gap-2">
                <Zap className="size-3.5" />
                Test Endpoint
              </button>
              <button className="bg-[oklch(0.708_0.15_295)] text-[oklch(0.985_0_0)] font-mono font-bold rounded-xl text-xs leading-4 tracking-wide flex px-4 py-3 justify-center items-center flex-1 gap-2">
                <Check className="size-3.5" />
                Save Provider
                <ArrowRight className="size-3.5" />
              </button>
            </div>
            <div className="text-center">
              <span className="text-[oklch(0.45_0_0)] font-mono text-[10px]">
                // Status: waiting for input.
              </span>
            </div>
          </div>
          <div className="fixed border-[oklch(1_0_0/10%)] bg-[oklch(0.10_0_0)] border-black/1 border-t-1 border-r-0 border-b-0 border-l-0 border-solid flex inset-x-0 bottom-0 px-4 py-2 flex-row justify-around items-center">
            <button className="flex px-4 py-1 flex-col items-center gap-1">
              <MessageCircle className="size-5 text-[oklch(0.708_0_0)]" />
              <span className="text-[oklch(0.708_0_0)] font-mono text-[10px]">
                Chats
              </span>
            </button>
            <button className="flex px-4 py-1 flex-col items-center gap-1">
              <Settings className="size-5 text-[oklch(0.985_0_0)]" />
              <span className="text-[oklch(0.985_0_0)] font-mono text-[10px]">
                Settings
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
