# Screen 20

This is a code bundle for Screen 20. It's based on default Vite project. The original design is available at https://app.flowstep.ai/file?activeFileId=d073a8ab-59fe-42a1-9e5c-1a24fb760569.

## Running the code

Run `npm i` and `npm run setup` to install the dependencies.

Run `npm run dev` to start the development server.
