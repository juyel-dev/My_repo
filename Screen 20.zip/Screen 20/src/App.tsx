import { useEffect } from "react";
import {
  AlertTriangle,
  ArrowLeft,
  Database,
  KeyRound,
  LogOut,
  RefreshCw,
  RotateCcw,
  Shield,
  Trash2,
  UserX,
} from "lucide-react";

export default function App() {
  return (
    <div>
      <div className="bg-[oklch(0.10_0_0)] font-mono text-neutral-50 w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <div className="sticky z-10 bg-neutral-950 border-white/10 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex top-0 px-4 py-3 items-center gap-3">
          <button className="rounded-lg text-neutral-400 flex justify-center items-center w-8 h-8">
            <ArrowLeft className="size-4" />
          </button>
          <div className="flex justify-center items-center flex-1 gap-2">
            <span className="font-mono font-bold text-neutral-50 text-sm leading-5 tracking-tight">
              Danger Zone
            </span>
            <AlertTriangle className="size-3.5 text-red-400" />
          </div>
          <div className="w-8 h-8" />
        </div>
        <div className="flex p-4 flex-col gap-4">
          <div className="rounded-xl bg-red-500/8 border-red-500/25 border-1 border-solid flex px-4 py-3 flex-col gap-1.5">
            <div className="flex items-center gap-2">
              <AlertTriangle className="size-4 shrink-0 text-red-400" />
              <span className="font-mono font-bold text-red-400 text-sm leading-5">
                // IRREVERSIBLE ACTIONS
              </span>
            </div>
            <span className="font-mono text-neutral-500 text-[10px]">
              // these actions cannot be undone. proceed with extreme caution.
            </span>
          </div>
          <div className="flex flex-col gap-2">
            <div className="flex px-1 items-center gap-2">
              <Trash2 className="size-3 text-red-400" />
              <span className="font-mono uppercase text-red-400 text-[10px] tracking-widest">
                🗑️ // CLEAR DATA
              </span>
            </div>
            <div className="rounded-xl bg-neutral-900 border-red-500/15 border-1 border-solid flex px-3 py-2 flex-col gap-2">
              <div className="rounded-lg bg-neutral-950 border-white/10 border-1 border-solid flex p-3 justify-between items-center gap-2">
                <div className="min-w-0 flex items-start flex-1 gap-2">
                  <Trash2 className="size-3.5 shrink-0 text-red-400/70 mt-0.5" />
                  <div className="min-w-0 flex flex-col gap-0.5">
                    <span className="leading-tight font-mono text-neutral-50 text-sm leading-5">
                      Clear All Chat History
                    </span>
                    <span className="block font-mono text-neutral-600 text-[10px]">
                      // permanently deletes all conversations
                    </span>
                  </div>
                </div>
                <button className="shrink-0 font-mono font-bold rounded-lg bg-red-500/8 text-red-400 text-[11px] border-red-500/40 border-1 border-solid px-3 py-1.5">
                  CLEAR
                </button>
              </div>
              <div className="rounded-lg bg-neutral-950 border-white/10 border-1 border-solid flex p-3 justify-between items-center gap-2">
                <div className="min-w-0 flex items-start flex-1 gap-2">
                  <Trash2 className="size-3.5 shrink-0 text-red-400/70 mt-0.5" />
                  <div className="min-w-0 flex flex-col gap-0.5">
                    <span className="leading-tight font-mono text-neutral-50 text-sm leading-5">
                      Clear Model Configs
                    </span>
                    <span className="block font-mono text-neutral-600 text-[10px]">
                      // removes all saved model configurations
                    </span>
                  </div>
                </div>
                <button className="shrink-0 font-mono font-bold rounded-lg bg-red-500/8 text-red-400 text-[11px] border-red-500/40 border-1 border-solid px-3 py-1.5">
                  CLEAR
                </button>
              </div>
              <div className="rounded-lg bg-neutral-950 border-white/10 border-1 border-solid flex p-3 justify-between items-center gap-2">
                <div className="min-w-0 flex items-start flex-1 gap-2">
                  <Trash2 className="size-3.5 shrink-0 text-red-400/70 mt-0.5" />
                  <div className="min-w-0 flex flex-col gap-0.5">
                    <span className="leading-tight font-mono text-neutral-50 text-sm leading-5">
                      Clear Agent Configs
                    </span>
                    <span className="block font-mono text-neutral-600 text-[10px]">
                      // removes all configured agents
                    </span>
                  </div>
                </div>
                <button className="shrink-0 font-mono font-bold rounded-lg bg-red-500/8 text-red-400 text-[11px] border-red-500/40 border-1 border-solid px-3 py-1.5">
                  CLEAR
                </button>
              </div>
              <div className="rounded-lg bg-neutral-950 border-white/10 border-1 border-solid flex p-3 justify-between items-center gap-2">
                <div className="min-w-0 flex items-start flex-1 gap-2">
                  <Trash2 className="size-3.5 shrink-0 text-red-400/70 mt-0.5" />
                  <div className="min-w-0 flex flex-col gap-0.5">
                    <span className="leading-tight font-mono text-neutral-50 text-sm leading-5">
                      Clear MCP Configs
                    </span>
                    <span className="block font-mono text-neutral-600 text-[10px]">
                      // removes all MCP server configurations
                    </span>
                  </div>
                </div>
                <button className="shrink-0 font-mono font-bold rounded-lg bg-red-500/8 text-red-400 text-[11px] border-red-500/40 border-1 border-solid px-3 py-1.5">
                  CLEAR
                </button>
              </div>
            </div>
          </div>
          <div className="flex flex-col gap-2">
            <div className="flex px-1 items-center gap-2">
              <RotateCcw className="size-3 text-red-400" />
              <span className="font-mono uppercase text-red-400 text-[10px] tracking-widest">
                ⚙️ // RESET APP
              </span>
            </div>
            <div className="rounded-xl bg-neutral-900 border-red-500/15 border-1 border-solid flex px-3 py-2 flex-col gap-2">
              <div className="rounded-lg bg-neutral-950 border-white/10 border-1 border-solid flex p-3 justify-between items-center gap-2">
                <div className="min-w-0 flex items-start flex-1 gap-2">
                  <RotateCcw className="size-3.5 shrink-0 text-amber-400/70 mt-0.5" />
                  <div className="min-w-0 flex flex-col gap-0.5">
                    <span className="leading-tight font-mono text-neutral-50 text-sm leading-5">
                      Reset All Settings
                    </span>
                    <span className="block font-mono text-neutral-600 text-[10px]">
                      // restores all settings to factory defaults
                    </span>
                  </div>
                </div>
                <button className="shrink-0 font-mono font-bold rounded-lg bg-amber-400/8 text-amber-400 text-[11px] border-amber-400/40 border-1 border-solid px-3 py-1.5">
                  RESET
                </button>
              </div>
              <div className="rounded-lg bg-neutral-950 border-white/10 border-1 border-solid flex p-3 justify-between items-center gap-2">
                <div className="min-w-0 flex items-start flex-1 gap-2">
                  <RefreshCw className="size-3.5 shrink-0 text-neutral-400/70 mt-0.5" />
                  <div className="min-w-0 flex flex-col gap-0.5">
                    <span className="leading-tight font-mono text-neutral-50 text-sm leading-5">
                      Reset Onboarding
                    </span>
                    <span className="block font-mono text-neutral-600 text-[10px]">
                      // re-runs the first-time setup flow
                    </span>
                  </div>
                </div>
                <button className="shrink-0 font-mono rounded-lg bg-neutral-950 text-neutral-400 text-[11px] border-white/20 border-1 border-solid px-3 py-1.5">
                  RESET
                </button>
              </div>
              <div className="rounded-lg bg-neutral-950 border-white/10 border-1 border-solid flex p-3 justify-between items-center gap-2">
                <div className="min-w-0 flex items-start flex-1 gap-2">
                  <Database className="size-3.5 shrink-0 text-violet-400/70 mt-0.5" />
                  <div className="min-w-0 flex flex-col gap-0.5">
                    <span className="leading-tight font-mono text-neutral-50 text-sm leading-5">
                      Rebuild Local Index
                    </span>
                    <span className="block font-mono text-neutral-600 text-[10px]">
                      // re-indexes all local data for search
                    </span>
                  </div>
                </div>
                <button className="shrink-0 border-[oklch(0.708_0.15_295)]/40 bg-[oklch(0.708_0.15_295)]/8 text-[oklch(0.708_0.15_295)] font-mono rounded-lg text-[11px] border-black/1 border-1 border-solid px-3 py-1.5">
                  RUN
                </button>
              </div>
            </div>
          </div>
          <div className="flex flex-col gap-2">
            <div className="flex px-1 items-center gap-2">
              <Shield className="size-3 text-red-400" />
              <span className="font-mono uppercase text-red-400 text-[10px] tracking-widest">
                🔐 // ACCOUNT
              </span>
            </div>
            <div className="rounded-xl bg-neutral-900 border-red-500/15 border-1 border-solid flex px-3 py-2 flex-col gap-2">
              <div className="rounded-lg bg-neutral-950 border-white/10 border-1 border-solid flex p-3 justify-between items-center gap-2">
                <div className="min-w-0 flex items-start flex-1 gap-2">
                  <KeyRound className="size-3.5 shrink-0 text-red-400/70 mt-0.5" />
                  <div className="min-w-0 flex flex-col gap-0.5">
                    <span className="leading-tight font-mono text-neutral-50 text-sm leading-5">
                      Revoke All API Keys
                    </span>
                    <span className="block font-mono text-neutral-600 text-[10px]">
                      // invalidates all stored provider API keys
                    </span>
                  </div>
                </div>
                <button className="shrink-0 font-mono font-bold rounded-lg bg-red-500/8 text-red-400 text-[11px] border-red-500/40 border-1 border-solid px-3 py-1.5">
                  REVOKE
                </button>
              </div>
              <div className="rounded-lg bg-neutral-950 border-white/10 border-1 border-solid flex p-3 justify-between items-center gap-2">
                <div className="min-w-0 flex items-start flex-1 gap-2">
                  <LogOut className="size-3.5 shrink-0 text-neutral-400/70 mt-0.5" />
                  <div className="min-w-0 flex flex-col gap-0.5">
                    <span className="leading-tight font-mono text-neutral-50 text-sm leading-5">
                      Sign Out
                    </span>
                    <span className="block font-mono text-neutral-600 text-[10px]">
                      // logs out of NeuralKey account
                    </span>
                  </div>
                </div>
                <button className="shrink-0 font-mono rounded-lg bg-neutral-950 text-neutral-400 text-[11px] border-white/20 border-1 border-solid px-3 py-1.5">
                  SIGN OUT
                </button>
              </div>
              <div className="rounded-lg bg-neutral-950 border-red-500/30 border-1 border-solid flex p-3 justify-between items-center gap-2">
                <div className="min-w-0 flex items-start flex-1 gap-2">
                  <UserX className="size-3.5 shrink-0 text-red-400/70 mt-0.5" />
                  <div className="min-w-0 flex flex-col gap-0.5">
                    <span className="leading-tight font-mono text-neutral-50 text-sm leading-5">
                      Delete Account
                    </span>
                    <span className="block font-mono text-red-400/70 text-[10px]">
                      // permanently deletes your account and all data
                    </span>
                  </div>
                </div>
                <button className="shrink-0 font-mono font-bold rounded-lg bg-red-500/20 text-red-400 text-[11px] border-red-500/50 border-1 border-solid px-3 py-1.5">
                  DELETE
                </button>
              </div>
            </div>
          </div>
          <div className="flex pt-2 pb-6 justify-center items-center">
            <span className="font-mono text-center text-neutral-700 text-[10px]">
              // NeuralKey v2.1.0 · build 20250115 · all data stored locally
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
