import { useEffect } from "react";
import {
  ArrowLeft,
  BarChart2,
  CheckCircle,
  ChevronRight,
  Copy,
  Cpu,
  Eye,
  Globe,
  Key,
  MoreVertical,
  Settings2,
  Sparkles,
} from "lucide-react";
import { Switch } from "@/components/ui/switch";

export default function App() {
  return (
    <div>
      <div className="font-mono bg-[#0d0d0d] text-neutral-50 w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <div className="sticky z-10 bg-neutral-950 border-white/10 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex top-0 px-4 py-3 justify-between items-center">
          <button className="rounded-full bg-neutral-900 text-neutral-400 flex justify-center items-center w-8 h-8">
            <ArrowLeft className="size-4" />
          </button>
          <span className="font-mono font-bold text-neutral-50 text-base leading-6">
            OpenAI
          </span>
          <button className="rounded-full bg-neutral-900 text-neutral-400 flex justify-center items-center w-8 h-8">
            <MoreVertical className="size-4" />
          </button>
        </div>
        <div className="bg-neutral-900 border-white/10 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex p-4 items-center gap-3">
          <div className="flex-shrink-0 rounded-xl bg-neutral-800 border-white/10 border-1 border-solid flex justify-center items-center w-10 h-10">
            <Sparkles className="size-5 text-[oklch(0.708_0.15_295)]" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="font-mono font-bold text-neutral-50 text-sm leading-5">
              OpenAI
            </div>
            <div className="font-mono text-neutral-500 text-[10px]">
              openai.com · GPT-4o, o3, DALL·E
            </div>
            <div className="flex mt-0.5 items-center gap-1">
              <div className="rounded-full bg-emerald-400 w-1.5 h-1.5" />
              <span className="font-mono text-emerald-400 text-[10px]">
                Connected
              </span>
            </div>
          </div>
          <Switch className="scale-75" defaultChecked={true} />
        </div>
        <div className="flex px-4 pt-4 pb-8 flex-col gap-4">
          <div className="rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex p-4 flex-col gap-3">
            <div className="flex items-center gap-2">
              <Key className="size-3 text-[oklch(0.708_0.15_295)]" />
              <span className="text-[oklch(0.708_0.15_295)] font-mono uppercase text-[10px] tracking-widest">
                // Authentication
              </span>
            </div>
            <div className="flex flex-col gap-2">
              <div className="relative flex items-center">
                <input
                  className="outline-none font-mono rounded-xl bg-neutral-950 text-neutral-300 text-sm leading-5 border-white/10 border-1 border-solid pl-3 pr-16 py-2.5 w-full"
                  defaultValue="••••••••••••••••sk-...4f2a"
                />
              </div>
              <div className="rounded-xl bg-neutral-950 border-white/10 border-1 border-solid flex px-3 py-2.5 justify-between items-center">
                <span className="truncate font-mono text-neutral-300 text-sm leading-5 flex-1">
                  ••••••••••••••••sk-...4f2a
                </span>
                <div className="flex ml-2 items-center gap-2">
                  <Eye className="size-4 flex-shrink-0 text-neutral-500" />
                  <Copy className="size-4 flex-shrink-0 text-neutral-500" />
                </div>
              </div>
              <input
                className="outline-none font-mono rounded-xl bg-neutral-950 text-neutral-600 text-sm leading-5 border-white/10 border-1 border-solid px-3 py-2.5 w-full"
                placeholder="// optional org ID"
              />
              <button className="font-mono rounded-xl text-neutral-300 text-sm leading-5 border-white/20 border-1 border-solid flex justify-center items-center gap-2 w-full h-10">
                <CheckCircle className="size-4" />
                Verify API Key
              </button>
              <div className="flex items-center gap-1.5">
                <CheckCircle className="size-3 text-emerald-400" />
                <span className="font-mono text-emerald-400 text-[10px]">
                  ✓ Valid · Last checked 5m ago
                </span>
              </div>
            </div>
          </div>
          <div className="rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex p-4 flex-col gap-3">
            <div className="flex items-center gap-2">
              <Cpu className="size-3 text-[oklch(0.708_0.15_295)]" />
              <span className="text-[oklch(0.708_0.15_295)] font-mono uppercase text-[10px] tracking-widest">
                // Available Models
              </span>
            </div>
            <input
              className="outline-none font-mono rounded-xl bg-neutral-950 text-neutral-400 text-xs leading-4 border-white/10 border-1 border-solid px-3 py-2 w-full"
              placeholder="// filter models..."
            />
            <div className="flex flex-col gap-2">
              <div className="rounded-lg bg-neutral-950 border-white/10 border-1 border-solid flex px-3 py-2.5 justify-between items-center gap-2">
                <span className="font-mono font-bold text-neutral-50 text-sm leading-5 flex-1">
                  gpt-4o
                </span>
                <span className="uppercase rounded-full bg-neutral-800 text-neutral-400 text-[9px] tracking-widest px-2 py-0.5">
                  128k
                </span>
                <Switch className="scale-75" defaultChecked={true} />
              </div>
              <div className="rounded-lg bg-neutral-950 border-white/10 border-1 border-solid flex px-3 py-2.5 justify-between items-center gap-2">
                <span className="font-mono font-bold text-neutral-50 text-sm leading-5 flex-1">
                  gpt-4o-mini
                </span>
                <span className="uppercase rounded-full bg-neutral-800 text-neutral-400 text-[9px] tracking-widest px-2 py-0.5">
                  128k
                </span>
                <Switch className="scale-75" defaultChecked={true} />
              </div>
              <div className="rounded-lg bg-neutral-950 border-white/10 border-1 border-solid flex px-3 py-2.5 justify-between items-center gap-2">
                <span className="font-mono font-bold text-neutral-50 text-sm leading-5 flex-1">
                  o3-mini
                </span>
                <span className="uppercase rounded-full bg-neutral-800 text-neutral-400 text-[9px] tracking-widest px-2 py-0.5">
                  200k
                </span>
                <Switch className="scale-75" defaultChecked={true} />
              </div>
              <div className="rounded-lg bg-neutral-950 border-white/10 border-1 border-solid flex px-3 py-2.5 justify-between items-center gap-2">
                <span className="font-mono font-bold text-neutral-400 text-sm leading-5 flex-1">
                  gpt-4-turbo
                </span>
                <span className="uppercase rounded-full bg-neutral-800 text-neutral-500 text-[9px] tracking-widest px-2 py-0.5">
                  128k
                </span>
                <Switch className="scale-75" />
              </div>
              <div className="rounded-lg bg-neutral-950 border-white/10 border-1 border-solid flex px-3 py-2.5 justify-between items-center gap-2">
                <span className="font-mono font-bold text-neutral-400 text-sm leading-5 flex-1">
                  gpt-3.5-turbo
                </span>
                <span className="uppercase rounded-full bg-neutral-800 text-neutral-500 text-[9px] tracking-widest px-2 py-0.5">
                  16k
                </span>
                <Switch className="scale-75" />
              </div>
              <div className="rounded-lg bg-neutral-950 border-white/10 border-1 border-solid flex px-3 py-2.5 justify-between items-center gap-2">
                <span className="font-mono font-bold text-neutral-400 text-sm leading-5 flex-1">
                  dall-e-3
                </span>
                <span className="uppercase rounded-full bg-neutral-800 text-neutral-500 text-[9px] tracking-widest px-2 py-0.5">
                  image
                </span>
                <Switch className="scale-75" />
              </div>
            </div>
          </div>
          <div className="rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex p-4 flex-col gap-3">
            <div className="flex items-center gap-2">
              <Globe className="size-3 text-[oklch(0.708_0.15_295)]" />
              <span className="text-[oklch(0.708_0.15_295)] font-mono uppercase text-[10px] tracking-widest">
                // Endpoint Settings
              </span>
            </div>
            <div className="flex flex-col gap-2">
              <div className="flex flex-col gap-1">
                <span className="font-mono uppercase text-neutral-600 text-[10px] tracking-widest">
                  Base URL
                </span>
                <input
                  className="outline-none font-mono rounded-xl bg-neutral-950 text-neutral-300 text-xs leading-4 border-white/10 border-1 border-solid px-3 py-2.5 w-full"
                  defaultValue="https://api.openai.com/v1"
                />
              </div>
              <div className="border-white/5 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex py-2 justify-between items-center">
                <span className="font-mono text-neutral-300 text-sm leading-5">
                  API Version
                </span>
                <span className="font-mono text-neutral-400 text-sm leading-5">
                  v1
                </span>
              </div>
              <div className="border-white/5 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex py-2 justify-between items-center">
                <div className="flex flex-col">
                  <span className="font-mono text-neutral-300 text-sm leading-5">
                    Timeout
                  </span>
                  <span className="font-mono text-neutral-600 text-[10px]">
                    // Provider Default
                  </span>
                </div>
                <span className="text-[oklch(0.45_0_0)] font-mono font-bold rounded-full bg-neutral-800 text-[10px] px-2.5 py-1">
                  OFF
                </span>
              </div>
              <div className="flex py-2 justify-between items-center">
                <div className="flex flex-col">
                  <span className="font-mono text-neutral-300 text-sm leading-5">
                    Max Retries
                  </span>
                  <span className="font-mono text-neutral-600 text-[10px]">
                    // Provider Default
                  </span>
                </div>
                <span className="text-[oklch(0.45_0_0)] font-mono font-bold rounded-full bg-neutral-800 text-[10px] px-2.5 py-1">
                  OFF
                </span>
              </div>
            </div>
          </div>
          <div className="rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex p-4 flex-col gap-3">
            <div className="flex items-center gap-2">
              <BarChart2 className="size-3 text-[oklch(0.708_0.15_295)]" />
              <span className="text-[oklch(0.708_0.15_295)] font-mono uppercase text-[10px] tracking-widest">{`// Usage & Limits`}</span>
            </div>
            <div className="flex flex-col gap-2">
              <div className="flex justify-between items-center">
                <span className="font-mono text-neutral-400 text-xs leading-4">
                  This Month
                </span>
                <span className="text-[oklch(0.708_0.15_295)] font-mono font-bold text-sm leading-5">
                  $4.27 / $20.00 limit
                </span>
              </div>
              <div className="rounded-full bg-neutral-800 w-full h-1.5">
                <div className="bg-[oklch(0.708_0.15_295)] w-[21%] rounded-full h-1.5" />
              </div>
              <div className="flex mt-1 flex-col gap-1">
                <div className="border-white/5 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex py-1.5 justify-between items-center">
                  <span className="font-mono text-neutral-400 text-xs leading-4">
                    Requests Today
                  </span>
                  <span className="font-mono text-neutral-300 text-xs leading-4">
                    142
                  </span>
                </div>
                <div className="border-white/5 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex py-1.5 justify-between items-center">
                  <span className="font-mono text-neutral-400 text-xs leading-4">
                    Tokens Used
                  </span>
                  <span className="font-mono text-neutral-300 text-xs leading-4">
                    1.2M
                  </span>
                </div>
                <div className="border-white/5 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex py-1.5 justify-between items-center">
                  <span className="font-mono text-neutral-400 text-xs leading-4">
                    Avg Latency
                  </span>
                  <span className="font-mono text-neutral-300 text-xs leading-4">
                    340ms
                  </span>
                </div>
                <div className="flex py-1.5 justify-between items-center">
                  <span className="font-mono text-neutral-300 text-sm leading-5">
                    Set Monthly Limit
                  </span>
                  <ChevronRight className="size-4 text-neutral-500" />
                </div>
              </div>
            </div>
          </div>
          <div className="rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex p-4 flex-col gap-3">
            <div className="flex items-center gap-2">
              <Settings2 className="size-3 text-[oklch(0.708_0.15_295)]" />
              <span className="text-[oklch(0.708_0.15_295)] font-mono uppercase text-[10px] tracking-widest">
                // Advanced
              </span>
            </div>
            <div className="flex flex-col gap-1">
              <div className="border-white/5 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex py-2 justify-between items-center">
                <span className="font-mono text-neutral-300 text-sm leading-5">
                  Custom Headers
                </span>
                <ChevronRight className="size-4 text-neutral-500" />
              </div>
              <div className="border-white/5 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex py-2 flex-col gap-1">
                <span className="font-mono uppercase text-neutral-600 text-[10px] tracking-widest">
                  Proxy URL
                </span>
                <input
                  className="outline-none font-mono rounded-xl bg-neutral-950 text-neutral-600 text-xs leading-4 border-white/10 border-1 border-solid mt-1 px-3 py-2.5 w-full"
                  placeholder="// optional proxy..."
                />
              </div>
              <div className="border-white/5 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex py-2 justify-between items-center">
                <div className="flex flex-col">
                  <span className="font-mono text-neutral-300 text-sm leading-5">
                    Request Logging
                  </span>
                  <span className="font-mono text-neutral-600 text-[10px]">
                    // logs all api requests locally
                  </span>
                </div>
                <Switch className="scale-75" />
              </div>
              <div className="flex py-2 justify-between items-center">
                <div className="flex flex-col">
                  <span className="font-mono text-neutral-300 text-sm leading-5">
                    Stream Responses
                  </span>
                  <span className="font-mono text-neutral-600 text-[10px]">
                    // enables token streaming
                  </span>
                </div>
                <Switch className="scale-75" defaultChecked={true} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
