import { useEffect } from "react";
import {
  ArrowLeft,
  Check,
  ChevronDown,
  Layout,
  MessageSquare,
  Palette,
  Type,
} from "lucide-react";
import { Switch } from "@/components/ui/switch";

export default function App() {
  return (
    <div>
      <div className="bg-[oklch(0.10_0_0)] font-mono text-neutral-50 w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <div className="sticky z-20 bg-neutral-950 border-white/10 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex top-0 px-4 py-3 items-center gap-3">
          <button className="rounded-full flex justify-center items-center w-8 h-8">
            <ArrowLeft className="size-4 text-neutral-400" />
          </button>
          <span className="font-mono font-bold text-center text-neutral-50 text-sm leading-5 tracking-tight flex-1">
            Appearance
          </span>
          <div className="w-8" />
        </div>
        <div className="flex px-4 pt-4 pb-8 flex-col gap-4">
          <div className="rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex px-4 py-3 flex-col gap-3">
            <div className="flex items-center gap-2">
              <Palette className="size-3 text-[oklch(0.708_0.15_295)]" />
              <span className="text-[oklch(0.708_0.15_295)] font-mono font-bold uppercase text-[10px] tracking-widest">
                // THEME
              </span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="relative border-[oklch(0.708_0.15_295)] rounded-xl border-black/1 border-2 border-solid flex flex-col overflow-hidden">
                <div className="bg-neutral-950 flex justify-center items-center h-14">
                  <div className="rounded-full bg-neutral-800 w-8 h-1.5" />
                  <div className="bg-[oklch(0.708_0.15_295)] rounded-full flex absolute right-1.5 top-1.5 justify-center items-center w-4 h-4">
                    <Check className="size-2.5 text-white" />
                  </div>
                </div>
                <div className="bg-neutral-900 px-2 py-1.5">
                  <span className="font-mono text-neutral-50 text-[10px]">
                    Dark
                  </span>
                </div>
              </div>
              <div className="relative rounded-xl border-white/10 border-2 border-solid flex flex-col overflow-hidden">
                <div className="bg-white/90 flex justify-center items-center h-14">
                  <div className="rounded-full bg-neutral-300 w-8 h-1.5" />
                </div>
                <div className="bg-neutral-900 px-2 py-1.5">
                  <span className="font-mono text-neutral-400 text-[10px]">
                    Light
                  </span>
                </div>
              </div>
              <div className="relative rounded-xl border-white/10 border-2 border-solid flex flex-col overflow-hidden">
                <div className="bg-black flex justify-center items-center h-14">
                  <div className="rounded-full bg-neutral-900 w-8 h-1.5" />
                </div>
                <div className="bg-neutral-900 px-2 py-1.5">
                  <span className="font-mono text-neutral-400 text-[10px]">
                    OLED Black
                  </span>
                </div>
              </div>
              <div className="relative rounded-xl border-white/10 border-2 border-solid flex flex-col overflow-hidden">
                <div className="flex h-14">
                  <div className="bg-neutral-900 flex justify-center items-center flex-1">
                    <div className="rounded-full bg-neutral-700 w-3 h-1.5" />
                  </div>
                  <div className="bg-white/90 flex justify-center items-center flex-1">
                    <div className="rounded-full bg-neutral-300 w-3 h-1.5" />
                  </div>
                </div>
                <div className="bg-neutral-900 px-2 py-1.5">
                  <span className="font-mono text-neutral-400 text-[10px]">
                    System
                  </span>
                </div>
              </div>
            </div>
            <div className="flex flex-col gap-2">
              <span className="font-mono uppercase text-neutral-500 text-[10px] tracking-widest">
                ACCENT COLOR
              </span>
              <div className="flex flex-row items-center gap-3">
                <div className="bg-[oklch(0.708_0.15_295)] ring-2 ring-white ring-offset-2 ring-offset-neutral-900 rounded-full w-7 h-7" />
                <div className="rounded-full bg-blue-400 w-7 h-7" />
                <div className="rounded-full bg-emerald-400 w-7 h-7" />
                <div className="rounded-full bg-amber-400 w-7 h-7" />
                <div className="rounded-full bg-rose-400 w-7 h-7" />
                <div className="rounded-full bg-cyan-400 w-7 h-7" />
              </div>
            </div>
          </div>
          <div className="rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex px-4 py-3 flex-col gap-3">
            <div className="flex items-center gap-2">
              <Type className="size-3 text-[oklch(0.708_0.15_295)]" />
              <span className="text-[oklch(0.708_0.15_295)] font-mono font-bold uppercase text-[10px] tracking-widest">
                // TYPOGRAPHY
              </span>
            </div>
            <div className="border-white/5 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex py-1 justify-between items-center">
              <span className="font-mono text-neutral-300 text-[11px]">
                Font Family
              </span>
              <button className="rounded-lg bg-neutral-800 border-white/10 border-1 border-solid flex px-2.5 py-1 items-center gap-1.5">
                <span className="font-mono text-neutral-200 text-[11px]">
                  JetBrains Mono
                </span>
                <ChevronDown className="size-3 text-neutral-400" />
              </button>
            </div>
            <div className="border-white/5 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex py-1 justify-between items-center">
              <span className="font-mono text-neutral-300 text-[11px]">
                Font Size
              </span>
              <div className="rounded-lg border-white/10 border-1 border-solid flex overflow-hidden">
                <button className="font-mono bg-neutral-800 text-neutral-400 text-[10px] px-3 py-1">
                  SM
                </button>
                <button className="bg-[oklch(0.708_0.15_295)] font-mono font-bold text-white text-[10px] px-3 py-1">
                  MD
                </button>
                <button className="font-mono bg-neutral-800 text-neutral-400 text-[10px] px-3 py-1">
                  LG
                </button>
              </div>
            </div>
            <div className="border-white/5 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex py-1 justify-between items-center">
              <span className="font-mono text-neutral-300 text-[11px]">
                Line Height
              </span>
              <div className="rounded-lg border-white/10 border-1 border-solid flex overflow-hidden">
                <button className="font-mono bg-neutral-800 text-neutral-400 text-[10px] px-2.5 py-1">
                  Compact
                </button>
                <button className="bg-[oklch(0.708_0.15_295)] font-mono font-bold text-white text-[10px] px-2.5 py-1">
                  Normal
                </button>
                <button className="font-mono bg-neutral-800 text-neutral-400 text-[10px] px-2.5 py-1">
                  Relaxed
                </button>
              </div>
            </div>
            <div className="flex py-1 justify-between items-center">
              <span className="font-mono text-neutral-300 text-[11px]">
                Font Weight
              </span>
              <div className="rounded-lg border-white/10 border-1 border-solid flex overflow-hidden">
                <button className="bg-[oklch(0.708_0.15_295)] font-mono font-bold text-white text-[10px] px-2.5 py-1">
                  Regular
                </button>
                <button className="font-mono bg-neutral-800 text-neutral-400 text-[10px] px-2.5 py-1">
                  Medium
                </button>
                <button className="font-mono bg-neutral-800 text-neutral-400 text-[10px] px-2.5 py-1">
                  Bold
                </button>
              </div>
            </div>
          </div>
          <div className="rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex px-4 py-3 flex-col gap-3">
            <div className="flex items-center gap-2">
              <MessageSquare className="size-3 text-[oklch(0.708_0.15_295)]" />
              <span className="text-[oklch(0.708_0.15_295)] font-mono font-bold uppercase text-[10px] tracking-widest">
                // CHAT BUBBLES
              </span>
            </div>
            <div className="border-white/5 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex py-1 justify-between items-center">
              <span className="font-mono text-neutral-300 text-[11px]">
                Bubble Style
              </span>
              <div className="rounded-lg border-white/10 border-1 border-solid flex overflow-hidden">
                <button className="bg-[oklch(0.708_0.15_295)] font-mono font-bold text-white text-[10px] px-2.5 py-1">
                  Minimal
                </button>
                <button className="font-mono bg-neutral-800 text-neutral-400 text-[10px] px-2.5 py-1">
                  Rounded
                </button>
                <button className="font-mono bg-neutral-800 text-neutral-400 text-[10px] px-2.5 py-1">
                  Classic
                </button>
              </div>
            </div>
            <div className="border-white/5 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex py-1.5 justify-between items-center">
              <span className="font-mono text-neutral-300 text-[11px]">
                Show Avatars
              </span>
              <Switch checked={true} className="scale-75" />
            </div>
            <div className="border-white/5 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex py-1.5 flex-col gap-0.5">
              <div className="flex justify-between items-center">
                <span className="font-mono text-neutral-300 text-[11px]">
                  Compact Mode
                </span>
                <Switch className="scale-75" />
              </div>
              <span className="font-mono text-neutral-600 text-[9px]">
                // reduces padding between messages
              </span>
            </div>
            <div className="border-white/5 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex py-1.5 justify-between items-center">
              <span className="font-mono text-neutral-300 text-[11px]">
                Code Block Theme
              </span>
              <button className="rounded-lg bg-neutral-800 border-white/10 border-1 border-solid flex px-2.5 py-1 items-center gap-1.5">
                <span className="font-mono text-neutral-200 text-[10px]">
                  One Dark Pro
                </span>
                <ChevronDown className="size-3 text-neutral-400" />
              </button>
            </div>
            <div className="border-white/5 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex py-1.5 justify-between items-center">
              <span className="font-mono text-neutral-300 text-[11px]">
                Syntax Highlighting
              </span>
              <Switch checked={true} className="scale-75" />
            </div>
            <div className="flex py-1.5 justify-between items-center">
              <span className="font-mono text-neutral-300 text-[11px]">
                Show Line Numbers
              </span>
              <Switch className="scale-75" />
            </div>
          </div>
          <div className="rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex px-4 py-3 flex-col gap-3">
            <div className="flex items-center gap-2">
              <Layout className="size-3 text-[oklch(0.708_0.15_295)]" />
              <span className="text-[oklch(0.708_0.15_295)] font-mono font-bold uppercase text-[10px] tracking-widest">
                // LAYOUT
              </span>
            </div>
            <div className="border-white/5 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex py-1 justify-between items-center">
              <span className="font-mono text-neutral-300 text-[11px]">
                Sidebar Width
              </span>
              <div className="rounded-lg border-white/10 border-1 border-solid flex overflow-hidden">
                <button className="font-mono bg-neutral-800 text-neutral-400 text-[10px] px-2.5 py-1">
                  Narrow
                </button>
                <button className="bg-[oklch(0.708_0.15_295)] font-mono font-bold text-white text-[10px] px-2.5 py-1">
                  Normal
                </button>
                <button className="font-mono bg-neutral-800 text-neutral-400 text-[10px] px-2.5 py-1">
                  Wide
                </button>
              </div>
            </div>
            <div className="border-white/5 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex py-1 justify-between items-center">
              <span className="font-mono text-neutral-300 text-[11px]">
                Message Width
              </span>
              <div className="rounded-lg border-white/10 border-1 border-solid flex overflow-hidden">
                <button className="font-mono bg-neutral-800 text-neutral-400 text-[10px] px-2.5 py-1">
                  Compact
                </button>
                <button className="bg-[oklch(0.708_0.15_295)] font-mono font-bold text-white text-[10px] px-2.5 py-1">
                  Full
                </button>
                <button className="font-mono bg-neutral-800 text-neutral-400 text-[10px] px-2.5 py-1">
                  Centered
                </button>
              </div>
            </div>
            <div className="border-white/5 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex py-1.5 justify-between items-center">
              <span className="font-mono text-neutral-300 text-[11px]">
                Show Timestamps
              </span>
              <Switch checked={true} className="scale-75" />
            </div>
            <div className="border-white/5 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex py-1.5 justify-between items-center">
              <span className="font-mono text-neutral-300 text-[11px]">
                Sticky Input Bar
              </span>
              <Switch checked={true} className="scale-75" />
            </div>
            <div className="border-white/5 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex py-1.5 flex-col gap-0.5">
              <div className="flex justify-between items-center">
                <span className="font-mono text-neutral-300 text-[11px]">
                  Blur Effects
                </span>
                <Switch checked={true} className="scale-75" />
              </div>
              <span className="font-mono text-neutral-600 text-[9px]">
                // glassmorphism effects
              </span>
            </div>
            <div className="flex py-1.5 flex-col gap-0.5">
              <div className="flex justify-between items-center">
                <span className="font-mono text-neutral-300 text-[11px]">
                  Reduce Motion
                </span>
                <Switch className="scale-75" />
              </div>
              <span className="font-mono text-neutral-600 text-[9px]">
                // accessibility: disables animations
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
