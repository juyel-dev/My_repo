import { useEffect } from "react";
import {
  ArrowLeft,
  Bot,
  Cpu,
  ExternalLink,
  Eye,
  Image,
  MessageCircle,
  Pencil,
  Settings,
  Trash2,
  Wrench,
} from "lucide-react";
import { Switch } from "@/components/ui/switch";

export default function App() {
  return (
    <div>
      <div className="font-mono bg-neutral-950 text-neutral-50 w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <div className="min-h-[874px] bg-[oklch(0.10_0_0)] flex flex-col">
          <div className="flex px-4 pt-10 pb-4 items-center gap-4">
            <div className="size-8 bg-[oklch(0.20_0_0)] rounded-full flex justify-center items-center">
              <ArrowLeft className="size-4 text-neutral-50" />
            </div>
            <span className="font-bold text-neutral-50 text-2xl leading-8 tracking-tight">
              GLM
            </span>
          </div>
          <div className="overflow-y-auto flex px-4 pb-28 flex-col flex-1 gap-4">
            <div className="bg-[oklch(0.18_0_0)] rounded-2xl flex p-4 items-center gap-4">
              <Settings className="size-5 shrink-0 text-[#a1a1a1]" />
              <div className="flex-1">
                <p className="font-semibold text-neutral-50 text-sm leading-5">
                  Enable this service
                </p>
                <p className="text-[#a1a1a1] text-xs leading-4 mt-0.5">
                  Allow selection in the default assistant
                </p>
              </div>
              <Switch className="shrink-0" />
            </div>
            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2">
                <Settings className="size-4 text-[oklch(0.708_0.15_295)]" />
                <span className="text-[oklch(0.708_0.15_295)] font-semibold text-sm leading-5 tracking-wide">
                  API Key
                </span>
              </div>
              <div className="bg-[oklch(0.18_0_0)] rounded-2xl flex p-4 flex-col gap-3">
                <div className="flex items-center gap-3">
                  <Bot className="size-5 shrink-0 text-[#a1a1a1]" />
                  <div className="flex-1">
                    <p className="font-semibold text-neutral-50 text-sm leading-5">
                      API Keys
                    </p>
                    <p className="text-[#a1a1a1] text-xs leading-4">
                      How to get
                      <span className="text-[oklch(0.708_0.15_295)] underline">
                        API Keys?
                      </span>
                      <ExternalLink className="inline size-3" />
                    </p>
                  </div>
                </div>
                <div className="bg-[oklch(0.22_0_0)] rounded-xl flex p-3 items-center gap-3">
                  <div className="size-5 shrink-0 rounded-full border-[#a1a1a1] border-2 border-solid flex justify-center items-center" />
                  <div className="flex-1">
                    <p className="font-mono text-neutral-50 text-sm leading-5">
                      ***
                    </p>
                    <p className="text-[#a1a1a1] text-xs leading-4">
                      My Testing API key
                    </p>
                  </div>
                  <div className="size-8 bg-[oklch(0.30_0.05_295)] rounded-full flex justify-center items-center">
                    <Pencil className="size-3.5 text-[oklch(0.708_0.15_295)]" />
                  </div>
                  <div className="size-8 bg-[oklch(0.45_0.18_22)] rounded-full flex justify-center items-center">
                    <Trash2 className="size-3.5 text-white" />
                  </div>
                </div>
                <div className="bg-[oklch(0.22_0_0)] border-[oklch(0.708_0.15_295)/40%] rounded-xl border-black/1 border-1 border-solid flex p-3 items-center gap-3">
                  <div className="size-5 border-[oklch(0.708_0.15_295)] shrink-0 rounded-full border-black/1 border-2 border-solid flex justify-center items-center">
                    <div className="size-2.5 bg-[oklch(0.708_0.15_295)] rounded-full" />
                  </div>
                  <div className="flex-1">
                    <p className="font-mono text-neutral-50 text-sm leading-5">
                      ***
                    </p>
                    <p className="text-[#a1a1a1] text-xs leading-4">
                      Production
                    </p>
                  </div>
                  <div className="size-8 bg-[oklch(0.30_0.05_295)] rounded-full flex justify-center items-center">
                    <Pencil className="size-3.5 text-[oklch(0.708_0.15_295)]" />
                  </div>
                  <div className="size-8 bg-[oklch(0.45_0.18_22)] rounded-full flex justify-center items-center">
                    <Trash2 className="size-3.5 text-white" />
                  </div>
                </div>
                <div className="flex pt-1 justify-end gap-4">
                  <span className="text-[#a1a1a1] text-sm leading-5">
                    Test connection
                  </span>
                  <span className="text-[oklch(0.708_0.15_295)] font-semibold text-sm leading-5">
                    Add
                  </span>
                </div>
              </div>
            </div>
            <div className="bg-[oklch(0.18_0_0)] rounded-2xl flex p-4 flex-col gap-3">
              <div className="flex items-center gap-3">
                <Settings className="size-5 shrink-0 text-[#a1a1a1]" />
                <div className="flex-1">
                  <p className="font-semibold text-neutral-50 text-sm leading-5">
                    API Host
                  </p>
                  <p className="text-[#a1a1a1] text-xs leading-4">
                    Leave blank to use the default
                  </p>
                </div>
              </div>
              <div className="border-[oklch(0.708_0.15_295)/50%] bg-[oklch(0.14_0_0)] rounded-xl border-black/1 border-1 border-solid px-3 py-2">
                <p className="font-mono text-neutral-50 text-xs leading-4">
                  https://open.bigmodel.cn/api/paas/v4
                </p>
              </div>
            </div>
            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2">
                <Bot className="size-4 text-[oklch(0.708_0.15_295)]" />
                <span className="text-[oklch(0.708_0.15_295)] font-semibold text-sm leading-5 tracking-wide">
                  Custom models
                </span>
              </div>
              <div className="bg-[oklch(0.18_0_0)] rounded-2xl flex p-4 flex-col gap-2">
                <p className="text-center text-[#a1a1a1] text-sm leading-5 py-2">
                  No custom models
                </p>
                <div className="flex justify-end">
                  <span className="text-[oklch(0.708_0.15_295)] font-semibold text-sm leading-5">
                    Add
                  </span>
                </div>
              </div>
            </div>
            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2">
                <Cpu className="size-4 text-[oklch(0.708_0.15_295)]" />
                <span className="text-[oklch(0.708_0.15_295)] font-semibold text-sm leading-5 tracking-wide">
                  Available models
                </span>
              </div>
              <div className="bg-[oklch(0.18_0_0)] rounded-2xl flex p-2 flex-col gap-1">
                <div className="rounded-xl flex p-2 items-center gap-3">
                  <Bot className="size-4 shrink-0 text-[#a1a1a1]" />
                  <div className="flex-1">
                    <p className="text-neutral-50 text-sm leading-5">
                      cogview-3-flash
                    </p>
                    <div className="flex items-center gap-1">
                      <Image className="size-3 text-[#a1a1a1]" />
                      <span className="text-[#a1a1a1] text-xs leading-4">
                        128K
                      </span>
                    </div>
                  </div>
                  <Pencil className="size-3.5 text-[#a1a1a1]" />
                  <div className="size-6 bg-[oklch(0.45_0.18_22)] rounded-full flex justify-center items-center">
                    <Trash2 className="size-3 text-white" />
                  </div>
                </div>
                <div className="rounded-xl flex p-2 items-center gap-3">
                  <Bot className="size-4 shrink-0 text-[#a1a1a1]" />
                  <div className="flex-1">
                    <p className="text-neutral-50 text-sm leading-5">
                      cogview-4
                    </p>
                    <div className="flex items-center gap-1">
                      <Image className="size-3 text-[#a1a1a1]" />
                      <span className="text-[#a1a1a1] text-xs leading-4">
                        128K
                      </span>
                    </div>
                  </div>
                  <Pencil className="size-3.5 text-[#a1a1a1]" />
                  <div className="size-6 bg-[oklch(0.45_0.18_22)] rounded-full flex justify-center items-center">
                    <Trash2 className="size-3 text-white" />
                  </div>
                </div>
                <div className="rounded-xl flex p-2 items-center gap-3">
                  <Bot className="size-4 shrink-0 text-[#a1a1a1]" />
                  <div className="flex-1">
                    <p className="text-neutral-50 text-sm leading-5">
                      glm-4.5-air
                    </p>
                    <div className="flex items-center gap-1">
                      <Wrench className="size-3 text-[#a1a1a1]" />
                      <span className="text-[#a1a1a1] text-xs leading-4">
                        128K
                      </span>
                    </div>
                  </div>
                  <Pencil className="size-3.5 text-[#a1a1a1]" />
                  <div className="size-6 bg-[oklch(0.45_0.18_22)] rounded-full flex justify-center items-center">
                    <Trash2 className="size-3 text-white" />
                  </div>
                </div>
                <div className="rounded-xl flex p-2 items-center gap-3">
                  <Bot className="size-4 shrink-0 text-[#a1a1a1]" />
                  <div className="flex-1">
                    <p className="text-neutral-50 text-sm leading-5">
                      glm-4.5-flash
                    </p>
                    <div className="flex items-center gap-1">
                      <Wrench className="size-3 text-[#a1a1a1]" />
                      <span className="text-[#a1a1a1] text-xs leading-4">
                        128K
                      </span>
                    </div>
                  </div>
                  <Pencil className="size-3.5 text-[#a1a1a1]" />
                  <div className="size-6 bg-[oklch(0.45_0.18_22)] rounded-full flex justify-center items-center">
                    <Trash2 className="size-3 text-white" />
                  </div>
                </div>
                <div className="rounded-xl flex p-2 items-center gap-3">
                  <Bot className="size-4 shrink-0 text-[#a1a1a1]" />
                  <div className="flex-1">
                    <p className="text-neutral-50 text-sm leading-5">glm-4.6</p>
                    <div className="flex items-center gap-2">
                      <Wrench className="size-3 text-[#a1a1a1]" />
                      <Eye className="size-3 text-[#a1a1a1]" />
                      <span className="text-[#a1a1a1] text-xs leading-4">
                        128K
                      </span>
                    </div>
                  </div>
                  <Pencil className="size-3.5 text-[#a1a1a1]" />
                  <div className="size-6 bg-[oklch(0.45_0.18_22)] rounded-full flex justify-center items-center">
                    <Trash2 className="size-3 text-white" />
                  </div>
                </div>
                <div className="rounded-xl flex p-2 items-center gap-3">
                  <Bot className="size-4 shrink-0 text-[#a1a1a1]" />
                  <div className="flex-1">
                    <p className="text-neutral-50 text-sm leading-5">
                      glm-4.6v
                    </p>
                    <div className="flex items-center gap-2">
                      <Eye className="size-3 text-[#a1a1a1]" />
                      <Wrench className="size-3 text-[#a1a1a1]" />
                      <Eye className="size-3 text-[#a1a1a1]" />
                      <span className="text-[#a1a1a1] text-xs leading-4">
                        128K
                      </span>
                    </div>
                  </div>
                  <Pencil className="size-3.5 text-[#a1a1a1]" />
                  <div className="size-6 bg-[oklch(0.45_0.18_22)] rounded-full flex justify-center items-center">
                    <Trash2 className="size-3 text-white" />
                  </div>
                </div>
                <div className="rounded-xl flex p-2 items-center gap-3">
                  <Bot className="size-4 shrink-0 text-[#a1a1a1]" />
                  <div className="flex-1">
                    <p className="text-neutral-50 text-sm leading-5">glm-5</p>
                    <div className="flex items-center gap-1">
                      <Wrench className="size-3 text-[#a1a1a1]" />
                      <span className="text-[#a1a1a1] text-xs leading-4">
                        128K
                      </span>
                    </div>
                  </div>
                  <Pencil className="size-3.5 text-[#a1a1a1]" />
                  <div className="size-6 bg-[oklch(0.45_0.18_22)] rounded-full flex justify-center items-center">
                    <Trash2 className="size-3 text-white" />
                  </div>
                </div>
                <div className="flex px-2 py-1 justify-between items-center">
                  <span className="text-[oklch(0.708_0.15_295)] text-xs leading-4">
                    View all 11 items
                  </span>
                  <span className="text-[#a1a1a1] text-xs leading-4">
                    Refresh models
                  </span>
                </div>
              </div>
            </div>
          </div>
          <div className="fixed bg-[oklch(0.12_0_0)] border-white/10 border-t-1 border-r-0 border-b-0 border-l-0 border-solid inset-x-0 bottom-0">
            <div className="flex px-4 py-3 flex-row justify-around items-center">
              <div className="flex flex-col items-center gap-1">
                <MessageCircle className="size-5 text-[#a1a1a1]" />
                <span className="font-mono text-[#a1a1a1] text-xs leading-4">
                  Chats
                </span>
              </div>
              <div className="flex flex-col items-center gap-1">
                <Settings className="size-5 text-neutral-50" />
                <span className="font-mono text-neutral-50 text-xs leading-4">
                  Settings
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
