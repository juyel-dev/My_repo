import { useEffect } from "react";
import {
  ArrowLeft,
  ChevronDown,
  Pencil,
  Plus,
  Search,
  Server,
  Star,
  Trash2,
} from "lucide-react";
import { Switch } from "@/components/ui/switch";

export default function App() {
  return (
    <div>
      <div className="bg-[oklch(0.10_0_0)] text-[oklch(0.87_0_0)] font-mono flex flex-col w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <div className="sticky z-20 bg-neutral-950 border-white/10 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex top-0 px-4 py-3 items-center gap-3">
          <button className="rounded-lg text-neutral-400 flex justify-center items-center w-8 h-8">
            <ArrowLeft className="size-4" />
          </button>
          <span className="font-mono font-bold text-neutral-50 text-sm leading-5 flex-1">
            MCP Settings
          </span>
          <div className="flex items-center gap-2">
            <button className="rounded-lg text-neutral-400 flex justify-center items-center w-8 h-8">
              <Search className="size-4" />
            </button>
            <button className="bg-[oklch(0.708_0.15_295)] rounded-full text-white flex justify-center items-center w-8 h-8">
              <Plus className="size-4" />
            </button>
          </div>
        </div>
        <div className="overflow-y-auto flex p-4 flex-col flex-1 gap-4">
          <div className="relative flex items-center">
            <Search className="size-3.5 text-neutral-500 absolute left-3" />
            <input
              className="placeholder-neutral-600 outline-none font-mono rounded-xl bg-neutral-900 text-neutral-400 text-xs leading-4 border-white/10 border-1 border-solid pl-8 pr-4 py-2.5 w-full"
              placeholder="// search mcp servers..."
            />
          </div>
          <div className="flex items-center gap-2">
            <Server className="size-3.5 text-[oklch(0.708_0.15_295)]" />
            <span className="text-[oklch(0.708_0.15_295)] font-mono font-bold uppercase text-[10px] tracking-widest">
              ⚙ // CONFIGURED SERVERS
            </span>
          </div>
          <div className="flex flex-col gap-2">
            <div className="relative rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex px-4 py-3 items-center gap-3 overflow-hidden">
              <div className="bg-[oklch(0.708_0.15_295)] rounded-l-xl absolute left-0 inset-y-0 w-0.5" />
              <div className="min-w-0 flex pl-1 flex-col flex-1 gap-1">
                <div className="flex items-center gap-2">
                  <span className="font-mono font-bold text-neutral-50 text-sm leading-5">
                    filesystem-mcp
                  </span>
                  <span className="bg-[oklch(0.708_0.15_295)]/10 text-[oklch(0.708_0.15_295)] font-mono uppercase rounded-full text-[10px] tracking-widest px-1.5 py-0.5">
                    STDIO
                  </span>
                </div>
                <span className="truncate text-neutral-400 text-xs leading-4">
                  /usr/local/bin/mcp-fs
                </span>
                <div className="flex items-center gap-1">
                  <div className="rounded-full bg-green-500 w-1.5 h-1.5" />
                  <span className="font-mono text-green-400 text-[10px]">
                    Connected
                  </span>
                </div>
              </div>
              <div className="shrink-0 flex items-center gap-2">
                <Switch className="scale-75" checked={true} />
                <button className="text-neutral-400">
                  <Pencil className="size-3.5" />
                </button>
                <button className="text-red-400">
                  <Trash2 className="size-3.5" />
                </button>
              </div>
            </div>
            <div className="relative rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex px-4 py-3 items-center gap-3 overflow-hidden">
              <div className="bg-[oklch(0.708_0.15_295)] rounded-l-xl absolute left-0 inset-y-0 w-0.5" />
              <div className="min-w-0 flex pl-1 flex-col flex-1 gap-1">
                <div className="flex items-center gap-2">
                  <span className="font-mono font-bold text-neutral-50 text-sm leading-5">
                    brave-search
                  </span>
                  <span className="bg-[oklch(0.708_0.15_295)]/10 text-[oklch(0.708_0.15_295)] font-mono uppercase rounded-full text-[10px] tracking-widest px-1.5 py-0.5">
                    SSE
                  </span>
                </div>
                <span className="truncate text-neutral-400 text-xs leading-4">
                  https://mcp.brave.com/sse
                </span>
                <div className="flex items-center gap-1">
                  <div className="rounded-full bg-green-500 w-1.5 h-1.5" />
                  <span className="font-mono text-green-400 text-[10px]">
                    Connected
                  </span>
                </div>
              </div>
              <div className="shrink-0 flex items-center gap-2">
                <Switch className="scale-75" checked={true} />
                <button className="text-neutral-400">
                  <Pencil className="size-3.5" />
                </button>
                <button className="text-red-400">
                  <Trash2 className="size-3.5" />
                </button>
              </div>
            </div>
            <div className="relative rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex px-4 py-3 items-center gap-3 overflow-hidden">
              <div className="bg-[oklch(0.708_0.15_295)] rounded-l-xl absolute left-0 inset-y-0 w-0.5" />
              <div className="min-w-0 flex pl-1 flex-col flex-1 gap-1">
                <div className="flex items-center gap-2">
                  <span className="font-mono font-bold text-neutral-50 text-sm leading-5">
                    github-mcp
                  </span>
                  <span className="bg-[oklch(0.708_0.15_295)]/10 text-[oklch(0.708_0.15_295)] font-mono uppercase rounded-full text-[10px] tracking-widest px-1.5 py-0.5">
                    WebSocket
                  </span>
                </div>
                <span className="truncate text-neutral-400 text-xs leading-4">
                  wss://api.github.com/mcp
                </span>
                <div className="flex items-center gap-1">
                  <div className="rounded-full bg-red-500 w-1.5 h-1.5" />
                  <span className="font-mono text-red-400 text-[10px]">
                    Disconnected
                  </span>
                </div>
              </div>
              <div className="shrink-0 flex items-center gap-2">
                <Switch className="scale-75" checked={true} />
                <button className="text-neutral-400">
                  <Pencil className="size-3.5" />
                </button>
                <button className="text-red-400">
                  <Trash2 className="size-3.5" />
                </button>
              </div>
            </div>
            <div className="relative opacity-50 rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex px-4 py-3 items-center gap-3 overflow-hidden">
              <div className="min-w-0 flex flex-col flex-1 gap-1">
                <div className="flex items-center gap-2">
                  <span className="font-mono font-bold text-neutral-400 text-sm leading-5">
                    postgres-mcp
                  </span>
                  <span className="font-mono uppercase rounded-full bg-neutral-800 text-neutral-500 text-[10px] tracking-widest px-1.5 py-0.5">
                    HTTP
                  </span>
                </div>
                <span className="truncate text-neutral-500 text-xs leading-4">
                  http://localhost:5432/mcp
                </span>
                <div className="flex items-center gap-1">
                  <div className="rounded-full bg-red-700 w-1.5 h-1.5" />
                  <span className="font-mono text-red-600 text-[10px]">
                    Disconnected
                  </span>
                </div>
              </div>
              <div className="shrink-0 flex items-center gap-2">
                <Switch className="scale-75 bg-neutral-600" />
                <button className="text-neutral-600">
                  <Pencil className="size-3.5" />
                </button>
                <button className="text-red-800">
                  <Trash2 className="size-3.5" />
                </button>
              </div>
            </div>
            <div className="relative rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex px-4 py-3 items-center gap-3 overflow-hidden">
              <div className="bg-[oklch(0.708_0.15_295)] rounded-l-xl absolute left-0 inset-y-0 w-0.5" />
              <div className="min-w-0 flex pl-1 flex-col flex-1 gap-1">
                <div className="flex items-center gap-2">
                  <span className="font-mono font-bold text-neutral-50 text-sm leading-5">
                    puppeteer-mcp
                  </span>
                  <span className="bg-[oklch(0.708_0.15_295)]/10 text-[oklch(0.708_0.15_295)] font-mono uppercase rounded-full text-[10px] tracking-widest px-1.5 py-0.5">
                    STDIO
                  </span>
                </div>
                <span className="truncate text-neutral-400 text-xs leading-4">
                  /usr/bin/mcp-puppeteer
                </span>
                <div className="flex items-center gap-1">
                  <div className="rounded-full bg-green-500 w-1.5 h-1.5" />
                  <span className="font-mono text-green-400 text-[10px]">
                    Connected
                  </span>
                </div>
              </div>
              <div className="shrink-0 flex items-center gap-2">
                <Switch className="scale-75" checked={true} />
                <button className="text-neutral-400">
                  <Pencil className="size-3.5" />
                </button>
                <button className="text-red-400">
                  <Trash2 className="size-3.5" />
                </button>
              </div>
            </div>
          </div>
          <p className="font-mono text-neutral-600 text-[10px]">{`// tap edit to configure connection & permissions`}</p>
        </div>
        <div className="sticky z-20 bg-neutral-950 border-white/10 border-t-1 border-r-0 border-b-0 border-l-0 border-solid flex bottom-0 px-4 py-3 justify-between items-center">
          <div className="flex items-center gap-1.5">
            <Star className="size-3 text-[oklch(0.708_0.15_295)]" />
            <span className="text-[oklch(0.708_0.15_295)] font-mono font-bold uppercase text-[10px] tracking-widest">
              Active MCP Server
            </span>
          </div>
          <button className="rounded-lg bg-neutral-900 border-white/10 border-1 border-solid flex px-3 py-1.5 items-center gap-2">
            <span className="font-mono text-neutral-50 text-sm leading-5">
              filesystem-mcp
            </span>
            <ChevronDown className="size-3.5 text-neutral-400" />
          </button>
        </div>
      </div>
    </div>
  );
}
