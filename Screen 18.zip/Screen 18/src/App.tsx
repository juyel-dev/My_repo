import { useEffect } from "react";
import {
  ArrowLeft,
  ChevronDown,
  ChevronRight,
  HardDrive,
  RefreshCw,
  Trash2,
  Zap,
} from "lucide-react";
import { Switch } from "@/components/ui/switch";

export default function App() {
  return (
    <div>
      <div className="bg-[oklch(0.10_0_0)] font-mono text-neutral-50 w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <div className="sticky z-10 bg-neutral-950 border-white/10 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex top-0 px-4 py-3 items-center gap-3">
          <button className="text-neutral-400 flex justify-center items-center">
            <ArrowLeft className="size-5" />
          </button>
          <span className="font-mono font-bold text-center text-neutral-50 text-sm leading-5 tracking-tight flex-1">{`Auto-Compress & Storage`}</span>
          <div className="w-5" />
        </div>
        <div className="flex p-4 flex-col gap-4">
          <div className="rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex px-4 py-3 flex-col gap-3">
            <div className="flex mb-1 items-center gap-2">
              <Zap className="size-3 text-[oklch(0.708_0.15_295)]" />
              <span className="text-[oklch(0.708_0.15_295)] font-mono font-bold uppercase text-[10px] tracking-widest">
                // AUTO-COMPRESS
              </span>
            </div>
            <div className="flex flex-col gap-1">
              <div className="flex justify-between items-center">
                <span className="font-mono text-neutral-50 text-xs leading-4">
                  Auto-Compress
                </span>
                <Switch className="scale-75" defaultChecked={true} />
              </div>
              <span className="font-mono text-neutral-500 text-[10px]">
                // automatically compresses long conversations
              </span>
            </div>
            <div className="flex flex-col gap-1">
              <div className="flex justify-between items-center">
                <span className="font-mono text-neutral-50 text-xs leading-4">
                  Compression Threshold
                </span>
                <div className="flex items-center gap-1.5">
                  <input
                    className="bg-[oklch(0.708_0.15_295)]/10 border-[oklch(0.708_0.15_295)]/30 text-[oklch(0.708_0.15_295)] outline-none font-mono text-right rounded-sm text-xs leading-4 border-black/1 border-1 border-solid px-1.5 py-0.5 w-16"
                    defaultValue="8000"
                  />
                  <span className="font-mono text-neutral-500 text-[10px]">
                    tokens
                  </span>
                  <span className="bg-[oklch(0.708_0.15_295)]/20 border-[oklch(0.708_0.15_295)]/40 text-[oklch(0.708_0.15_295)] font-mono font-bold rounded-full text-[9px] border-black/1 border-1 border-solid px-2 py-0.5">
                    ON
                  </span>
                </div>
              </div>
            </div>
            <div className="flex flex-col gap-1">
              <div className="flex justify-between items-center">
                <span className="font-mono text-neutral-50 text-xs leading-4">
                  Compression Strategy
                </span>
                <div className="rounded-lg bg-neutral-950 border-white/10 border-1 border-solid flex px-2 py-1 items-center gap-1">
                  <span className="font-mono text-neutral-300 text-[10px]">
                    Summarize + Trim
                  </span>
                  <ChevronDown className="size-3 text-neutral-500" />
                </div>
              </div>
            </div>
            <div className="flex flex-col gap-1">
              <div className="flex justify-between items-center">
                <span className="font-mono text-neutral-50 text-xs leading-4">
                  Preserve System Prompt
                </span>
                <Switch className="scale-75" defaultChecked={true} />
              </div>
              <span className="font-mono text-neutral-500 text-[10px]">
                // always keeps system prompt intact
              </span>
            </div>
            <div className="flex flex-col gap-1">
              <div className="flex justify-between items-center">
                <span className="font-mono text-neutral-50 text-xs leading-4">
                  Preserve Last N Messages
                </span>
                <div className="flex items-center gap-1.5">
                  <input
                    className="bg-[oklch(0.708_0.15_295)]/10 border-[oklch(0.708_0.15_295)]/30 text-[oklch(0.708_0.15_295)] outline-none font-mono text-right rounded-sm text-xs leading-4 border-black/1 border-1 border-solid px-1.5 py-0.5 w-16"
                    defaultValue="20"
                  />
                  <span className="bg-[oklch(0.708_0.15_295)]/20 border-[oklch(0.708_0.15_295)]/40 text-[oklch(0.708_0.15_295)] font-mono font-bold rounded-full text-[9px] border-black/1 border-1 border-solid px-2 py-0.5">
                    ON
                  </span>
                </div>
              </div>
            </div>
            <div className="flex flex-col gap-1">
              <div className="flex justify-between items-center">
                <span className="font-mono text-neutral-50 text-xs leading-4">
                  Compression Model
                </span>
                <div className="rounded-lg bg-neutral-950 border-white/10 border-1 border-solid flex px-2 py-1 items-center gap-1">
                  <span className="font-mono text-neutral-300 text-[10px]">
                    gpt-4o-mini
                  </span>
                  <ChevronDown className="size-3 text-neutral-500" />
                </div>
              </div>
              <span className="font-mono text-neutral-500 text-[10px]">
                // model used for summarization
              </span>
            </div>
            <div className="flex flex-col gap-1">
              <div className="flex justify-between items-center">
                <span className="font-mono text-neutral-50 text-xs leading-4">
                  Show Compression Notice
                </span>
                <Switch className="scale-75" defaultChecked={true} />
              </div>
              <span className="font-mono text-neutral-500 text-[10px]">
                // notifies when compression occurs
              </span>
            </div>
            <div className="bg-[oklch(0.708_0.15_295)]/5 border-[oklch(0.708_0.15_295)]/20 rounded-lg border-black/1 border-1 border-solid px-3 py-2">
              <span className="font-mono text-neutral-400 text-[10px]">
                // compression preserves context quality while reducing token
                usage
              </span>
            </div>
          </div>
          <div className="rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex px-4 py-3 flex-col gap-3">
            <div className="flex mb-1 items-center gap-2">
              <HardDrive className="size-3 text-[oklch(0.708_0.15_295)]" />
              <span className="text-[oklch(0.708_0.15_295)] font-mono font-bold uppercase text-[10px] tracking-widest">
                💾 // STORAGE
              </span>
            </div>
            <div className="flex flex-col gap-1.5">
              <div className="flex justify-between items-center">
                <span className="font-mono text-neutral-50 text-xs leading-4">
                  Storage Used
                </span>
                <span className="font-mono text-neutral-400 text-xs leading-4">
                  124 MB / 500 MB
                </span>
              </div>
              <div className="rounded-full bg-neutral-800 w-full h-1.5">
                <div className="bg-[oklch(0.708_0.15_295)] w-[40%] rounded-full h-1.5" />
              </div>
            </div>
            <div className="rounded-lg bg-neutral-950 border-white/10 border-1 border-solid flex px-3 py-2 justify-between items-center">
              <span className="font-mono text-neutral-50 text-xs leading-4">
                Chat History
              </span>
              <div className="flex items-center gap-1">
                <span className="font-mono text-neutral-400 text-xs leading-4">
                  847 conversations
                </span>
                <ChevronRight className="size-3 text-neutral-500" />
              </div>
            </div>
            <div className="rounded-lg bg-neutral-950 border-white/10 border-1 border-solid flex px-3 py-2 justify-between items-center">
              <span className="font-mono text-neutral-50 text-xs leading-4">
                Attachment Cache
              </span>
              <div className="flex items-center gap-1">
                <span className="font-mono text-neutral-400 text-xs leading-4">
                  89 MB
                </span>
                <ChevronRight className="size-3 text-neutral-500" />
              </div>
            </div>
            <div className="flex flex-col gap-1">
              <div className="flex justify-between items-center">
                <span className="font-mono text-neutral-50 text-xs leading-4">
                  Auto-Delete Old Chats
                </span>
                <Switch className="scale-75" />
              </div>
              <span className="font-mono text-neutral-500 text-[10px]">
                // removes chats older than threshold
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="font-mono text-neutral-50 text-xs leading-4">
                Retention Period
              </span>
              <div className="flex items-center gap-1.5">
                <span className="font-mono text-neutral-600 text-[10px]">
                  App Default
                </span>
                <span className="text-[oklch(0.45_0_0)] font-mono font-bold rounded-full bg-neutral-800 text-[9px] px-2 py-0.5">
                  OFF
                </span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="font-mono text-neutral-50 text-xs leading-4">
                Cache Images
              </span>
              <Switch className="scale-75" defaultChecked={true} />
            </div>
            <div className="rounded-lg bg-neutral-950 border-white/10 border-1 border-solid flex px-3 py-2 justify-between items-center">
              <div className="flex items-center gap-2">
                <Trash2 className="size-3.5 text-neutral-400" />
                <span className="font-mono text-neutral-50 text-sm leading-5">
                  Clear Cache
                </span>
              </div>
              <div className="flex items-center gap-1">
                <span className="font-mono text-neutral-400 text-xs leading-4">
                  89 MB
                </span>
                <ChevronRight className="size-3 text-neutral-500" />
              </div>
            </div>
          </div>
          <div className="rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex px-4 py-3 flex-col gap-3">
            <div className="flex mb-1 items-center gap-2">
              <RefreshCw className="size-3 text-[oklch(0.708_0.15_295)]" />
              <span className="text-[oklch(0.708_0.15_295)] font-mono font-bold uppercase text-[10px] tracking-widest">
                🔄 // SYNC
              </span>
            </div>
            <div className="flex flex-col gap-1">
              <div className="flex justify-between items-center">
                <span className="font-mono text-neutral-50 text-xs leading-4">
                  iCloud Sync
                </span>
                <Switch className="scale-75" defaultChecked={true} />
              </div>
              <span className="font-mono text-neutral-500 text-[10px]">
                // syncs chats across Apple devices
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="font-mono text-neutral-50 text-xs leading-4">
                Last Synced
              </span>
              <span className="font-mono text-neutral-400 text-xs leading-4">
                2 minutes ago
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="font-mono text-neutral-50 text-xs leading-4">
                Sync on Wi-Fi Only
              </span>
              <Switch className="scale-75" defaultChecked={true} />
            </div>
            <div className="flex flex-col gap-1">
              <div className="flex justify-between items-center">
                <span className="font-mono text-neutral-50 text-xs leading-4">
                  Sync Attachments
                </span>
                <Switch className="scale-75" />
              </div>
              <span className="font-mono text-neutral-500 text-[10px]">
                // attachments excluded by default
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="font-mono text-neutral-50 text-xs leading-4">
                Background Sync
              </span>
              <Switch className="scale-75" defaultChecked={true} />
            </div>
          </div>
          <div className="h-6" />
        </div>
      </div>
    </div>
  );
}
