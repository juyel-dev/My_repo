import { useEffect } from "react";
import {
  ArrowLeft,
  Bot,
  Brain,
  ChevronDown,
  Code2,
  Cpu,
  Eye,
  FlaskConical,
  Globe,
  Pencil,
  Plus,
  Search,
  Server,
  Settings,
  Star,
  Trash2,
  Wrench,
} from "lucide-react";
import { Switch } from "@/components/ui/switch";

export default function App() {
  return (
    <div>
      <div className="bg-[oklch(0.10_0_0)] text-[oklch(0.87_0_0)] font-mono flex flex-col w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <div className="sticky z-20 bg-neutral-950 border-white/10 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex top-0 px-4 py-3 items-center gap-3">
          <ArrowLeft className="size-4 shrink-0 text-neutral-400" />
          <span className="font-mono font-bold text-neutral-50 text-sm leading-5 flex-1">
            Agent Settings
          </span>
          <Search className="size-4 shrink-0 text-neutral-400" />
          <button className="size-7 bg-[oklch(0.708_0.15_295)] shrink-0 rounded-full flex justify-center items-center">
            <Plus className="size-3.5 text-white" />
          </button>
        </div>
        <div className="overflow-y-auto flex p-4 flex-col flex-1 gap-4">
          <div className="relative rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex px-3 py-2.5 items-center gap-2">
            <Search className="size-3.5 shrink-0 text-neutral-600" />
            <span className="font-mono text-neutral-600 text-[11px]">
              // search agents...
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Bot className="size-3 text-[oklch(0.708_0.15_295)]" />
            <Settings className="size-3 text-[oklch(0.708_0.15_295)]" />
            <span className="text-[oklch(0.708_0.15_295)] font-mono uppercase text-[10px] tracking-widest">
              // CONFIGURED AGENTS
            </span>
          </div>
          <div className="flex flex-col gap-2">
            <div className="relative rounded-xl bg-neutral-900 border-white/10 border-1 border-solid p-3 overflow-hidden">
              <div className="bg-[oklch(0.708_0.15_295)] rounded-l-xl absolute left-0 inset-y-0 w-0.5" />
              <div className="flex items-start gap-2.5">
                <div className="size-7 shrink-0 rounded-lg bg-neutral-800 flex mt-0.5 justify-center items-center">
                  <Bot className="size-4 text-[oklch(0.708_0.15_295)]" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex justify-between items-center gap-2">
                    <div className="min-w-0">
                      <p className="leading-tight font-mono font-bold text-neutral-50 text-sm leading-5">
                        ResearchBot
                      </p>
                      <p className="leading-tight font-mono text-neutral-400 text-[10px]">
                        gpt-4o
                      </p>
                    </div>
                    <div className="shrink-0 flex items-center gap-2">
                      <Switch className="scale-75" checked={true} />
                      <Pencil className="size-3.5 text-neutral-400" />
                      <Trash2 className="size-3.5 text-red-400" />
                    </div>
                  </div>
                  <p className="truncate italic font-mono text-neutral-500 text-[10px] mt-1">{`// Deep research & web synthesis agent`}</p>
                  <div className="flex mt-1.5 flex-wrap gap-1">
                    <span className="bg-[oklch(0.708_0.15_295)]/15 text-[oklch(0.708_0.15_295)] font-mono uppercase rounded-full text-[9px] tracking-widest flex px-2 py-0.5 items-center gap-1">
                      <Wrench className="size-2" />
                      Tools
                    </span>
                    <span className="font-mono uppercase rounded-full bg-blue-400/15 text-blue-400 text-[9px] tracking-widest flex px-2 py-0.5 items-center gap-1">
                      <Brain className="size-2" />
                      Memory
                    </span>
                    <span className="font-mono uppercase rounded-full bg-amber-400/15 text-amber-400 text-[9px] tracking-widest flex px-2 py-0.5 items-center gap-1">
                      <Eye className="size-2" />
                      Vision
                    </span>
                    <span className="font-mono uppercase rounded-full bg-emerald-400/15 text-emerald-400 text-[9px] tracking-widest flex px-2 py-0.5 items-center gap-1">
                      <Server className="size-2" />
                      MCP
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <div className="relative rounded-xl bg-neutral-900 border-white/10 border-1 border-solid p-3 overflow-hidden">
              <div className="bg-[oklch(0.708_0.15_295)] rounded-l-xl absolute left-0 inset-y-0 w-0.5" />
              <div className="flex items-start gap-2.5">
                <div className="size-7 shrink-0 rounded-lg bg-neutral-800 flex mt-0.5 justify-center items-center">
                  <Code2 className="size-4 text-[oklch(0.708_0.15_295)]" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex justify-between items-center gap-2">
                    <div className="min-w-0">
                      <p className="leading-tight font-mono font-bold text-neutral-50 text-sm leading-5">
                        CodeAssist
                      </p>
                      <p className="leading-tight font-mono text-neutral-400 text-[10px]">
                        claude-3.5-sonnet
                      </p>
                    </div>
                    <div className="shrink-0 flex items-center gap-2">
                      <Switch className="scale-75" checked={true} />
                      <Pencil className="size-3.5 text-neutral-400" />
                      <Trash2 className="size-3.5 text-red-400" />
                    </div>
                  </div>
                  <p className="truncate italic font-mono text-neutral-500 text-[10px] mt-1">{`// Code generation, review & debugging`}</p>
                  <div className="flex mt-1.5 flex-wrap gap-1">
                    <span className="bg-[oklch(0.708_0.15_295)]/15 text-[oklch(0.708_0.15_295)] font-mono uppercase rounded-full text-[9px] tracking-widest flex px-2 py-0.5 items-center gap-1">
                      <Wrench className="size-2" />
                      Tools
                    </span>
                    <span className="font-mono uppercase rounded-full bg-emerald-400/15 text-emerald-400 text-[9px] tracking-widest flex px-2 py-0.5 items-center gap-1">
                      <Server className="size-2" />
                      MCP
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <div className="relative rounded-xl bg-neutral-900 border-white/10 border-1 border-solid p-3 overflow-hidden">
              <div className="bg-[oklch(0.708_0.15_295)] rounded-l-xl absolute left-0 inset-y-0 w-0.5" />
              <div className="flex items-start gap-2.5">
                <div className="size-7 shrink-0 rounded-lg bg-neutral-800 flex mt-0.5 justify-center items-center">
                  <Cpu className="size-4 text-[oklch(0.708_0.15_295)]" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex justify-between items-center gap-2">
                    <div className="min-w-0">
                      <p className="leading-tight font-mono font-bold text-neutral-50 text-sm leading-5">
                        DataAnalyst
                      </p>
                      <p className="leading-tight font-mono text-neutral-400 text-[10px]">
                        gemini-1.5-pro
                      </p>
                    </div>
                    <div className="shrink-0 flex items-center gap-2">
                      <Switch className="scale-75" checked={true} />
                      <Pencil className="size-3.5 text-neutral-400" />
                      <Trash2 className="size-3.5 text-red-400" />
                    </div>
                  </div>
                  <p className="truncate italic font-mono text-neutral-500 text-[10px] mt-1">{`// Data analysis, charts & file processing`}</p>
                  <div className="flex mt-1.5 flex-wrap gap-1">
                    <span className="bg-[oklch(0.708_0.15_295)]/15 text-[oklch(0.708_0.15_295)] font-mono uppercase rounded-full text-[9px] tracking-widest flex px-2 py-0.5 items-center gap-1">
                      <Wrench className="size-2" />
                      Tools
                    </span>
                    <span className="font-mono uppercase rounded-full bg-blue-400/15 text-blue-400 text-[9px] tracking-widest flex px-2 py-0.5 items-center gap-1">
                      <Brain className="size-2" />
                      Memory
                    </span>
                    <span className="font-mono uppercase rounded-full bg-amber-400/15 text-amber-400 text-[9px] tracking-widest flex px-2 py-0.5 items-center gap-1">
                      <Eye className="size-2" />
                      Vision
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <div className="relative rounded-xl bg-neutral-900 border-white/10 border-1 border-solid p-3 overflow-hidden">
              <div className="bg-[oklch(0.708_0.15_295)] rounded-l-xl absolute left-0 inset-y-0 w-0.5" />
              <div className="flex items-start gap-2.5">
                <div className="size-7 shrink-0 rounded-lg bg-neutral-800 flex mt-0.5 justify-center items-center">
                  <Globe className="size-4 text-[oklch(0.708_0.15_295)]" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex justify-between items-center gap-2">
                    <div className="min-w-0">
                      <p className="leading-tight font-mono font-bold text-neutral-50 text-sm leading-5">
                        CreativeWriter
                      </p>
                      <p className="leading-tight font-mono text-neutral-400 text-[10px]">
                        gpt-4o-mini
                      </p>
                    </div>
                    <div className="shrink-0 flex items-center gap-2">
                      <Switch className="scale-75" checked={true} />
                      <Pencil className="size-3.5 text-neutral-400" />
                      <Trash2 className="size-3.5 text-red-400" />
                    </div>
                  </div>
                  <p className="truncate italic font-mono text-neutral-500 text-[10px] mt-1">{`// Creative writing & storytelling assistant`}</p>
                  <div className="flex mt-1.5 flex-wrap gap-1">
                    <span className="font-mono uppercase rounded-full bg-blue-400/15 text-blue-400 text-[9px] tracking-widest flex px-2 py-0.5 items-center gap-1">
                      <Brain className="size-2" />
                      Memory
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <div className="relative opacity-50 rounded-xl bg-neutral-900 border-white/10 border-1 border-solid p-3 overflow-hidden">
              <div className="flex items-start gap-2.5">
                <div className="size-7 shrink-0 rounded-lg bg-neutral-800 flex mt-0.5 justify-center items-center">
                  <FlaskConical className="size-4 text-neutral-500" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex justify-between items-center gap-2">
                    <div className="min-w-0">
                      <p className="leading-tight font-mono font-bold text-neutral-400 text-sm leading-5">
                        LocalAgent
                      </p>
                      <p className="leading-tight font-mono text-neutral-500 text-[10px]">
                        glm-4
                      </p>
                    </div>
                    <div className="shrink-0 flex items-center gap-2">
                      <Switch className="scale-75" />
                      <Pencil className="size-3.5 text-neutral-600" />
                      <Trash2 className="size-3.5 text-red-900" />
                    </div>
                  </div>
                  <p className="truncate italic font-mono text-neutral-600 text-[10px] mt-1">
                    // Offline local task execution agent
                  </p>
                  <div className="flex mt-1.5 flex-wrap gap-1">
                    <span className="font-mono uppercase rounded-full bg-neutral-800 text-neutral-500 text-[9px] tracking-widest flex px-2 py-0.5 items-center gap-1">
                      <Wrench className="size-2" />
                      Tools
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <p className="font-mono text-neutral-600 text-[10px]">{`// tap edit to configure agent behavior & permissions`}</p>
        </div>
        <div className="sticky z-20 bg-neutral-950 border-white/10 border-t-1 border-r-0 border-b-0 border-l-0 border-solid flex bottom-0 px-4 py-3 justify-between items-center gap-3">
          <div className="flex items-center gap-1.5">
            <Star className="size-3 text-[oklch(0.708_0.15_295)]" />
            <span className="text-[oklch(0.708_0.15_295)] font-mono uppercase text-[10px] tracking-widest">
              ★ DEFAULT ACTIVE AGENT
            </span>
          </div>
          <button className="rounded-lg bg-neutral-900 border-white/10 border-1 border-solid flex px-3 py-1.5 items-center gap-2">
            <span className="font-mono text-neutral-50 text-sm leading-5">
              ResearchBot
            </span>
            <ChevronDown className="size-3.5 text-neutral-400" />
          </button>
        </div>
      </div>
    </div>
  );
}
