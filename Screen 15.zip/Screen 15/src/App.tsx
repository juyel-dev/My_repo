import { useEffect } from "react";
import {
  Bot,
  Brain,
  Check,
  ChevronDown,
  ChevronRight,
  Code2,
  Cpu,
  Eye,
  FlaskConical,
  FolderOpen,
  Globe,
  Info,
  Mic,
  Play,
  RotateCcw,
  Server,
  Settings2,
  Shield,
  SlidersHorizontal,
  Sparkles,
  Wrench,
  X,
} from "lucide-react";
import { Switch } from "@/components/ui/switch";

export default function App() {
  return (
    <div>
      <div className="font-mono bg-neutral-950 text-neutral-50 w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <div className="rounded-t-2xl bg-neutral-900 flex flex-col w-full">
          <div className="flex mt-2 mb-1 justify-center">
            <div className="rounded-full bg-neutral-700 w-10 h-1" />
          </div>
          <div className="border-white/10 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex px-4 pt-2 pb-3 justify-between items-center">
            <span className="font-mono font-bold text-neutral-50 text-base leading-6">
              Edit Agent
            </span>
            <button className="rounded-full bg-neutral-800 p-1">
              <X className="size-4 text-neutral-400" />
            </button>
          </div>
          <div className="overflow-y-auto flex px-3 pb-4 flex-col gap-3">
            <div className="rounded-xl bg-neutral-950 border-white/10 border-1 border-solid flex p-3 flex-col gap-3">
              <div className="flex mb-2 items-center gap-1">
                <Info
                  className="text-[oklch(0.708_0.15_295)]"
                  width={12}
                  height={12}
                />
                <span className="text-[oklch(0.708_0.15_295)] font-mono uppercase text-[10px] tracking-widest">
                  // BASIC
                </span>
              </div>
              <div className="flex flex-col gap-2">
                <div className="flex flex-col gap-1">
                  <span className="font-mono uppercase text-neutral-500 text-[9px] tracking-widest">
                    AVATAR / ICON
                  </span>
                  <div className="flex flex-row gap-2">
                    <div className="border-[oklch(0.708_0.15_295)] rounded-lg bg-neutral-800 border-black/1 border-2 border-solid flex justify-center items-center w-8 h-8">
                      <Bot className="size-4 text-[oklch(0.708_0.15_295)]" />
                    </div>
                    <div className="rounded-lg bg-neutral-800 border-white/10 border-1 border-solid flex justify-center items-center w-8 h-8">
                      <Cpu className="size-4 text-neutral-400" />
                    </div>
                    <div className="rounded-lg bg-neutral-800 border-white/10 border-1 border-solid flex justify-center items-center w-8 h-8">
                      <Code2 className="size-4 text-neutral-400" />
                    </div>
                    <div className="rounded-lg bg-neutral-800 border-white/10 border-1 border-solid flex justify-center items-center w-8 h-8">
                      <Globe className="size-4 text-neutral-400" />
                    </div>
                    <div className="rounded-lg bg-neutral-800 border-white/10 border-1 border-solid flex justify-center items-center w-8 h-8">
                      <FlaskConical className="size-4 text-neutral-400" />
                    </div>
                  </div>
                </div>
                <div className="flex flex-col gap-1">
                  <span className="font-mono uppercase text-neutral-500 text-[9px] tracking-widest">
                    AGENT NAME
                  </span>
                  <input
                    className="placeholder-neutral-600 outline-none font-mono rounded-lg bg-neutral-900 text-neutral-50 text-sm leading-5 border-white/10 border-1 border-solid px-3 py-2 w-full"
                    placeholder="e.g. ResearchBot"
                    defaultValue="ResearchBot"
                  />
                </div>
                <div className="flex flex-col gap-1">
                  <span className="font-mono uppercase text-neutral-500 text-[9px] tracking-widest">
                    DESCRIPTION
                  </span>
                  <textarea
                    className="placeholder-neutral-600 outline-none resize-none font-mono rounded-lg bg-neutral-900 text-neutral-50 text-xs leading-4 border-white/10 border-1 border-solid px-3 py-2 w-full"
                    rows={2}
                    placeholder="// brief description of this agent"
                    defaultValue="// A powerful research assistant with web access"
                  />
                </div>
                <div className="flex flex-col gap-1">
                  <span className="font-mono uppercase text-neutral-500 text-[9px] tracking-widest">
                    ASSIGNED MODEL
                  </span>
                  <div className="rounded-lg bg-neutral-900 border-white/10 border-1 border-solid flex px-3 py-2 justify-between items-center">
                    <span className="font-mono text-neutral-50 text-sm leading-5">
                      gpt-4o
                    </span>
                    <ChevronDown className="size-4 text-neutral-400" />
                  </div>
                </div>
                <div className="flex flex-col gap-1">
                  <span className="font-mono uppercase text-neutral-500 text-[9px] tracking-widest">
                    SYSTEM PROMPT
                  </span>
                  <textarea
                    className="placeholder-neutral-600 outline-none resize-none font-mono rounded-lg bg-neutral-900 text-neutral-50 text-xs leading-4 border-white/10 border-1 border-solid px-3 py-2 w-full"
                    rows={4}
                    placeholder="// You are a helpful research assistant..."
                    defaultValue="// You are a helpful research assistant with access to web search and file tools. Always cite sources."
                  />
                </div>
              </div>
            </div>
            <div className="rounded-xl bg-neutral-950 border-white/10 border-1 border-solid flex p-3 flex-col gap-3">
              <div className="flex mb-2 items-center gap-1">
                <Sparkles
                  className="text-[oklch(0.708_0.15_295)]"
                  width={12}
                  height={12}
                />
                <span className="text-[oklch(0.708_0.15_295)] font-mono uppercase text-[10px] tracking-widest">
                  // CAPABILITIES
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-1">
                    <Eye
                      width={12}
                      height={12}
                      className="text-[oklch(0.708_0.15_295)]"
                    />
                    <span className="font-mono text-neutral-300 text-xs leading-4">
                      Vision
                    </span>
                  </div>
                  <Switch className="scale-75" defaultChecked={true} />
                </div>
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-1">
                    <Wrench
                      width={12}
                      height={12}
                      className="text-[oklch(0.708_0.15_295)]"
                    />
                    <span className="font-mono text-neutral-300 text-xs leading-4">
                      Tool Calling
                    </span>
                  </div>
                  <Switch className="scale-75" defaultChecked={true} />
                </div>
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-1">
                    <Server
                      width={12}
                      height={12}
                      className="text-[oklch(0.708_0.15_295)]"
                    />
                    <span className="font-mono text-neutral-300 text-xs leading-4">
                      MCP Access
                    </span>
                  </div>
                  <Switch className="scale-75" defaultChecked={true} />
                </div>
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-1">
                    <Brain
                      width={12}
                      height={12}
                      className="text-[oklch(0.708_0.15_295)]"
                    />
                    <span className="font-mono text-neutral-300 text-xs leading-4">
                      Memory
                    </span>
                  </div>
                  <Switch className="scale-75" defaultChecked={true} />
                </div>
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-1">
                    <Globe
                      width={12}
                      height={12}
                      className="text-neutral-600"
                    />
                    <span className="font-mono text-neutral-500 text-xs leading-4">
                      Web Search
                    </span>
                  </div>
                  <Switch className="scale-75" defaultChecked={false} />
                </div>
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-1">
                    <FolderOpen
                      width={12}
                      height={12}
                      className="text-neutral-600"
                    />
                    <span className="font-mono text-neutral-500 text-xs leading-4">
                      File Access
                    </span>
                  </div>
                  <Switch className="scale-75" defaultChecked={false} />
                </div>
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-1">
                    <Code2
                      width={12}
                      height={12}
                      className="text-neutral-600"
                    />
                    <span className="font-mono text-neutral-500 text-xs leading-4">
                      Code Interp.
                    </span>
                  </div>
                  <Switch className="scale-75" defaultChecked={false} />
                </div>
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-1">
                    <Mic width={12} height={12} className="text-neutral-600" />
                    <span className="font-mono text-neutral-500 text-xs leading-4">
                      TTS
                    </span>
                  </div>
                  <Switch className="scale-75" defaultChecked={false} />
                </div>
              </div>
            </div>
            <div className="rounded-xl bg-neutral-950 border-white/10 border-1 border-solid flex p-3 flex-col gap-2">
              <div className="flex mb-2 items-center gap-1">
                <SlidersHorizontal
                  className="text-[oklch(0.708_0.15_295)]"
                  width={12}
                  height={12}
                />
                <span className="text-[oklch(0.708_0.15_295)] font-mono uppercase text-[10px] tracking-widest">
                  // BEHAVIOR
                </span>
              </div>
              <span className="font-mono uppercase text-neutral-500 text-[9px] tracking-widest">
                — GENERATION SETTINGS
              </span>
              <div className="flex flex-col gap-1">
                <div className="border-[oklch(0.708_0.15_295)/30] bg-[oklch(0.708_0.15_295)/5] rounded-lg border-black/1 border-1 border-solid flex px-2 py-1 justify-between items-center">
                  <span className="font-mono text-neutral-400 text-xs leading-4">
                    Temperature
                  </span>
                  <div className="flex items-center gap-2">
                    <input
                      className="border-[oklch(0.708_0.15_295)/40] outline-none font-mono text-right rounded-sm bg-neutral-900 text-neutral-50 text-xs leading-4 border-black/1 border-1 border-solid px-1 py-0.5 w-14"
                      defaultValue="0.7"
                    />
                    <span className="bg-[oklch(0.708_0.15_295)/20] text-[oklch(0.708_0.15_295)] font-mono rounded-full text-[10px] px-1.5 py-0.5">
                      ON
                    </span>
                  </div>
                </div>
                <div className="flex px-2 py-1 justify-between items-center">
                  <span className="font-mono text-neutral-400 text-xs leading-4">
                    Top P
                  </span>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-neutral-600 text-[10px]">
                      Agent Default
                    </span>
                    <span className="text-[oklch(0.45_0_0)] font-mono rounded-full bg-neutral-800 text-[10px] px-1.5 py-0.5">
                      OFF
                    </span>
                  </div>
                </div>
                <div className="flex px-2 py-1 justify-between items-center">
                  <span className="font-mono text-neutral-400 text-xs leading-4">
                    Max Tokens
                  </span>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-neutral-600 text-[10px]">
                      Agent Default
                    </span>
                    <span className="text-[oklch(0.45_0_0)] font-mono rounded-full bg-neutral-800 text-[10px] px-1.5 py-0.5">
                      OFF
                    </span>
                  </div>
                </div>
                <div className="flex px-2 py-1 justify-between items-center">
                  <span className="font-mono text-neutral-400 text-xs leading-4">
                    Reasoning Effort
                  </span>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-neutral-600 text-[10px]">
                      Agent Default
                    </span>
                    <span className="text-[oklch(0.45_0_0)] font-mono rounded-full bg-neutral-800 text-[10px] px-1.5 py-0.5">
                      OFF
                    </span>
                  </div>
                </div>
              </div>
              <span className="font-mono uppercase text-neutral-500 text-[9px] tracking-widest mt-2">
                — RESPONSE STYLE
              </span>
              <div className="flex mt-1 flex-row gap-1">
                <button className="font-mono uppercase rounded-full bg-neutral-800 text-neutral-400 text-[10px] py-1 flex-1">
                  Concise
                </button>
                <button className="bg-[oklch(0.708_0.15_295)] font-mono uppercase rounded-full text-white text-[10px] py-1 flex-1">
                  Balanced
                </button>
                <button className="font-mono uppercase rounded-full bg-neutral-800 text-neutral-400 text-[10px] py-1 flex-1">
                  Detailed
                </button>
              </div>
              <span className="font-mono uppercase text-neutral-500 text-[9px] tracking-widest mt-2">
                — AGENT PERSONALITY
              </span>
              <div className="grid grid-cols-2 mt-1 gap-1">
                <button className="bg-[oklch(0.708_0.15_295)] font-mono uppercase rounded-full text-white text-[10px] py-1">
                  Professional
                </button>
                <button className="font-mono uppercase rounded-full bg-neutral-800 text-neutral-400 text-[10px] py-1">
                  Creative
                </button>
                <button className="font-mono uppercase rounded-full bg-neutral-800 text-neutral-400 text-[10px] py-1">
                  Technical
                </button>
                <button className="font-mono uppercase rounded-full bg-neutral-800 text-neutral-400 text-[10px] py-1">
                  Casual
                </button>
              </div>
            </div>
            <div className="rounded-xl bg-neutral-950 border-white/10 border-1 border-solid flex p-3 flex-col gap-2">
              <div className="flex mb-2 items-center gap-1">
                <Brain
                  className="text-[oklch(0.708_0.15_295)]"
                  width={12}
                  height={12}
                />
                <span className="text-[oklch(0.708_0.15_295)] font-mono uppercase text-[10px] tracking-widest">
                  // MEMORY
                </span>
              </div>
              <div className="flex flex-col gap-1">
                <div className="flex py-1 justify-between items-center">
                  <div className="flex flex-col">
                    <span className="font-mono text-neutral-300 text-xs leading-4">
                      Persistent Memory
                    </span>
                    <span className="font-mono text-neutral-600 text-[9px]">
                      // retained across sessions
                    </span>
                  </div>
                  <Switch className="scale-75" defaultChecked={true} />
                </div>
                <div className="flex py-1 justify-between items-center">
                  <span className="font-mono text-neutral-300 text-xs leading-4">
                    Session Memory
                  </span>
                  <Switch className="scale-75" defaultChecked={true} />
                </div>
                <div className="flex py-1 justify-between items-center">
                  <span className="font-mono text-neutral-400 text-xs leading-4">
                    Memory Limit
                  </span>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-neutral-600 text-[10px]">
                      Agent Default
                    </span>
                    <span className="text-[oklch(0.45_0_0)] font-mono rounded-full bg-neutral-800 text-[10px] px-1.5 py-0.5">
                      OFF
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <div className="rounded-xl bg-neutral-950 border-white/10 border-1 border-solid flex p-3 flex-col gap-2">
              <div className="flex mb-2 items-center gap-1">
                <Shield
                  className="text-[oklch(0.708_0.15_295)]"
                  width={12}
                  height={12}
                />
                <span className="text-[oklch(0.708_0.15_295)] font-mono uppercase text-[10px] tracking-widest">
                  // PERMISSIONS
                </span>
              </div>
              <div className="flex flex-col gap-1">
                <div className="flex py-1 justify-between items-center">
                  <span className="font-mono text-neutral-300 text-xs leading-4">
                    Allow Tool Execution
                  </span>
                  <Switch className="scale-75" defaultChecked={true} />
                </div>
                <div className="flex py-1 justify-between items-center">
                  <span className="font-mono text-neutral-300 text-xs leading-4">
                    Allow External Requests
                  </span>
                  <Switch className="scale-75" defaultChecked={true} />
                </div>
                <div className="flex py-1 justify-between items-center">
                  <span className="font-mono text-neutral-300 text-xs leading-4">
                    Allow File Access
                  </span>
                  <Switch className="scale-75" defaultChecked={false} />
                </div>
                <div className="flex py-1 justify-between items-center">
                  <span className="font-mono text-neutral-300 text-xs leading-4">
                    Confirmation Before Actions
                  </span>
                  <Switch className="scale-75" defaultChecked={true} />
                </div>
              </div>
              <span className="font-mono text-neutral-600 text-[9px]">
                // agent will prompt before executing destructive actions
              </span>
            </div>
            <div className="rounded-xl bg-neutral-950 border-white/10 border-1 border-solid flex p-3 flex-col gap-2">
              <div className="flex mb-2 items-center gap-1">
                <Settings2
                  className="text-[oklch(0.708_0.15_295)]"
                  width={12}
                  height={12}
                />
                <span className="text-[oklch(0.708_0.15_295)] font-mono uppercase text-[10px] tracking-widest">
                  // ADVANCED
                </span>
              </div>
              <span className="font-mono uppercase text-neutral-500 text-[9px] tracking-widest">
                — TOOL ROUTING
              </span>
              <div className="flex mt-1 flex-col gap-1">
                <div className="rounded-lg bg-neutral-900 border-white/10 border-1 border-solid flex px-3 py-2 justify-between items-center">
                  <span className="font-mono text-neutral-300 text-xs leading-4">
                    Preferred MCP Server
                  </span>
                  <div className="flex items-center gap-1">
                    <span className="font-mono text-neutral-500 text-xs leading-4">
                      filesystem-mcp
                    </span>
                    <ChevronRight className="size-3 text-neutral-400" />
                  </div>
                </div>
                <div className="rounded-lg bg-neutral-900 border-white/10 border-1 border-solid flex px-3 py-2 justify-between items-center">
                  <span className="font-mono text-neutral-300 text-xs leading-4">
                    Preferred Tools
                  </span>
                  <div className="flex items-center gap-1">
                    <span className="bg-[oklch(0.708_0.15_295)/20] text-[oklch(0.708_0.15_295)] font-mono rounded-full text-[10px] px-1.5 py-0.5">
                      3 selected
                    </span>
                    <ChevronRight className="size-3 text-neutral-400" />
                  </div>
                </div>
                <div className="rounded-lg bg-neutral-900 border-white/10 border-1 border-solid flex px-3 py-2 justify-between items-center">
                  <span className="font-mono text-neutral-300 text-xs leading-4">
                    Tool Priority
                  </span>
                  <div className="flex items-center gap-1">
                    <span className="font-mono text-neutral-500 text-xs leading-4">
                      Speed
                    </span>
                    <ChevronDown className="size-3 text-neutral-400" />
                  </div>
                </div>
              </div>
              <span className="font-mono uppercase text-neutral-500 text-[9px] tracking-widest mt-2">
                — DEVELOPER OPTIONS
              </span>
              <div className="flex mt-1 flex-col gap-1">
                <div className="flex py-1 justify-between items-center">
                  <span className="font-mono text-neutral-300 text-xs leading-4">
                    Debug Logs
                  </span>
                  <Switch className="scale-75" defaultChecked={false} />
                </div>
                <div className="rounded-lg bg-neutral-900 border-white/10 border-1 border-solid flex px-3 py-2 justify-between items-center">
                  <span className="font-mono text-neutral-300 text-xs leading-4">
                    Raw System Prompt
                  </span>
                  <ChevronRight className="size-3 text-neutral-400" />
                </div>
                <div className="rounded-lg bg-neutral-900 border-white/10 border-1 border-solid flex px-3 py-2 justify-between items-center">
                  <span className="font-mono text-neutral-300 text-xs leading-4">
                    JSON Config
                  </span>
                  <ChevronRight className="size-3 text-neutral-400" />
                </div>
                <div className="rounded-lg bg-neutral-900 border-white/10 border-1 border-solid flex px-3 py-2 justify-between items-center">
                  <span className="font-mono text-neutral-300 text-xs leading-4">
                    Custom Variables
                  </span>
                  <div className="flex items-center gap-1">
                    <span className="bg-[oklch(0.708_0.15_295)/20] text-[oklch(0.708_0.15_295)] font-mono rounded-full text-[10px] px-1.5 py-0.5">
                      2
                    </span>
                    <ChevronRight className="size-3 text-neutral-400" />
                  </div>
                </div>
              </div>
            </div>
            <div className="rounded-xl bg-neutral-950 border-white/10 border-1 border-solid flex p-3 flex-col gap-2">
              <div className="flex mb-2 items-center gap-1">
                <FlaskConical
                  className="text-[oklch(0.708_0.15_295)]"
                  width={12}
                  height={12}
                />
                <span className="text-[oklch(0.708_0.15_295)] font-mono uppercase text-[10px] tracking-widest">
                  // EXPERIMENTAL
                </span>
              </div>
              <div className="flex flex-col gap-1">
                <div className="flex py-1 flex-col gap-0.5">
                  <div className="flex justify-between items-center">
                    <span className="font-mono text-neutral-300 text-xs leading-4">
                      Multi-Agent Collaboration
                    </span>
                    <Switch className="scale-75" defaultChecked={false} />
                  </div>
                  <span className="font-mono text-neutral-600 text-[9px]">
                    // enables agent-to-agent delegation
                  </span>
                </div>
                <div className="flex py-1 justify-between items-center">
                  <span className="font-mono text-neutral-300 text-xs leading-4">
                    Auto Tool Selection
                  </span>
                  <Switch className="scale-75" defaultChecked={true} />
                </div>
                <div className="flex py-1 flex-col gap-0.5">
                  <div className="flex justify-between items-center">
                    <span className="font-mono text-neutral-300 text-xs leading-4">
                      Autonomous Mode
                    </span>
                    <Switch className="scale-75" defaultChecked={false} />
                  </div>
                  <span className="font-mono text-red-400/60 text-[9px]">
                    // agent acts without confirmation
                  </span>
                </div>
                <div className="flex py-1 flex-col gap-0.5">
                  <div className="flex justify-between items-center">
                    <span className="font-mono text-neutral-300 text-xs leading-4">
                      Background Task Mode
                    </span>
                    <Switch className="scale-75" defaultChecked={false} />
                  </div>
                  <span className="font-mono text-neutral-600 text-[9px]">
                    // runs tasks in background
                  </span>
                </div>
              </div>
            </div>
          </div>
          <div className="bg-neutral-900 border-white/10 border-t-1 border-r-0 border-b-0 border-l-0 border-solid flex px-4 py-3 flex-row gap-2">
            <button className="font-mono rounded-xl text-neutral-300 text-xs leading-4 border-white/20 border-1 border-solid flex py-2 justify-center items-center flex-1 gap-1">
              <Play width={12} height={12} />
              Test Agent
            </button>
            <button className="font-mono rounded-xl text-neutral-400 text-xs leading-4 border-white/20 border-1 border-solid flex py-2 justify-center items-center flex-1 gap-1">
              <RotateCcw width={12} height={12} />
              Reset
            </button>
            <button className="bg-[oklch(0.708_0.15_295)] font-mono font-bold rounded-xl text-white text-xs leading-4 flex py-2 justify-center items-center flex-1 gap-1">
              <Check width={12} height={12} />
              Save Changes
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
