import { useEffect } from "react";
import {
  ArrowLeft,
  ChevronRight,
  Cpu,
  MessageCircle,
  Plus,
  Server,
  Settings,
} from "lucide-react";
import { Switch } from "@/components/ui/switch";

export default function App() {
  return (
    <div>
      <div className="font-mono bg-neutral-950 text-neutral-50 w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <div className="sticky z-10 bg-neutral-950 border-white/10 border-t-0 border-r-0 border-b-1 border-l-0 border-solid top-0">
          <div className="flex px-4 items-center gap-4 h-14">
            <button className="size-8 rounded-lg text-[#a1a1a1] flex justify-center items-center">
              <ArrowLeft className="size-5" />
            </button>
            <span className="font-semibold text-base leading-6 tracking-wide">
              Provider Settings
            </span>
          </div>
        </div>
        <div className="flex px-4 pt-4 pb-24 flex-col gap-4">
          <div className="flex px-1 items-center gap-2">
            <Cpu className="size-3.5 text-[#a1a1a1]" />
            <span className="font-bold text-[#a1a1a1] text-xs leading-4 tracking-widest">
              // PROVIDERS
            </span>
          </div>
          <div className="flex flex-col gap-2">
            <div className="relative rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex items-center overflow-hidden">
              <div className="bg-[oklch(0.708_0.15_295)] absolute left-0 inset-y-0 w-0.5" />
              <div className="flex pl-5 pr-4 py-3.5 justify-between items-center flex-1">
                <div className="flex items-center gap-3">
                  <div className="size-7 rounded-md bg-neutral-800 border-white/10 border-1 border-solid flex justify-center items-center">
                    <span className="text-[oklch(0.985_0_0)] font-bold text-xs leading-4">
                      OA
                    </span>
                  </div>
                  <div className="flex flex-col gap-0.5">
                    <span className="text-[#e0e0e0] text-sm leading-5">
                      OpenAI
                    </span>
                    <span className="text-[#a1a1a1] text-xs leading-4">
                      gpt-4o · gpt-4-turbo
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Switch defaultChecked={true} />
                  <ChevronRight className="size-4 text-[#a1a1a1]" />
                </div>
              </div>
            </div>
            <div className="relative rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex items-center overflow-hidden">
              <div className="bg-[oklch(0.708_0.15_295)] absolute left-0 inset-y-0 w-0.5" />
              <div className="flex pl-5 pr-4 py-3.5 justify-between items-center flex-1">
                <div className="flex items-center gap-3">
                  <div className="size-7 rounded-md bg-neutral-800 border-white/10 border-1 border-solid flex justify-center items-center">
                    <span className="text-[oklch(0.696_0.17_162.48)] font-bold text-xs leading-4">
                      G
                    </span>
                  </div>
                  <div className="flex flex-col gap-0.5">
                    <span className="text-[#e0e0e0] text-sm leading-5">
                      Google
                    </span>
                    <span className="text-[#a1a1a1] text-xs leading-4">
                      gemini-1.5-pro · flash
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Switch defaultChecked={true} />
                  <ChevronRight className="size-4 text-[#a1a1a1]" />
                </div>
              </div>
            </div>
            <div className="relative rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex items-center overflow-hidden">
              <div className="bg-[oklch(0.708_0.15_295)] absolute left-0 inset-y-0 w-0.5" />
              <div className="flex pl-5 pr-4 py-3.5 justify-between items-center flex-1">
                <div className="flex items-center gap-3">
                  <div className="size-7 rounded-md bg-neutral-800 border-white/10 border-1 border-solid flex justify-center items-center">
                    <span className="text-[oklch(0.769_0.188_70.08)] font-bold text-xs leading-4">
                      An
                    </span>
                  </div>
                  <div className="flex flex-col gap-0.5">
                    <span className="text-[#e0e0e0] text-sm leading-5">
                      Anthropic
                    </span>
                    <span className="text-[#a1a1a1] text-xs leading-4">
                      claude-3.5-sonnet
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Switch defaultChecked={true} />
                  <ChevronRight className="size-4 text-[#a1a1a1]" />
                </div>
              </div>
            </div>
            <div className="relative rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex items-center overflow-hidden">
              <div className="flex px-4 py-3.5 justify-between items-center flex-1">
                <div className="flex items-center gap-3">
                  <div className="size-7 rounded-md bg-neutral-800 border-white/10 border-1 border-solid flex justify-center items-center">
                    <span className="font-bold text-[#e0e0e0] text-xs leading-4">
                      DS
                    </span>
                  </div>
                  <div className="flex flex-col gap-0.5">
                    <span className="text-[#e0e0e0] text-sm leading-5">
                      DeepSeek
                    </span>
                    <span className="text-[#a1a1a1] text-xs leading-4">
                      deepseek-chat · coder
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Switch defaultChecked={false} />
                  <ChevronRight className="size-4 text-[#a1a1a1]" />
                </div>
              </div>
            </div>
            <div className="relative rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex items-center overflow-hidden">
              <div className="flex px-4 py-3.5 justify-between items-center flex-1">
                <div className="flex items-center gap-3">
                  <div className="size-7 rounded-md bg-neutral-800 border-white/10 border-1 border-solid flex justify-center items-center">
                    <span className="font-bold text-[#e0e0e0] text-xs leading-4">
                      Gk
                    </span>
                  </div>
                  <div className="flex flex-col gap-0.5">
                    <span className="text-[#e0e0e0] text-sm leading-5">
                      Grok
                    </span>
                    <span className="text-[#a1a1a1] text-xs leading-4">
                      grok-2 · grok-vision
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Switch defaultChecked={false} />
                  <ChevronRight className="size-4 text-[#a1a1a1]" />
                </div>
              </div>
            </div>
            <div className="relative rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex items-center overflow-hidden">
              <div className="bg-[oklch(0.708_0.15_295)] absolute left-0 inset-y-0 w-0.5" />
              <div className="flex pl-5 pr-4 py-3.5 justify-between items-center flex-1">
                <div className="flex items-center gap-3">
                  <div className="size-7 rounded-md bg-neutral-800 border-white/10 border-1 border-solid flex justify-center items-center">
                    <span className="text-[oklch(0.627_0.265_303.9)] font-bold text-xs leading-4">
                      Mi
                    </span>
                  </div>
                  <div className="flex flex-col gap-0.5">
                    <span className="text-[#e0e0e0] text-sm leading-5">
                      Mistral
                    </span>
                    <span className="text-[#a1a1a1] text-xs leading-4">
                      mistral-large · nemo
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Switch defaultChecked={true} />
                  <ChevronRight className="size-4 text-[#a1a1a1]" />
                </div>
              </div>
            </div>
            <div className="relative rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex items-center overflow-hidden">
              <div className="flex px-4 py-3.5 justify-between items-center flex-1">
                <div className="flex items-center gap-3">
                  <div className="size-7 rounded-md bg-neutral-800 border-white/10 border-1 border-solid flex justify-center items-center">
                    <span className="text-[oklch(0.696_0.17_162.48)] font-bold text-xs leading-4">
                      Nv
                    </span>
                  </div>
                  <div className="flex flex-col gap-0.5">
                    <span className="text-[#e0e0e0] text-sm leading-5">
                      Nvidia NIM
                    </span>
                    <span className="text-[#a1a1a1] text-xs leading-4">
                      llama-3.1 · nemotron
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Switch defaultChecked={false} />
                  <ChevronRight className="size-4 text-[#a1a1a1]" />
                </div>
              </div>
            </div>
            <div className="relative rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex items-center overflow-hidden">
              <div className="bg-[oklch(0.708_0.15_295)] absolute left-0 inset-y-0 w-0.5" />
              <div className="flex pl-5 pr-4 py-3.5 justify-between items-center flex-1">
                <div className="flex items-center gap-3">
                  <div className="size-7 rounded-md bg-neutral-800 border-white/10 border-1 border-solid flex justify-center items-center">
                    <span className="text-[oklch(0.488_0.243_264.376)] font-bold text-xs leading-4">
                      GL
                    </span>
                  </div>
                  <div className="flex flex-col gap-0.5">
                    <span className="text-[#e0e0e0] text-sm leading-5">
                      GLM
                    </span>
                    <span className="text-[#a1a1a1] text-xs leading-4">
                      glm-4 · glm-4v
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Switch defaultChecked={true} />
                  <ChevronRight className="size-4 text-[#a1a1a1]" />
                </div>
              </div>
            </div>
            <div className="relative rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex items-center overflow-hidden">
              <div className="flex px-4 py-3.5 justify-between items-center flex-1">
                <div className="flex items-center gap-3">
                  <div className="size-7 rounded-md bg-neutral-800 border-white/10 border-1 border-solid flex justify-center items-center">
                    <span className="font-bold text-[#e0e0e0] text-xs leading-4">
                      OR
                    </span>
                  </div>
                  <div className="flex flex-col gap-0.5">
                    <span className="text-[#e0e0e0] text-sm leading-5">
                      Open Router
                    </span>
                    <span className="text-[#a1a1a1] text-xs leading-4">
                      multi-model gateway
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Switch defaultChecked={false} />
                  <ChevronRight className="size-4 text-[#a1a1a1]" />
                </div>
              </div>
            </div>
            <div className="relative rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex items-center overflow-hidden">
              <div className="flex px-4 py-3.5 justify-between items-center flex-1">
                <div className="flex items-center gap-3">
                  <div className="size-7 rounded-md bg-neutral-800 border-white/10 border-1 border-solid flex justify-center items-center">
                    <span className="text-[oklch(0.769_0.188_70.08)] font-bold text-xs leading-4">
                      HF
                    </span>
                  </div>
                  <div className="flex flex-col gap-0.5">
                    <span className="text-[#e0e0e0] text-sm leading-5">
                      Hugging Face
                    </span>
                    <span className="text-[#a1a1a1] text-xs leading-4">
                      inference API
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Switch defaultChecked={false} />
                  <ChevronRight className="size-4 text-[#a1a1a1]" />
                </div>
              </div>
            </div>
            <div className="relative rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex items-center overflow-hidden">
              <div className="bg-[oklch(0.708_0.15_295)] absolute left-0 inset-y-0 w-0.5" />
              <div className="flex pl-5 pr-4 py-3.5 justify-between items-center flex-1">
                <div className="flex items-center gap-3">
                  <div className="size-7 rounded-md bg-neutral-800 border-white/10 border-1 border-solid flex justify-center items-center">
                    <Server className="size-3.5 text-[oklch(0.696_0.17_162.48)]" />
                  </div>
                  <div className="flex flex-col gap-0.5">
                    <span className="text-[#e0e0e0] text-sm leading-5">
                      Ollama
                    </span>
                    <span className="text-[#a1a1a1] text-xs leading-4">
                      local · llama3 · phi3
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Switch defaultChecked={true} />
                  <ChevronRight className="size-4 text-[#a1a1a1]" />
                </div>
              </div>
            </div>
            <div className="relative rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex items-center overflow-hidden">
              <div className="flex px-4 py-3.5 justify-between items-center flex-1">
                <div className="flex items-center gap-3">
                  <div className="size-7 rounded-md bg-neutral-800 border-white/10 border-1 border-solid flex justify-center items-center">
                    <span className="text-[oklch(0.645_0.246_16.439)] font-bold text-xs leading-4">
                      Al
                    </span>
                  </div>
                  <div className="flex flex-col gap-0.5">
                    <span className="text-[#e0e0e0] text-sm leading-5">
                      Alibaba
                    </span>
                    <span className="text-[#a1a1a1] text-xs leading-4">
                      qwen-max · qwen-plus
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Switch defaultChecked={false} />
                  <ChevronRight className="size-4 text-[#a1a1a1]" />
                </div>
              </div>
            </div>
          </div>
          <div className="flex mt-2 px-1 items-center gap-2">
            <span className="text-[#a1a1a1] text-xs leading-4">{`// tap a provider to configure API key & models`}</span>
          </div>
        </div>
        <div className="fixed z-20 right-5 bottom-20">
          <button className="size-12 bg-[oklch(0.708_0.15_295)] rounded-full flex justify-center items-center">
            <Plus className="size-5 text-neutral-950" />
          </button>
        </div>
        <div className="fixed z-10 bg-neutral-950 border-white/10 border-t-1 border-r-0 border-b-0 border-l-0 border-solid inset-x-0 bottom-0">
          <div className="flex px-4 flex-row justify-around items-center h-16">
            <button className="flex flex-col items-center gap-1">
              <MessageCircle className="size-5 text-[#a1a1a1]" />
              <span className="text-[#a1a1a1] text-xs leading-4">Chats</span>
            </button>
            <button className="flex flex-col items-center gap-1">
              <Settings className="size-5 text-[oklch(0.985_0_0)]" />
              <span className="text-[oklch(0.985_0_0)] text-xs leading-4">
                Settings
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
