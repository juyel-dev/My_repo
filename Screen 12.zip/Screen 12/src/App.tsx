import { useEffect } from "react";
import {
  BarChart2,
  Check,
  ChevronRight,
  Code2,
  Database,
  Eye,
  FlaskConical,
  Info,
  MessageSquare,
  Plug,
  RotateCcw,
  Shield,
  Sparkles,
  Wifi,
  Wrench,
  X,
  Zap,
} from "lucide-react";
import { Switch } from "@/components/ui/switch";

export default function App() {
  return (
    <div>
      <div className="font-mono bg-neutral-950 text-neutral-50 w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <div className="relative bg-[oklch(0.10_0_0)] min-h-screen flex flex-col w-full">
          <div className="bg-[oklch(0.10_0_0)] absolute inset-0" />
          <div className="relative z-10 flex flex-col h-full">
            <div className="flex flex-col justify-end flex-1">
              <div className="rounded-t-2xl bg-neutral-900 flex flex-col">
                <div className="bg-neutral-900 flex flex-col overflow-hidden">
                  <div className="flex pt-3 pb-2 justify-center">
                    <div className="rounded-full bg-neutral-700 w-10 h-1" />
                  </div>
                  <div className="border-white/10 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex px-4 pb-3 justify-between items-center">
                    <span className="font-mono font-bold text-neutral-50 text-base leading-6">
                      Edit MCP Server
                    </span>
                    <button className="rounded-full bg-neutral-800 flex justify-center items-center w-8 h-8">
                      <X className="size-4 text-neutral-400" />
                    </button>
                  </div>
                  <div className="overflow-y-auto flex p-4 flex-col gap-3">
                    <div className="rounded-xl bg-neutral-950 border-white/10 border-1 border-solid flex p-4 flex-col gap-3">
                      <div className="flex mb-1 items-center gap-2">
                        <Info className="size-3 text-[oklch(0.708_0.15_295)]" />
                        <span className="text-[oklch(0.708_0.15_295)] font-mono uppercase text-[10px] tracking-widest">
                          // BASIC
                        </span>
                      </div>
                      <div className="flex flex-col gap-1">
                        <label className="font-mono uppercase text-neutral-500 text-[10px] tracking-widest">
                          Server Name
                        </label>
                        <input
                          className="placeholder-neutral-600 outline-none font-mono rounded-lg bg-neutral-900 text-neutral-200 text-xs leading-4 border-white/10 border-1 border-solid px-3 py-2 w-full"
                          placeholder="e.g. filesystem-mcp"
                        />
                      </div>
                      <div className="flex flex-col gap-1">
                        <label className="font-mono uppercase text-neutral-500 text-[10px] tracking-widest">
                          Transport Type
                        </label>
                        <div className="grid grid-cols-2 gap-2">
                          <button className="bg-[oklch(0.708_0.15_295)] font-mono uppercase rounded-lg text-white text-[11px] px-3 py-2">
                            STDIO
                          </button>
                          <button className="font-mono uppercase rounded-lg bg-neutral-800 text-neutral-400 text-[11px] px-3 py-2">
                            SSE
                          </button>
                          <button className="font-mono uppercase rounded-lg bg-neutral-800 text-neutral-400 text-[11px] px-3 py-2">
                            WebSocket
                          </button>
                          <button className="font-mono uppercase rounded-lg bg-neutral-800 text-neutral-400 text-[11px] px-3 py-2">
                            HTTP
                          </button>
                        </div>
                      </div>
                      <div className="flex flex-col gap-1">
                        <label className="font-mono uppercase text-neutral-500 text-[10px] tracking-widest">
                          Host / Endpoint URL
                        </label>
                        <input
                          className="placeholder-neutral-600 outline-none font-mono rounded-lg bg-neutral-900 text-neutral-200 text-xs leading-4 border-white/10 border-1 border-solid px-3 py-2 w-full"
                          placeholder="e.g. /usr/bin/mcp-server or https://..."
                        />
                      </div>
                      <div className="flex gap-3">
                        <div className="flex flex-col gap-1">
                          <label className="font-mono uppercase text-neutral-500 text-[10px] tracking-widest">
                            Port
                          </label>
                          <input
                            className="placeholder-neutral-600 outline-none font-mono rounded-lg bg-neutral-900 text-neutral-200 text-xs leading-4 border-white/10 border-1 border-solid px-3 py-2 w-24"
                            placeholder="3000"
                          />
                        </div>
                        <div className="flex flex-col flex-1 gap-1">
                          <label className="font-mono uppercase text-neutral-500 text-[10px] tracking-widest">
                            API Key / Auth Token
                          </label>
                          <div className="rounded-lg bg-neutral-900 border-white/10 border-1 border-solid flex px-3 py-2 items-center gap-2">
                            <input
                              className="bg-transparent placeholder-neutral-600 outline-none font-mono text-neutral-200 text-xs leading-4 flex-1"
                              placeholder="// auth token or bearer key"
                              type="password"
                            />
                            <Eye className="size-3.5 flex-shrink-0 text-neutral-500" />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="rounded-xl bg-neutral-950 border-white/10 border-1 border-solid flex p-4 flex-col gap-3">
                      <div className="flex mb-1 items-center gap-2">
                        <Sparkles className="size-3 text-[oklch(0.708_0.15_295)]" />
                        <span className="text-[oklch(0.708_0.15_295)] font-mono uppercase text-[10px] tracking-widest">
                          // CAPABILITIES
                        </span>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div className="rounded-lg bg-neutral-900 flex px-3 py-2 items-center gap-2">
                          <Wrench className="size-3 text-[oklch(0.708_0.15_295)]" />
                          <span className="font-mono text-neutral-300 text-xs leading-4 flex-1">
                            Tools
                          </span>
                          <Switch className="scale-75" checked={true} />
                        </div>
                        <div className="rounded-lg bg-neutral-900 flex px-3 py-2 items-center gap-2">
                          <Database className="size-3 text-[oklch(0.708_0.15_295)]" />
                          <span className="font-mono text-neutral-300 text-xs leading-4 flex-1">
                            Resources
                          </span>
                          <Switch className="scale-75" checked={true} />
                        </div>
                        <div className="rounded-lg bg-neutral-900 flex px-3 py-2 items-center gap-2">
                          <MessageSquare className="size-3 text-[oklch(0.708_0.15_295)]" />
                          <span className="font-mono text-neutral-300 text-xs leading-4 flex-1">
                            Prompts
                          </span>
                          <Switch className="scale-75" checked={true} />
                        </div>
                        <div className="rounded-lg bg-neutral-900 flex px-3 py-2 items-center gap-2">
                          <BarChart2 className="size-3 text-neutral-600" />
                          <span className="font-mono text-neutral-500 text-xs leading-4 flex-1">
                            Sampling
                          </span>
                          <Switch className="scale-75" />
                        </div>
                        <div className="col-span-2 rounded-lg bg-neutral-900 flex px-3 py-2 items-center gap-2">
                          <Zap className="size-3 text-[oklch(0.708_0.15_295)]" />
                          <span className="font-mono text-neutral-300 text-xs leading-4 flex-1">
                            Streaming
                          </span>
                          <Switch className="scale-75" checked={true} />
                        </div>
                      </div>
                    </div>
                    <div className="rounded-xl bg-neutral-950 border-white/10 border-1 border-solid flex p-4 flex-col gap-3">
                      <div className="flex mb-1 items-center gap-2">
                        <Wifi className="size-3 text-[oklch(0.708_0.15_295)]" />
                        <span className="text-[oklch(0.708_0.15_295)] font-mono uppercase text-[10px] tracking-widest">
                          // CONNECTION SETTINGS
                        </span>
                      </div>
                      <div className="border-white/5 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex py-2 justify-between items-center">
                        <span className="font-mono text-neutral-300 text-xs leading-4">
                          Timeout
                        </span>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-neutral-600 text-[10px]">
                            Provider Default
                          </span>
                          <span className="text-[oklch(0.45_0_0)] font-mono rounded-md bg-neutral-800 text-[10px] px-2 py-0.5">
                            OFF
                          </span>
                        </div>
                      </div>
                      <div className="border-white/5 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex py-2 justify-between items-center">
                        <span className="font-mono text-neutral-300 text-xs leading-4">
                          Retry Count
                        </span>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-neutral-600 text-[10px]">
                            Provider Default
                          </span>
                          <span className="text-[oklch(0.45_0_0)] font-mono rounded-md bg-neutral-800 text-[10px] px-2 py-0.5">
                            OFF
                          </span>
                        </div>
                      </div>
                      <div className="border-[oklch(0.708_0.15_295)]/20 border-white/5 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex py-2 justify-between items-center">
                        <span className="font-mono text-neutral-300 text-xs leading-4">
                          Auto Reconnect
                        </span>
                        <Switch className="scale-75" checked={true} />
                      </div>
                      <div className="flex py-2 justify-between items-center">
                        <span className="font-mono text-neutral-300 text-xs leading-4">
                          Heartbeat Interval
                        </span>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-neutral-600 text-[10px]">
                            Provider Default
                          </span>
                          <span className="text-[oklch(0.45_0_0)] font-mono rounded-md bg-neutral-800 text-[10px] px-2 py-0.5">
                            OFF
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="rounded-xl bg-neutral-950 border-white/10 border-1 border-solid flex p-4 flex-col gap-3">
                      <div className="flex mb-1 items-center gap-2">
                        <Shield className="size-3 text-[oklch(0.708_0.15_295)]" />
                        <span className="text-[oklch(0.708_0.15_295)] font-mono uppercase text-[10px] tracking-widest">
                          // SECURITY
                        </span>
                      </div>
                      <div className="rounded-lg bg-neutral-900 flex px-3 py-2.5 justify-between items-center">
                        <span className="font-mono text-neutral-300 text-xs leading-4">
                          Custom Headers
                        </span>
                        <ChevronRight className="size-3.5 text-neutral-600" />
                      </div>
                      <div className="flex flex-col gap-1">
                        <label className="font-mono uppercase text-neutral-500 text-[10px] tracking-widest">
                          OAuth / Bearer Token
                        </label>
                        <div className="rounded-lg bg-neutral-900 border-white/10 border-1 border-solid flex px-3 py-2 items-center gap-2">
                          <input
                            className="bg-transparent placeholder-neutral-600 outline-none font-mono text-neutral-200 text-xs leading-4 flex-1"
                            placeholder="// Bearer sk-..."
                            type="password"
                          />
                        </div>
                      </div>
                      <div className="flex py-1 justify-between items-center">
                        <span className="font-mono text-neutral-300 text-xs leading-4">
                          SSL Verification
                        </span>
                        <Switch className="scale-75" checked={true} />
                      </div>
                    </div>
                    <div className="rounded-xl bg-neutral-950 border-white/10 border-1 border-solid flex p-4 flex-col gap-3">
                      <div className="flex mb-1 items-center gap-2">
                        <Code2 className="size-3 text-[oklch(0.708_0.15_295)]" />
                        <span className="text-[oklch(0.708_0.15_295)] font-mono uppercase text-[10px] tracking-widest">
                          // DEVELOPER OPTIONS
                        </span>
                      </div>
                      <div className="border-white/5 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex py-2 justify-between items-center">
                        <span className="font-mono text-neutral-300 text-xs leading-4">
                          Debug Logs
                        </span>
                        <Switch className="scale-75" />
                      </div>
                      <div className="rounded-lg bg-neutral-900 flex mt-1 px-3 py-2.5 justify-between items-center">
                        <span className="font-mono text-neutral-300 text-xs leading-4">
                          Raw JSON Config
                        </span>
                        <ChevronRight className="size-3.5 text-neutral-600" />
                      </div>
                      <div className="rounded-lg bg-neutral-900 flex px-3 py-2.5 justify-between items-center">
                        <span className="font-mono text-neutral-300 text-xs leading-4">
                          Request Inspector
                        </span>
                        <ChevronRight className="size-3.5 text-neutral-600" />
                      </div>
                      <div className="rounded-lg bg-neutral-900 flex px-3 py-2.5 justify-between items-center">
                        <span className="font-mono text-neutral-300 text-xs leading-4 flex-1">
                          Custom Environment Variables
                        </span>
                        <div className="flex items-center gap-2">
                          <span className="bg-[oklch(0.708_0.15_295)]/20 text-[oklch(0.708_0.15_295)] font-mono rounded-md text-[10px] px-1.5 py-0.5">
                            2
                          </span>
                          <ChevronRight className="size-3.5 text-neutral-600" />
                        </div>
                      </div>
                    </div>
                    <div className="rounded-xl bg-neutral-950 border-white/10 border-1 border-solid flex p-4 flex-col gap-3">
                      <div className="flex mb-1 items-center gap-2">
                        <FlaskConical className="size-3 text-[oklch(0.708_0.15_295)]" />
                        <span className="text-[oklch(0.708_0.15_295)] font-mono uppercase text-[10px] tracking-widest">
                          // EXPERIMENTAL
                        </span>
                      </div>
                      <div className="rounded-lg bg-neutral-900 flex px-3 py-2.5 justify-between items-center">
                        <span className="font-mono text-neutral-300 text-xs leading-4">
                          Tool Permission Rules
                        </span>
                        <ChevronRight className="size-3.5 text-neutral-600" />
                      </div>
                      <div className="border-white/5 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex py-2 justify-between items-center">
                        <span className="font-mono text-neutral-300 text-xs leading-4">
                          Rate Limit Overrides
                        </span>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-neutral-600 text-[10px]">
                            Provider Default
                          </span>
                          <span className="text-[oklch(0.45_0_0)] font-mono rounded-md bg-neutral-800 text-[10px] px-2 py-0.5">
                            OFF
                          </span>
                        </div>
                      </div>
                      <div className="border-white/5 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex py-2 justify-between items-center">
                        <span className="font-mono text-neutral-300 text-xs leading-4">
                          Parallel Tool Calls
                        </span>
                        <Switch className="scale-75" />
                      </div>
                      <div className="flex py-2 flex-col gap-1">
                        <div className="flex justify-between items-center">
                          <span className="font-mono text-neutral-300 text-xs leading-4">
                            Sandbox Mode
                          </span>
                          <Switch className="scale-75" />
                        </div>
                        <span className="font-mono text-neutral-600 text-[10px]">
                          // isolates server process
                        </span>
                      </div>
                    </div>
                    <div className="h-4" />
                  </div>
                  <div className="bg-neutral-900 border-white/10 border-t-1 border-r-0 border-b-0 border-l-0 border-solid flex px-4 py-3 gap-2">
                    <button className="font-mono rounded-xl text-neutral-400 text-xs leading-4 border-white/20 border-1 border-solid flex py-2.5 justify-center items-center flex-1 gap-1.5">
                      <Plug className="size-3" />
                      Test Connection
                    </button>
                    <button className="font-mono rounded-xl text-neutral-400 text-xs leading-4 border-white/20 border-1 border-solid flex py-2.5 justify-center items-center flex-1 gap-1.5">
                      <RotateCcw className="size-3" />
                      Reset
                    </button>
                    <button className="bg-[oklch(0.708_0.15_295)] font-mono font-bold rounded-xl text-white text-xs leading-4 flex py-2.5 justify-center items-center flex-1 gap-1.5">
                      <Check className="size-3" />
                      Save
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
