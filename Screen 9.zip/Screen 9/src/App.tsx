import { useEffect } from "react";
import {
  ArrowLeft,
  ChevronDown,
  Cpu,
  Eye,
  Pencil,
  Plus,
  Search,
  Star,
  Trash2,
  Wrench,
  Zap,
} from "lucide-react";
import { Switch } from "@/components/ui/switch";

export default function App() {
  return (
    <div>
      <div className="font-mono bg-neutral-950 text-neutral-50 w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <div className="flex flex-col">
          <div className="sticky z-20 bg-[oklch(0.10_0_0)] border-white/10 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex top-0 px-4 py-3 justify-between items-center">
            <div className="flex items-center gap-2">
              <button className="rounded-lg text-neutral-400 p-1">
                <ArrowLeft className="size-5" />
              </button>
              <span className="font-bold text-neutral-50 text-base leading-6 tracking-tight">
                Model Settings
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button className="rounded-lg text-neutral-400 p-1">
                <Search className="size-5" />
              </button>
              <button className="size-8 bg-[oklch(0.708_0.15_295)] rounded-full text-white flex justify-center items-center">
                <Plus className="size-4" />
              </button>
            </div>
          </div>
          <div className="px-4 pt-3 pb-2">
            <div className="rounded-xl bg-neutral-900 border-white/10 border-1 border-solid flex px-3 py-2 items-center gap-2">
              <Search className="size-4 shrink-0 text-neutral-500" />
              <span className="text-neutral-500 text-xs leading-4 tracking-wide">
                // search models...
              </span>
            </div>
          </div>
          <div className="flex px-4 pb-2 items-center gap-2">
            <Cpu className="size-3 text-[oklch(0.708_0.15_295)]" />
            <span className="text-[oklch(0.708_0.15_295)] font-mono uppercase text-[10px] tracking-widest">
              ⚙ // Configured Models
            </span>
          </div>
          <div className="flex px-4 pb-4 flex-col gap-2">
            <div className="relative rounded-xl bg-neutral-900 border-white/10 border-1 border-solid overflow-hidden">
              <div className="bg-[oklch(0.708_0.15_295)] absolute left-0 inset-y-0 w-0.5" />
              <div className="flex pl-4 pr-3 py-3 justify-between items-center">
                <div className="min-w-0 flex flex-col flex-1 gap-0.5">
                  <div className="flex items-center gap-1.5">
                    <span className="truncate font-bold text-neutral-50 text-sm leading-5">
                      gpt-4o
                    </span>
                    <div className="flex items-center gap-1">
                      <Eye className="size-3 text-[oklch(0.708_0.15_295)]" />
                      <Wrench className="size-3 text-[oklch(0.708_0.15_295)]" />
                    </div>
                  </div>
                  <span className="text-neutral-400 text-xs leading-4">
                    OpenAI
                  </span>
                  <span className="text-neutral-500 text-xs leading-4">
                    128K ctx
                  </span>
                </div>
                <div className="shrink-0 flex items-center gap-2">
                  <Switch checked={true} className="scale-75" />
                  <button className="text-neutral-400 p-1">
                    <Pencil className="size-3.5" />
                  </button>
                  <button className="text-red-400 p-1">
                    <Trash2 className="size-3.5" />
                  </button>
                </div>
              </div>
            </div>
            <div className="relative rounded-xl bg-neutral-900 border-white/10 border-1 border-solid overflow-hidden">
              <div className="bg-[oklch(0.708_0.15_295)] absolute left-0 inset-y-0 w-0.5" />
              <div className="flex pl-4 pr-3 py-3 justify-between items-center">
                <div className="min-w-0 flex flex-col flex-1 gap-0.5">
                  <div className="flex items-center gap-1.5">
                    <span className="truncate font-bold text-neutral-50 text-sm leading-5">
                      gpt-4o-mini
                    </span>
                    <div className="flex items-center gap-1">
                      <Wrench className="size-3 text-[oklch(0.708_0.15_295)]" />
                    </div>
                  </div>
                  <span className="text-neutral-400 text-xs leading-4">
                    OpenAI
                  </span>
                  <span className="text-neutral-500 text-xs leading-4">
                    128K ctx
                  </span>
                </div>
                <div className="shrink-0 flex items-center gap-2">
                  <Switch checked={true} className="scale-75" />
                  <button className="text-neutral-400 p-1">
                    <Pencil className="size-3.5" />
                  </button>
                  <button className="text-red-400 p-1">
                    <Trash2 className="size-3.5" />
                  </button>
                </div>
              </div>
            </div>
            <div className="relative rounded-xl bg-neutral-900 border-white/10 border-1 border-solid overflow-hidden">
              <div className="bg-[oklch(0.708_0.15_295)] absolute left-0 inset-y-0 w-0.5" />
              <div className="flex pl-4 pr-3 py-3 justify-between items-center">
                <div className="min-w-0 flex flex-col flex-1 gap-0.5">
                  <div className="flex items-center gap-1.5">
                    <span className="truncate font-bold text-neutral-50 text-sm leading-5">
                      gemini-1.5-pro
                    </span>
                    <div className="flex items-center gap-1">
                      <Eye className="size-3 text-[oklch(0.708_0.15_295)]" />
                      <Wrench className="size-3 text-[oklch(0.708_0.15_295)]" />
                    </div>
                  </div>
                  <span className="text-neutral-400 text-xs leading-4">
                    Google
                  </span>
                  <span className="text-neutral-500 text-xs leading-4">
                    1M ctx
                  </span>
                </div>
                <div className="shrink-0 flex items-center gap-2">
                  <Switch checked={true} className="scale-75" />
                  <button className="text-neutral-400 p-1">
                    <Pencil className="size-3.5" />
                  </button>
                  <button className="text-red-400 p-1">
                    <Trash2 className="size-3.5" />
                  </button>
                </div>
              </div>
            </div>
            <div className="relative rounded-xl bg-neutral-900 border-white/10 border-1 border-solid overflow-hidden">
              <div className="bg-[oklch(0.708_0.15_295)] absolute left-0 inset-y-0 w-0.5" />
              <div className="flex pl-4 pr-3 py-3 justify-between items-center">
                <div className="min-w-0 flex flex-col flex-1 gap-0.5">
                  <div className="flex items-center gap-1.5">
                    <span className="truncate font-bold text-neutral-50 text-sm leading-5">
                      claude-3.5-sonnet
                    </span>
                    <div className="flex items-center gap-1">
                      <Eye className="size-3 text-[oklch(0.708_0.15_295)]" />
                      <Wrench className="size-3 text-[oklch(0.708_0.15_295)]" />
                      <Zap className="size-3 text-[oklch(0.708_0.15_295)]" />
                    </div>
                  </div>
                  <span className="text-neutral-400 text-xs leading-4">
                    Anthropic
                  </span>
                  <span className="text-neutral-500 text-xs leading-4">
                    200K ctx
                  </span>
                </div>
                <div className="shrink-0 flex items-center gap-2">
                  <Switch checked={true} className="scale-75" />
                  <button className="text-neutral-400 p-1">
                    <Pencil className="size-3.5" />
                  </button>
                  <button className="text-red-400 p-1">
                    <Trash2 className="size-3.5" />
                  </button>
                </div>
              </div>
            </div>
            <div className="relative rounded-xl bg-neutral-900 border-white/10 border-1 border-solid overflow-hidden">
              <div className="flex pl-4 pr-3 py-3 justify-between items-center">
                <div className="min-w-0 flex flex-col flex-1 gap-0.5">
                  <div className="flex items-center gap-1.5">
                    <span className="truncate font-bold text-neutral-400 text-sm leading-5">
                      deepseek-chat
                    </span>
                  </div>
                  <span className="text-neutral-500 text-xs leading-4">
                    DeepSeek
                  </span>
                  <span className="text-neutral-600 text-xs leading-4">
                    64K ctx
                  </span>
                </div>
                <div className="shrink-0 flex items-center gap-2">
                  <Switch className="scale-75" />
                  <button className="text-neutral-600 p-1">
                    <Pencil className="size-3.5" />
                  </button>
                  <button className="text-red-400/50 p-1">
                    <Trash2 className="size-3.5" />
                  </button>
                </div>
              </div>
            </div>
            <div className="relative rounded-xl bg-neutral-900 border-white/10 border-1 border-solid overflow-hidden">
              <div className="bg-[oklch(0.708_0.15_295)] absolute left-0 inset-y-0 w-0.5" />
              <div className="flex pl-4 pr-3 py-3 justify-between items-center">
                <div className="min-w-0 flex flex-col flex-1 gap-0.5">
                  <div className="flex items-center gap-1.5">
                    <span className="truncate font-bold text-neutral-50 text-sm leading-5">
                      glm-4
                    </span>
                    <div className="flex items-center gap-1">
                      <Eye className="size-3 text-[oklch(0.708_0.15_295)]" />
                    </div>
                  </div>
                  <span className="text-neutral-400 text-xs leading-4">
                    GLM
                  </span>
                  <span className="text-neutral-500 text-xs leading-4">
                    128K ctx
                  </span>
                </div>
                <div className="shrink-0 flex items-center gap-2">
                  <Switch checked={true} className="scale-75" />
                  <button className="text-neutral-400 p-1">
                    <Pencil className="size-3.5" />
                  </button>
                  <button className="text-red-400 p-1">
                    <Trash2 className="size-3.5" />
                  </button>
                </div>
              </div>
            </div>
            <div className="pt-1 pb-2">
              <span className="font-mono text-neutral-600 text-[10px]">
                // tap edit to configure per-model generation params
              </span>
            </div>
          </div>
          <div className="sticky z-20 bg-[oklch(0.10_0_0)] border-white/10 border-t-1 border-r-0 border-b-0 border-l-0 border-solid flex bottom-0 px-4 py-3 justify-between items-center">
            <div className="flex items-center gap-1.5">
              <Star className="size-3 text-[oklch(0.708_0.15_295)]" />
              <span className="text-[oklch(0.708_0.15_295)] font-mono uppercase text-[10px] tracking-widest">
                ★ Active Default Model
              </span>
            </div>
            <button className="rounded-lg bg-neutral-900 border-white/10 border-1 border-solid flex px-3 py-1.5 items-center gap-1">
              <span className="font-mono font-bold text-neutral-50 text-xs leading-4">
                gpt-4o-mini
              </span>
              <ChevronDown className="size-3.5 text-neutral-400" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
