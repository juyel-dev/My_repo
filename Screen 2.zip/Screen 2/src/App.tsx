import { useEffect } from "react";
import {
  ArrowRight,
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronsUpDown,
  KeyRound,
  Zap,
} from "lucide-react";

export default function App() {
  return (
    <div>
      <div className="font-mono bg-neutral-950 text-neutral-50 w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <div className="min-h-[874px] flex p-8 flex-col">
          <div className="text-sm leading-5 flex justify-between items-center">
            <button className="text-neutral-50 flex items-center gap-1">
              <ChevronLeft className="size-4" />
              <span>Back</span>
            </button>
            <span className="text-violet-400 tracking-wide">BYOK Setup</span>
            <span className="text-[#555]">|Skip|</span>
          </div>
          <div className="whitespace-nowrap text-[#555] text-xs leading-4 tracking-tighter mt-4 overflow-hidden">
            ════════════════════════════════════════
          </div>
          <p className="text-violet-400 text-sm leading-5 mt-6">
            // Step 1 — Add your first AI Provider
          </p>
          <div className="rounded-lg bg-neutral-900 border-white/10 border-1 border-solid mt-4 p-4">
            <div className="text-sm leading-5 flex items-center gap-2">
              <span className="text-[#555]">Provider</span>
              <ChevronDown className="size-4 text-violet-400" />
              <div className="rounded-sm border-white/15 border-1 border-solid flex px-2 py-1 justify-between items-center flex-1">
                <span className="text-neutral-50">OpenAI</span>
                <ChevronsUpDown className="size-3 text-[#555]" />
              </div>
            </div>
          </div>
          <div className="flex mt-6 flex-col gap-4">
            <div className="flex flex-col gap-1">
              <label className="text-[#e0e0e0] text-xs leading-4">
                Display Name
              </label>
              <div className="rounded-lg bg-neutral-900 text-[#555] text-sm leading-5 border-white/10 border-1 border-solid px-4 py-3">
                e.g. My OpenAI
              </div>
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[#e0e0e0] text-xs leading-4">
                Model Name<span className="text-violet-400">*</span>
              </label>
              <div className="rounded-lg bg-neutral-900 text-[#555] text-sm leading-5 border-white/10 border-1 border-solid px-4 py-3">
                e.g. gpt-4o
              </div>
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[#e0e0e0] text-xs leading-4">
                Base URL<span className="text-violet-400">*</span>
              </label>
              <div className="rounded-lg bg-neutral-900 text-neutral-50 text-sm leading-5 border-white/10 border-1 border-solid px-4 py-3">
                https://api.openai.com/v1
              </div>
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[#e0e0e0] text-xs leading-4">
                API Key<span className="text-violet-400">*</span>
              </label>
              <div className="rounded-lg bg-neutral-900 text-sm leading-5 border-white/10 border-1 border-solid flex px-4 py-3 justify-between items-center">
                <span className="text-neutral-50 tracking-widest">
                  sk-••••••••••••••••••••••••••••
                </span>
                <KeyRound className="size-4 text-[#555]" />
              </div>
            </div>
          </div>
          <p className="text-[#555] text-xs leading-4 mt-4">
            // * required fields ° optional per-model config
          </p>
          <div className="whitespace-nowrap text-[#555] text-xs leading-4 tracking-tighter mt-4 overflow-hidden">
            ───────────────────────────────────────
          </div>
          <div className="flex mt-4 gap-2">
            <button className="rounded-lg bg-neutral-900 text-neutral-50 text-sm leading-5 border-white/10 border-1 border-solid flex px-2 py-3 justify-center items-center flex-1 gap-2">
              <Zap className="size-4 text-violet-400" />
              <span>Test Endpoint</span>
            </button>
            <button className="font-medium rounded-lg bg-violet-400 text-[#0d0d0d] text-sm leading-5 flex px-2 py-3 justify-center items-center flex-1 gap-2">
              <Check className="size-4" />
              <span>{`Connect & Save`}</span>
              <ArrowRight className="size-4" />
            </button>
          </div>
          <p className="text-[#555] text-xs leading-4 mt-4">
            // Status: waiting for input...
          </p>
        </div>
      </div>
    </div>
  );
}
